import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {CALayerRenderer as Old} from '../grain0410-edge-r2/ca-layer.mjs';
import {CALayerRenderer as Batch} from '../grain0410-edge-r3/ca-layer.mjs';
const {createCanvas}=createRequire('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/x.js')('@napi-rs/canvas');
const dpr=Number(process.argv[2]||1),width=324*dpr,height=486*dpr;
const ts=[Old,Batch].map(Type=>{const canvas=createCanvas(width,height);return {canvas,c:canvas.getContext('2d'),r:new Type({createCanvas:()=>createCanvas(1,1)})}});
const bodies=Array.from({length:52992},(_,id)=>({id,x:28.5+id%232,y:419.5-Math.floor(id/232),color:1+id%4}));
const results=[];
function draw(label,patch){for(const {r,c} of ts){r.apply(structuredClone(patch));r.synchronize([],null);r.configure(width,height,'standard');c.setTransform(width/288,0,0,height/432,0,0);c.fillStyle='#0d1315';c.fillRect(0,0,288,432);r.draw(c)}
for(const type of ['screen','cache']){const a=ts[0][type==='screen'?'canvas':'r'],b=ts[1][type==='screen'?'canvas':'r'];const aa=type==='screen'?a:a.canvas,bb=type==='screen'?b:b.canvas;assert(Buffer.from(aa.getContext('2d').getImageData(0,0,width,height).data).equals(Buffer.from(bb.getContext('2d').getImageData(0,0,width,height).data)),`${label} ${type}`)}
results.push({label,old:ts[0].r.read(),batch:ts[1].r.read()});}
draw('initial-52992',{reset:true,removed:[],upsert:bodies});
const ids=bodies.filter(b=>[31.5,32.5,47.5,48.5,79.5,80.5,159.5,160.5].includes(b.x)&&[207.5,208.5,239.5,240.5,319.5,320.5,399.5,400.5].includes(b.y)).map(b=>b.id);
draw('simultaneous-tile-corner-recolor',{removed:[],upsert:ids.map(id=>({...bodies[id],color:1+(bodies[id].color%4)}))});
draw('remove-shared-border-grains',{removed:ids,upsert:[]});
draw('reinsert-reversed-paint-ranks',{removed:[],upsert:ids.toReversed().map(id=>bodies[id])});
draw('unchanged-idle',{removed:[],upsert:[]});
draw('reset',{reset:true,removed:[],upsert:[]});
const report={passed:true,dpr,comparisons:results.length*2,scope:'Node exact RGBA only; repeated native canvas allocations are not browser performance or leak proof',results};
writeFileSync(new URL(`r3-batch-stress-dpr${dpr}.json`,import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({passed:true,dpr,comparisons:report.comparisons,rows:results.map(x=>({label:x.label,tiles:x.old.lastDirtyTiles,oldPaints:x.old.lastStablePaints,batchPaints:x.batch.lastStablePaints}))}));
