# 0.4.10 edge-contour-r3: dirty-tile batching

Frozen r3 candidate: grain0410-edge-r3. Apply grain0410-edge-r3-delta on complete frozen r2. Only runtime ca-layer.mjs changes. Other nine runtime files, including contour and all physical/presentation protocol code, are byte-identical. No Path2D or geometry-rule changes.

The independently measured r2 hotspot is dirty-cache processing, chiefly tile-copy calls; the repeated source modification/copy chain is now replaced by one scratch union paint in global paint order, followed by unchanged exact device-pixel crops. Source transform, size, per-grain fill and AA footprint remain unchanged. Whole scratch clearing is transparent initialization only: the stable bed is not fully repainted. No extra persistent state is retained.

## Completed

51 Node tests, 252 independent full-reference exact RGBA fixture draws, 320 slot cycles and551-frame physics/path parity passed. New behavioral assertion verifies a single sorted union paint occurs before all tile copies, and idle performs no scratch work. New full-reference fixture uses52992 particles,56 simultaneous dirty tile corner regions, four colors, removal, reversed reinsertion and reset.

A separate direct frozen-r2/r3 comparison additionally passed36 screen/cache pairs at DPR1/1.5/2, at original full-canvas origin. Its source is r3-batch-stress.mjs; run from this workspace with node grain0410-perf-evidence/r3-batch-stress.mjs 1 (then1.5 and2 as separate processes). It uses the preinstalled @napi-rs/canvas and imports the explicit sibling r2/r3 directories; adjust only consumer-local paths when relocated. This verifies raster output, not live browser performance or memory health.

DPR2 extreme recolor:16236→13768 grain fills;56 dirty tile crops unchanged. This operation reduction is measured, but no actual browser speedup is claimed yet.

## Required independent review

Verify five-file overlay and ten runtime hashes, then npm test (51), verify:pixels:browser (252), verify:browser, verify:slots, verify:parity. Compare frozen r2/r3 directly at DPR1/1.5/2 for tiled mutations and actual same presented poses; render each from a complete independent dependency root. Existing fixed1001/1212 suites can be reused; contour source is identical to verified r2.

Run unprofiled actual high-density DPR2 with recording/screenshots/forcedGC separate. Capture exact dimensions, live particle range, actual drop poses, draw/s, complete rAF/draw percentiles, over-budget counts and consecutive lengths, dirty tiles/paint counts/full-cache rebuilds, peak and final activity-window debt and later settled debt separately. Do not use final ratio≈1 to hide transient backlog. Old r2 debt peak1.31s is a known failure.

Preserve first/second drop visuals, real natural clearing/ACK gate, mixed colors, isolated particles, resize, fallback and reset. Confirm body/style/tile/contour indices clear. No new persistent objects are introduced, but this does not resolve the existing long-term native-memory uncertainty.

No browser launched on dot cloud, no publication, no change to input/physics/clock/resolution. Independent Chromium performance remains the acceptance gate.
