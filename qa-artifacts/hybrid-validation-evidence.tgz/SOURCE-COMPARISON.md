# Released 0.4.9 versus r13: source-level comparison

Reviewed actual released 0.4.9 under grainform-sites-owner-0410/dist/experimental/0.4.9 and frozen r13 under grain0410-r13-external/unpacked/candidate. Static facts below explain why movement could change; only same-condition continuous video establishes the experienced difference.

| Layer | Released 0.4.9 | r13 |
|---|---|---|
| Material clock | ca-world:3 dt=1/60; ca-frame-world:8–15 invokes four rules per 60 Hz output | dt=1/240, same four calls |
| Grain birth | game:51 always 480 | intact natural speed formula, first block 43.2 |
| Transport | ca-world:41 active-particle vy/credit accumulation, unused credit retained to cap 8 | ca-world:74–79 birth-age analytic current integer Q, blocked remainder discarded; cap720 |
| Update | initial chunk ID snapshot, 8 global downward rounds, then 3 reserved slip rounds | one ordered bottom-up wake-front visit per ID, local while-quota down/diagonal actions |
| Slide geometry | ca-world:37–44 ID roughness permits corridor length1/2; one/two horizontal unit legs then one vertical leg, one credit per complete slip | distance1 only, direct diagonal descent, one credit per descent |
| Path time | ca-frame-world:13 actual 68 integer phases; axis-unit interpolation with holds | actual polyline arc-length within four quarter-output intervals |
| Wire paths | ca-adapter:16 {id,points} | {id,mode:'substep-arc',points} |
| Queue | ca-layer:37–72 old head only, every frame alpha1 draw, single ACK object | successive intervals may be consumed together, final barrier mandatory, ACK array |
| Geometry display | fixed ID micro-grains + cached settled layer | same styles plus independent contour clipping/rim and cache optimizations |

The 4×1/60 material integration is a concrete old-game speed rule. Interpreting each 60 Hz output as a physically calibrated 1/60 material second would be inconsistent, but that does not authorize changing the user's accepted feel. Faster old virtual gravity does not alone explain all perceived flow: old two-column slips, phase ordering, credit and path presentation all differ.

## Minimum compatible edge-only splice

Only two runtime files change:
- Add r13 ca-contour.mjs, which reads rendered bodies/positions and never writes world state.
- Preserve the old ca-layer constants, path decoder, path validator and MaterialFrameQueue byte-for-byte. Import the contour helper; use r13 tinyGrain (including x/y arguments) and CALayerRenderer. Identity hash/style/tint are unchanged.

r13 CALayerRenderer.synchronize uses sample?.displayQueue ?? queue and therefore accepts the old sample.positions and old queue. The bodyPatch schema, center offset (+28.5,+.5), IDs, colors and board dimensions already agree. The full rendering-class splice also retains r13's exact-pose cache/paint allocation optimizations; these require same-pose raster validation but do not change motion. Copying all of r13 ca-layer would be wrong because the new queue returns arrays where old app/worker expect one receipt.

No physics, adapter, app, worker, input, UI version, palette, path generation or queue-clock edits are required. The original full L paths and all-frame endpoint ACK remain intact. Newly smoothed old-motion poses still need independent real video review for holes, stairs, chunk seams, draw debt and flow quality.
