// Runs unchanged original 0.4.9 Node gates in disposable copies, then the
// same npm test with Canvas-mock capabilities adapted and assertions untouched.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const base=path.resolve(fileURLToPath(new URL('..',import.meta.url)));
assert(process.env.ORIGINAL049_ROOT,'Set ORIGINAL049_ROOT to the fixed-commit complete 0.4.9 test package');
const source=path.resolve(process.env.ORIGINAL049_ROOT),candidate=path.resolve(process.env.CANDIDATE_ROOT??path.join(base,'candidate'));
const work=path.resolve(process.env.GATES_WORK_ROOT??path.join(base,`validation-work-${Date.now()}`)),out=path.join(base,'evidence');
assert(!fs.existsSync(work),'Use a new GATES_WORK_ROOT; original tests are never changed in place');
fs.mkdirSync(work,{recursive:true});fs.mkdirSync(out,{recursive:true});
const runs=[];
function run(label,dir,args){const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8',maxBuffer:32*1024*1024});const log=`${label}.log`;fs.writeFileSync(path.join(out,log),(r.stdout??'')+(r.stderr??''));const result={label,command:['node',...args],exitCode:r.status,signal:r.signal,log};runs.push(result);console.log(JSON.stringify(result));}
const suites=[['npm-test',['--test','tests/ca-game.test.mjs','tests/ca-phase.test.mjs','tests/ui-ca-presentation.test.mjs','tests/ui-grid-clock.test.mjs','tests/ui-grid-renderer.test.mjs','tests/ui-grid-boot.test.mjs','tests/ui-message-clock.test.mjs']],['slots',['merge-test.mjs']],['parity',['merge-parity.mjs']],['pixels',['tests/pixel-equivalence-node.mjs']]];
for(const kind of ['original','hybrid']){const dir=path.join(work,kind);fs.cpSync(source,dir,{recursive:true});fs.mkdirSync(path.join(dir,'evidence'),{recursive:true});if(kind==='hybrid')for(const file of ['ca-layer.mjs','ca-contour.mjs'])fs.copyFileSync(path.join(candidate,file),path.join(dir,file));for(const [name,args]of suites)run(`${kind}-${name}`,dir,args);}
const compat=path.join(work,'hybrid-canvasmock');fs.cpSync(path.join(work,'hybrid'),compat,{recursive:true});
run('adapt-canvas-mocks',base,[path.join(base,'validation/compat-original-mocks.mjs'),compat]);
run('hybrid-canvasmock-npm-test',compat,suites[0][1]);
const report={originalCommit:'2a8fe3b67a75df2a74a124871d80acf5543cc271',runs,classification:'Unchanged hybrid npm test may fail old Canvas mocks; unchanged old RGBA oracle intentionally disagrees with approved new edges. Neither FAIL is rewritten as PASS. Motion/slots/parity, all assertions after mock-only capability adaptation, and the independent new-edge full-raster comparison are required.'};fs.writeFileSync(path.join(out,'original-gates-reproduced.json'),JSON.stringify(report,null,2)+'\n');
// Expected incompatibilities remain visible above; valid gates must still pass.
process.exitCode=runs.some(r=>r.exitCode!==0&&!['hybrid-npm-test','hybrid-pixels'].includes(r.label))?1:0;
