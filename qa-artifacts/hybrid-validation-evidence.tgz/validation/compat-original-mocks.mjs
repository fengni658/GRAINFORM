// Test-fixture capability adaptation only. Assertions and runtime files stay unchanged.
// Use only on a disposable copy of original 0.4.9 tests, never the fetched source.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'');
assert(process.argv[2], 'Pass a disposable test-copy directory');
const file=path.join(root,'tests/ui-ca-presentation.test.mjs');
let s=fs.readFileSync(file,'utf8');
const old='class Context {constructor(){this.cells=[];this.images=0;}save(){}restore(){}setTransform(){}clearRect(){}drawImage(){this.images++;}fillRect(...v){this.cells.push(v);}beginPath(){}arc(x,y,r){this.cells.push([x,y,r]);}fill(){}}';
const next='class Context {constructor(){this.cells=[];this.images=0;this.pathArcs=[];}save(){}restore(){}setTransform(){}clearRect(){}drawImage(){this.images++;}fillRect(...v){this.cells.push(v);}beginPath(){this.pathArcs=[];}arc(x,y,r){this.pathArcs.push([x,y,r]);}moveTo(){}lineTo(){}quadraticCurveTo(){}closePath(){}clip(){}stroke(){}fill(){this.cells.push(...this.pathArcs);}}';
assert(s.includes(old),'Unexpected original mock: no blind replacement');
s=s.replace(old,next);fs.writeFileSync(file,s);
const boot=path.join(root,'tests/ui-grid-boot.test.mjs');s=fs.readFileSync(boot,'utf8');
assert(s.includes('arc(){}moveTo(){}lineTo(){}closePath()'),'Unexpected boot mock');
s=s.replace('arc(){}moveTo(){}lineTo(){}closePath()','arc(){}moveTo(){}lineTo(){}quadraticCurveTo(){}stroke(){}closePath()');fs.writeFileSync(boot,s);
console.log('Only two Canvas mocks changed; existing assertions untouched. Arc paths now count as painted only on fill(), not when assembled for clip().');
