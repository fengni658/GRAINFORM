# Frozen hybrid: released 0.4.9 motion + r13 edges

**The two-file runtime hybrid is ready for the authorized three-way continuous-video review. This is not visual approval or a release.** The inherited UI and VERSION still say 0.4.9. No deployment, GitHub write, browser session, new motion rule, speed adjustment or parameter search was performed in this implementation.

## Exact scope

Baseline is the real published 0.4.9 runtime, verified byte-for-byte against original Git commit `2a8fe3b67a75df2a74a124871d80acf5543cc271`. Eight of its nine runtime files are unchanged. ca-layer.mjs retains the old path decoder/validator, MaterialFrameQueue, constants, hash/style and tint exactly; only the renderer class/tinyGrain helper are transplanted, plus an import. ca-contour.mjs is byte-identical to frozen r13. The renderer transplant also brings r13's pure dirty-cache/dynamic-paint allocation optimizations.

The two-file delta overlays **0.4.9, not r13**. Initial speed480, up-to-four material1/60 rule steps per60Hz output, fixed-list scheduling, persistent blocked credit, ID-dependent1–2-column L slips, reservation stages, unit-axis path legs/holds, old single-object ACK, controls, rigid speed and every-frame endpoint barrier are untouched. This material speed is a game rule, not a physically calibrated clock claim. Wall-clock presentation has not been slowed or replaced.

## Original tests: retain the actual outcomes

- Original `npm test`:36/36. Hybrid with unchanged original tests:32/36; four old Canvas mocks lack contour drawing methods. Original FAIL logs are included.
- Separately adapted Canvas mocks, original assertions unchanged:36/36. The two test-only edits add path methods and make arc construction count as painted only at fill(), as real Canvas does. No runtime workaround was added.
- Original `verify:slots`:both versions pass, including320 slot-reuse cycles.
- Original `verify:parity`:both pass551 frame observations plus330 single-rule observations. Exact trajectory SHA256 for both: `31205449eb19668c2e2b8a9a9e1b7fa9dff7bd608772814f195b0ec5038ac5bb`. Includes six historical fixture batches, clear and support removal, frozen checkpoints.
- Original `verify:pixels`:old144/144; hybrid has70 intentional old-screen mismatches. All72 raw-cell cases and all cache comparisons remain exact. Old un-contoured pixel equality cannot be the new-edge acceptance gate; its FAIL is preserved rather than rewritten.

Original source/test hashes are in ORIGINAL-TEST-PROVENANCE.json. The unrelated legacy/preview app suites and browser gates were not run here.

## New rendering evidence and retained limitation

Independent reference code rebuilds MaterialContour fresh at each pose and paints fixed-identity grains directly, without the candidate renderer/tile-cache methods. At DPR1/1.5/2,185 poses produce555 screen plus555 cache RGBA comparisons,333,745,920 pixels, zero differences. Includes18 actual old-game path frames from blocks1/2/6, tile borders, two-horizontal-leg L turns, deletion, reuse, reset, thin streams and a one-cell hole. Those raster-path fixture inputs are intentionally separate from the natural-first video protocol and are listed in render.json.

Twenty still frames per DPR add zero contour/cache rebuilds or grain paints. Fourteen thin/L/stream geometry groups retain fully opaque centers and full-glyph protection. The known one-cell hole stays transparent.

One newly authored diagnostic remains FAIL, not hidden: an 8× mask sample of a thick block's outer-corner logical center has alpha124 versus the diagnostic's180 threshold. A64× sample is255. The actual jitter center lies outside the existing contour; the grain retains about39–41% of its alpha area. Original r13 and hybrid screens at DPR1/1.5/2 and their contour masks are identical for that pose. Thus this is an inherited partial exterior-grain trim, not a newly introduced hybrid hole/seam or complete grain disappearance. No threshold or renderer change was made. render.json retains `pass:false` for the aggregate diagnostic and separately reports the passing raster/legacy-contour/limited thin-hole checks. This does not prove universal hole-free geometry.

The first render attempt was killed (exit137) after repeatedly allocating temporary Canvas buffers. Only the validation script was fixed to reuse buffers; the initial log is preserved. This is not a game runtime memory/performance measurement.

## Motion and presentation proof

Final motion proof passes:659,928 independently occupancy-checked real unit actions,659,928 exact path legs,2,206,375 endpoint/midpoint/hold samples,382 original single-object ACKs and140 terminal output frames held without ACK. Six fixed-input blocks (natural first, moves24/−72/48/−24/72, rotations2/4/6) settle in34/82/17/107/23/115 output frames in both original and hybrid;13,824 cells remain. These settling counts exclude the extra withheld-ACK holds and are not wall-clock browser results. A real worker also preserves60Hz control timing over240 ticks. See evidence/motion.json and motion.log, including the real two-horizontal-leg fixture. The test checks original/hybrid snapshots, patches, occupancy, color/mass, every recorded action, fractional path samples, unit-axis geometry, terminal ACK withholding, no-disturbance20 frames, support removal and generation reuse. An earlier different-rotation fixture pass is retained separately. The first ACK-fixture failure was overwritten by a rerun, so no complete original failure trace is claimed; first-failure-notes.md records the exact observed mistake and correction. Runtime never changed to satisfy it.

## Handoff

- RUNTIME-MANIFEST.json:all10 hybrid runtime files, sizes/hashes and original hashes.
- hybrid-delta.tgz:only ca-layer.mjs and ca-contour.mjs.
- hybrid-validation-evidence.tgz:small validation scripts, manifests, these technical reports and actual evidence; no old assets, full-source duplicate or3.85MB frozen expected dataset.
- VALIDATION.md:reproduction commands and reference bindings.
- QA-SPEC.md:real original0.4.9, hybrid and r13, same natural first / moved-rotated second / sixth, continuous normal-speed video and real frame/ACK observations.

No flow-quality claim follows from numeric equality. The decisive next step is the same-condition three-way video: does the old accepted deformation remain, do new edges still help it, and are any motion stair/chunk artifacts or contour costs visible? Final UI/version choice is deferred until review.
