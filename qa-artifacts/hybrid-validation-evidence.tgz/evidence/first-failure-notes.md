# Motion-test development history and retained evidence

The authoritative final result is `motion.json` / `motion.log`. Its input rotates only pieces 2, 4 and 6. It passed all five scenarios.

## Original failure was overwritten, not preserved

The complete JSON and log from the first long run were overwritten by the next run before they were copied. They are not available as a complete original artifact. The following is a factual reconstruction from the command's captured output, not a reconstructed original result file.

The first long run used a different six-piece input: rotations on pieces 2, 3 and 5, instead of the required 2, 4 and 6. Six-piece parity and the dist2/local-support/slot-reuse fixtures passed. At approximately 24.136 seconds, the ACK fixture failed with this assertion:

    ACK fixture frame 2 no early queue ACK
    actual: { epoch: 1, ruleTick: 4, token: 1 }
    expected: null

The test assumption was wrong: when frame 2 arrived, frame 1 had already reached alpha = 1. Calling the original queue's `didDraw()` at that point correctly returned frame 1's single ACK. The test had incorrectly assumed that receiving frame 2 implied frame 1 was still early.

Only the test was changed: when a sampled queue head has alpha < 1, assert `didDraw()` returns null; when it has alpha = 1, leave the sampled completion uncommitted until the explicit final-draw/ACK test. No runtime, movement rule, probability, queue implementation, or candidate file was changed.

An earlier short startup attempt also exposed a test-only floating-point assertion issue: the legacy game computes `gameTick * (1 / 60)`, which is not bit-identical to `gameTick / 60` for every tick. The assertion now matches the exact original multiplication expression. This did not change game timing.

## Different-input artifacts

Both `motion-different-input-attempt.*` and `motion-different-input-ack-fixed.*` contain the same subsequent passed run with rotations 2, 3 and 5, including 270 ACKs. The former name does not mean it retains the original failed run. The copy happened after the next run had already overwritten the source result. These duplicates are retained for transparency, and neither is the final required-input acceptance result.

## Final required-input run

The fixture was then corrected to rotate pieces 2, 4 and 6, with horizontal inputs +24, -72, +48, -24, +72 after the first natural-fall piece. This run passed, recording 659,928 independently validated real unit actions, the same number of real path legs, 382 original single ACKs, and 140 terminal output frames held without an ACK. Full results and exact input manifest are in `motion.json`.
