# Isolated 0.4.9-motion / r13-edge hybrid

This is an unpublished visual experiment. UI, VERSION, game rules, world update, material time rule, worker and presentation queue remain the released 0.4.9 files. It is not a new product version. Only ca-layer.mjs rendering helpers/class and added ca-contour.mjs differ from released 0.4.9. No deployment is authorized by this package.

## Three-way baseline

Record actual released 0.4.9, hybrid and frozen r13 under the same viewport (1100×850), DPR 2, 324 CSS-pixel board width, seed 1, standard palette, motion enabled, QA display off. Use separate paths/origins or clear independent storage before each run. Label the unchanged 0.4.9 UI in the hybrid with an external video caption, not a game-source edit.

1. Natural first block: start and leave all inputs untouched until contact, material settling and next rigid block. Include ≥0.3 s before contact and ≥0.4 s after stable material.
2. Uninterrupted six blocks: first naturally lands. For subsequent blocks relative moves are [24,-72,48,-24,72]; rotate blocks 2, 4 and 6 once, then hard drop. Wait for each actual command ACK and matching piece ID. Wait for the next FALLING phase before the next input. Keep the entire recording, then provide first/second/sixth contact-aligned normal-speed excerpts.

Normal-speed wall-clock videos are decisive. Do not resample motion to pretend 60 successful draws/s, interpolate missing captures, slow playback, cut the waiting tail, or infer feel from endpoint images. Use the same scene inputs but do not force identical contact coordinates after the first block: changed heaps naturally change later contact height. Contact should align to the earliest worker settling/contact-conversion snapshot, not a delayed wait completion.

## What should be visible and what remains uncertain

- Hybrid must retain exactly old 0.4.9 sideways travel and granular deformation. Compare original/hybrid directly before comparing r13.
- The renderer should smooth old exposed edges while retaining tiny grains, thin flow, holes, color boundaries and the exact old L-shaped path. Two horizontal unit legs followed by one downward unit leg must not become a diagonal shortcut.
- In r13, the old two-column L slips, global slide phases and preserved blocked credit were replaced. The hybrid restores none of these by approximation: its unchanged old world already supplies them.
- Do not assume contour smoothing can fix motion-produced stairs or 16-cell wake-boundary discontinuities. Inspect these in continuous motion, including thin outer streams and sloping old heaps.
- Compare old/hybrid real draw cadence, cold/contact draw maximum and worker debt. New contour cost can change actual backpressure even though the movement source and intended output interval are identical.

## Clock and presentation semantics

Old 0.4.9 runs up to four material rule steps of 1/60 per 60 Hz control/output frame, with initial grain speed 480. This is the accepted game's material-speed rule, not a claim of physically calibrated gravity or four true quarter-time substeps. The control/worker interval remains 1/60 wall second; no playback slowdown or queue/time rewrite belongs to this experiment.

Every old queued material frame, not merely the final frame, requires its alpha=1 draw before the old single-object ACK. The queue stays bounded at two. Preserve and inspect final endpoint draw → receipt → worker ACK → clear/new-piece order, pause/resume, epoch reset and resync. This hybrid does not use r13's intermediate-consumption queue or array receipts.

## Source binding

Delta overlays the released 0.4.9 directory. It does not overlay r13. For local validation set OLD049_ROOT to an untouched released 0.4.9 copy and CANDIDATE_ROOT to the overlay target if it is not ../candidate. R13_ROOT is optional source-reference binding only; do not import its world into the hybrid.

The original 0.4.9 test bundle and its fixed-commit provenance are listed in FINAL-REPORT.md once recovered. Preserve any original FAIL and classify it; never change material rules to satisfy a test written for a different revision.
