# R2 independent browser checklist

Keep both frozen source trees unchanged. Put this checklist and browser-fixed-suite.mjs outside them. Verify all r1/r2 source hashes before and after QA.

## Fixed synthetic scan entry

The earlier independent1001/1212 review had only tool output and no saved executable. browser-fixed-suite.mjs is an external, self-contained browser reproduction of that fixed acceptance definition, not a file from the frozen implementation and not a claim that a browser run already passed.

Serve the helper at any verified QA-only URL. In an otherwise empty page on that local origin, import it and call runFixedR2Suite with explicit r1Base and r2Base directory URLs, each ending in /. Example with verified local routes:

const result = await (await import('/qa/browser-fixed-suite.mjs')).runFixedR2Suite({r1Base: location.origin + '/r1/', r2Base: location.origin + '/r2/'});

Save returned JSON outside the candidate. Counts:1001 approaching-tip positions;1212 outlet connectivity checks (3 shapes ×101 shifts ×2 axes ×2 render modes); diagonal isolation and four bridge offsets. It also reports the exact old rounding-boundary probes at y11/12. This is synthetic Canvas2D evidence, not natural game/video/FPS evidence. No further parameter search or new exception hunt is requested.

Also run the unchanged candidate commands: npm test (50), verify:pixels:browser (228), verify:browser, slots and parity. Do not run the known monolithic Node long-sequence command merely to reproduce its native-backend OOM.

## Matched real moving poses

Capture real first/second keyboard drops at DPR1/1.5/2, with QA OFF. Keep the real canvas MediaRecorder evidence. Additionally use an external read-only prototype wrapper around synchronize/draw to capture bodies, moving IDs, positions, sample alpha/token and rule tick from one actual rAF in early/middle/late flow. Render the captured identical presented pose through both r1 and r2 in separate comparison canvases, at the same CSS/backing sizes and draw order. Do not substitute the worker's later endpoints or compare unrelated wall-clock screenshots as identical poses.

IMPORTANT: r1 ca-layer imports its own ca-contour. Serve both complete frozen module trees under separate prefixes. Renaming only ca-layer into the r2 directory silently uses the wrong dependency and produces a false comparison.

Label matched-pose images as supplemental pose comparisons, not time evidence. Show native CSS size and separately labelled nearest-neighbor zoom; do not treat zoomed1px grain roughness as a user-sized defect. Watch for classification jumps, disappearing isolated/diagonal grains, interrupted stream mouths/bridges, filled one-cell holes, color fringes, and whether remaining short protrusions are freely moving grains.

## DPR2 high-density performance

Run r1 and r2 sequentially on the same machine, seed, viewport, input sequence and actual canvas backing dimensions (324CSS board →648px at DPR2). Keep timing separate from screenshots, recording, forced GC and topology scans. Measure a13824-grain sixth block and an active43776–52992-grain interval; exclude pause/long input waits. Record sample counts/duration/live counts. Repeated comparable short runs are preferable to a single lucky number.

Required metrics: actual draw/s from drawCount; complete active rAF p50/p95/p99/max; draw and contour-update p95/p99/max; counts and percentages above16.67/33.33ms; longest consecutive budget exceedance; pending material frames/max; debt start/end/trajectory and simulation/active-wall ratio; stable/dynamic paints, dirty tiles and full rebuild count; errors, conserved grain counts, gate/clear/reset behavior. Confirm the high-density test is truly DPR2, not merely a DPR2 screenshot pass.

Do not call it zero-drop. If p95 reaches/exceeds the16.67ms budget, tail events become repeated/sustained, actual draw rate materially declines against r1, or debt keeps growing, report it as a blocker/tradeoff for the owner. A short-window RSS rise alone does not identify a canvas leak; retain the prior memory caveat and check JS/index reset counts separately.
