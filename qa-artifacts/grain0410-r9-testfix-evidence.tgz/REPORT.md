# r9 test-only correction
Frozen r9 runtime is unchanged. This corrects test assumptions, not gameplay, performance or tail acceptance.

Original verify:slots failed at merge-test.mjs:17, vy 3.75 versus old 15. Earlier local reporting missed the nonzero exit status; only the first three groups including 320 bounded reuse cycles completed. Original raw log is retained unchanged.

Round 1: authorized line17 update uses CFG.gravity*CFG.dt and strict credit0; reused birthSpeed0 and birthTick=current tick assertions added. Slots then failed at line18: zero-speed birth has no integer transport quota in the first frame. npm test separately passed76/76 exit0. Both raw logs/status retained.

Round 2: line18 advances exactly3 output frames (12 material steps). For zero birth speed, Q(11)=0.9453125<1, Q(12)=1.125>=1. First two frames must have no audited movement; each frame checks retained identity and roughness; third must audit the fresh generation. No timeout extension or speed change. Lines19/20 contain no time progression and remain unchanged.

Round2 complete: all7 slots groups PASS, process exit0; npm test76/76 PASS, exit0. Wrapper exit0. All10 runtime hashes match frozen r9 manifest.

Apply files from patch/ over r9. Replay: node tests/run-test-gates.mjs <new-output-directory>. The wrapper executes both npm run verify:slots and npm test independently, records each exit code/signal/error, and exits1 if either fails regardless of earlier PASS lines. It writes exit-status.json and raw streams. Use a fresh directory to retain previous results.

This does not resolve r9 twentieth-block 2.62s settling or independently establish visual/performance acceptance.
