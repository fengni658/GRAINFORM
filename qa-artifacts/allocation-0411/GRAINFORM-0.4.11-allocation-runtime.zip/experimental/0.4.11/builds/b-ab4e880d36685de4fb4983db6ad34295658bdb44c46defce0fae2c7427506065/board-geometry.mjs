// Shared logical dimensions. One material cell stays one logical pixel.
export const VERSION='0.4.11';
export const WIDTH=288, HEIGHT=512, BLOCK=24;
export const LEFT=28, RIGHT=WIDTH-28, FLOOR=HEIGHT-12;
export const FIELD_WIDTH=RIGHT-LEFT, FIELD_HEIGHT=FLOOR;
export const BOARD=Object.freeze({width:WIDTH,height:HEIGHT,left:LEFT,right:RIGHT,floor:FLOOR,fieldWidth:FIELD_WIDTH,fieldHeight:FIELD_HEIGHT,cell:1});
// Additive early-game uplift; preserve level/piece ramp and the existing cap.
export const rigidFallSpeed=(level,pieces)=>180*Math.min(1.45,29/75+(level-1)*.065+Math.min(.4,pieces*.002));
