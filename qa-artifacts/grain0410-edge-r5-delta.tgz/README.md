# GRAINFORM 0.4.10 edge-contour-r5: adjacent descent

Unpublished physical-rule candidate over frozen r4. This intentionally changes the sand's lateral mobility and final pile geometry. It is not an exact-trajectory continuation of049/r4. Only ca-world.mjs changes among the ten runtime files: a grain may slip only into the immediately adjacent column with a free cell below it. The former identity-dependent two-cell crossing over a supported shoulder is no longer allowed.

## Scope and visual tradeoff

The true horizontal-then-down unit path is retained; no diagonal cuts through supporting cells, grain deletion, image blur or contour expansion were introduced. The17-phase rule layout, four material rules per fixed60Hz control frame, velocities, credits, reservation checks, sleeping/waking and final-clear barriers remain. The now-unused second horizontal stage stays a hold, preserving the path format and time budget. The legacy roughness function remains for identity diagnostics but no longer grants longer physical slips. Identity-based render texture is unchanged.

R3 dirty-tile batching, r4 fixed-timeline selection, all contour/glyph/rim parameters and rendering code are byte-identical. No compensating speedup or extra rule was added.

Same-seed offline first/rotated-second-drop comparison:
- First:2304 grains; settling35/60s unchanged; width121→107cells; height40→41cells.
- Second:4608 grains; settling83/60→84/60s; width164→136cells (−17.1%); height63→67cells.
- Overall height/half-width angle proxy37.53°→44.58° for the second mound. This is an aspect-ratio measure, not a fitted physical angle of repose.

The pile is more compact/steep and lateral travel is shorter. At original CSS size, inspected worst subphase images show substantially less prominent attached horizontal tooth rows while retaining particle-scale roughness. This is offline evidence only. Real browser motion must still determine whether the user's original complaint is adequately addressed, especially early steep sides and potential overly rigid/pointed appearance.

The rule is not uniformly faster to settle: in the23-drop input sequence, high-density control steps302→326(+7.9%) and all23 drops1278→1403(+9.8%). In the six-drop natural-clear sequence, the sixth drop127→146steps(+15.0%). Both still naturally clear2304 and retain11520 of13824 added grains. Fixed clock rate did not change; these are actual modeled-flow differences and must be disclosed.

## New validation contract

The old551-frame049/r4 exact trajectory equality is intentionally invalid for r5. Original validation-reference files and old merge-parity.mjs are preserved unchanged for historical use, and exact r4 source copies accompany collision comparisons. No golden final positions were edited to manufacture agreement.

Use npm test (68 inherited flow/clock/render/gate tests), verify:slots (320 reuse cycles), verify:motion, verify:collisions, verify:pixels, verify:pixels:browser and verify:browser.

verify:motion is a new independent input-driven Map oracle. It reconstructs IDs/occupancy from explicit births/removals and audited unit movements, checks local nearest-neighbour legality/depth/reservations, every frame's ID/color/batch/occupancy conservation, natural multicolor clears, reuse and support-cut recovery. It also exhausts local direction decisions independently. This is an admissibility/conservation oracle, not a second full simulator or proof that every eligible move occurred. For compatibility, verify:parity now invokes this explicitly labelled new oracle; it does not claim the old551 comparison passed.

verify:collisions separately uses analytic relative-motion interval intersection for axis-aligned unit squares through every phase. It covers single/double support, opposing/following slides, one-cell passage/bridge aperture and68-phase frame paths, plus deliberately colliding oracle counterexamples. It compares six onehop fixtures with six frozen-r4 fixtures while expressly allowing the intended shoulder-crossing difference. The narrow-passage proof is finite-time transit through real initially-resting grains, not an assertion that sand walls remain permanently rigid.

The existing252 exact pixel-reference fixture draws remain valid for identical supplied poses; they do not imply the newly generated physical trajectories equal r4.

## Cost and external acceptance

The hot change reduces direction search from up to two horizontal cells to exactly one and removes its identity-hash lookup. No extra loop, collision solver, per-frame world traversal or retained cache was added. Same-input Node no-render runs both reached52992 grains without top-out or conservation failure. Timing is only a local computational sanity check, never browser FPS or DPR performance proof; changed trajectories and machine variation prevent an exact isolated speedup claim.

Browser QA must use complete independent r4/r5 roots and actual ACKed inputs. Review continuous first/second-drop videos at DPR1/1.5/2, middle-flow connected tooth rows, natural micrograin texture, footprint/steepness and elapsed settling time. Do not select only smooth subphases or final stills. Recheck mixed-color clears, solitary grains, one-cell channels, natural pause/reset/visibility and final true-alpha1 barrier before clear. High-density timing must separate real settling activity from input/falling gaps and report peak/last-active debt, draw-start gaps and CPU tails. No blanket60fps claim or publication is included.
