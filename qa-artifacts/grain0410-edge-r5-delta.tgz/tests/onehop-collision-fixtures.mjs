// Independent, small collision/conservation fixtures. No production source writes.
// Oracle: continuous interiors of axis-aligned unit squares must never overlap.
// Touching boundaries are legal. This is NOT an old/new trajectory-equivalence test.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { World as OneHopWorld, CFG } from '../ca-world.mjs';
import { FrameWorld as OneHopFrameWorld } from '../ca-frame-world.mjs';
import { World as OldWorld } from './legacy-r4/ca-world.mjs';
import { FrameWorld as OldFrameWorld } from './legacy-r4/ca-frame-world.mjs';

const root = new URL('./', import.meta.url);
const sourceNames = [
  '../ca-world.mjs', '../ca-frame-world.mjs',
  './legacy-r4/ca-world.mjs', './legacy-r4/ca-frame-world.mjs',
];
function hashes() {
  return Object.fromEntries(sourceNames.map(name => [name, createHash('sha256').update(readFileSync(new URL(name, root))).digest('hex')]));
}
const initialHashes = hashes();
const output = {
  scope: 'Independent small fixtures for one-hop descent and frozen r4 reference. No full-run equivalence or visual-acceptance claim.',
  oracle: {
    bodies: 'Axis-aligned unit squares centered on integer cell coordinates (a common +0.5 translation changes no collision result).',
    exactContinuousCheck: 'For every pair and every unit phase, intersect the open time intervals |dx0+dvx*t|<1 and |dy0+dvy*t|<1 with t in [0,1]. A nonempty interval means penetration. This is analytic relative-motion testing, not time sampling.',
    boundaries: 'Boundary contact is allowed; interior overlap is forbidden. Every actual movement must be a downward or horizontal axis-aligned unit leg.',
    conservation: 'All live IDs, counts, full grid occupancy, and mass are checked at each step. The dual-support release explicitly removes exactly one named support between two separately conserved episodes.',
    narrowPassage: 'A finite two-rule transit test. Corridor/roof grains begin at rest and have insufficient movement credit to move during those two rules; this is verified. They are not secretly pinned or removed. No claim of a permanently rigid sand wall is made.',
  },
  sourceHashes: initialHashes,
  oracleSelfTests: [],
  fixtures: [],
};

function axisInterval(d0, dv) {
  if (dv === 0) return Math.abs(d0) < 1 ? [-Infinity, Infinity] : null;
  const a = (-1 - d0) / dv, b = (1 - d0) / dv;
  return a < b ? [a, b] : [b, a];
}
function overlapInterval(a0, a1, b0, b1) {
  const x = axisInterval(a0[0] - b0[0], a1[0] - a0[0] - b1[0] + b0[0]);
  const y = axisInterval(a0[1] - b0[1], a1[1] - a0[1] - b1[1] + b0[1]);
  if (!x || !y) return null;
  const lo = Math.max(0, x[0], y[0]), hi = Math.min(1, x[1], y[1]);
  return lo < hi ? { lo, hi, witnessTime: (lo + hi) / 2 } : null;
}
function selfTest(name, actual, expected) {
  assert.equal(Boolean(actual), expected, name);
  output.oracleSelfTests.push({ name, pass: true, penetrationExpected: expected, interval: actual });
}
selfTest('Reject illegal diagonal shortcut through a supporting square', overlapInterval([0, 0], [1, 1], [0, 1], [0, 1]), true);
selfTest('Detect opposite moves with nonoverlapping endpoints but interior collision', overlapInterval([0, 0], [2, 0], [2, 0], [0, 0]), true);
selfTest('Detect relative collision between perpendicular moving grains', overlapInterval([0, 0], [1, 0], [1, 1], [1, 0]), true);
selfTest('Allow horizontally touching follower pair at equal velocity', overlapInterval([0, 0], [1, 0], [1, 0], [2, 0]), false);
selfTest('Allow exact unit-width passage between stationary side grains', overlapInterval([11, 410], [11, 411], [10, 411], [10, 411]), false);
selfTest('Reject independent fast/slow warps in a shared L corridor', overlapInterval([1, 0], [1, 0.25], [1.5, 1], [1.75, 1]), true);

function add(w, points, vy = 0) {
  const prior = new Set(w.snapshot().map(p => p.id));
  w.admit(points, 1, 1, vy);
  return w.snapshot().filter(p => !prior.has(p.id)).map(p => p.id);
}
function pos(w, id) { const i = w.slotOf(id); return [w.x[i], w.y[i]]; }
function checkGrid(w, expectedCount) {
  assert.equal(w.count, expectedCount, 'world count');
  const snapshot = w.snapshot(), occupied = new Set();
  assert.equal(snapshot.length, expectedCount, 'live snapshot count');
  let gridCount = 0;
  for (let q = 0; q < w.grid.length; q++) {
    if (!w.grid[q]) continue;
    gridCount++;
    const i = w.grid[q] - 1;
    assert.equal(w.live[i], 1, 'grid points to a live slot');
    assert.equal(w.cell(w.x[i], w.y[i]), q, 'grid and live slot agree');
  }
  assert.equal(gridCount, expectedCount, 'full grid occupied count');
  for (const p of snapshot) {
    assert.ok(Number.isInteger(p.x) && Number.isInteger(p.y));
    assert.ok(p.x >= 0 && p.x < CFG.width && p.y >= 0 && p.y < CFG.height);
    const key = `${p.x},${p.y}`;
    assert.ok(!occupied.has(key), 'unique occupied cell'); occupied.add(key);
    assert.equal(w.grid[w.cell(p.x, p.y)], w.slotOf(p.id) + 1);
  }
  return snapshot;
}
function runStep(w, record, frame = false) {
  const before = checkGrid(w, w.count), beforeIds = before.map(p => p.id).sort((a, b) => a - b);
  const count = w.count, audit = [];
  w.audit = (id, x0, y0, x1, y1, phase) => audit.push({ id, x0, y0, x1, y1, phase, ruleTick: w.tick });
  const startTick = w.tick;
  if (frame) w.stepFrame(); else w.step();
  w.audit = null;
  const after = checkGrid(w, count);
  assert.deepEqual(after.map(p => p.id).sort((a, b) => a - b), beforeIds, 'IDs conserved throughout the episode');
  const horizon = frame ? 68 : 17;
  const paths = before.map(p => {
    const i = w.slotOf(p.id), valid = frame ? w.frameStamp[i] === w.frame : w.pathStamp[i] === w.tick;
    const n = valid ? (frame ? w.frameN[i] : w.pathN[i]) : 0;
    const base = i * (frame ? 69 : 18), xs = frame ? w.frameX : w.pathX, ys = frame ? w.frameY : w.pathY, phases = frame ? w.framePhase : w.pathPhase;
    const points = n ? Array.from({ length: n }, (_, j) => [xs[base + j], ys[base + j], phases[base + j]]) : [[p.x, p.y, 0]];
    assert.deepEqual(points[0], [p.x, p.y, 0], 'path starts at actual starting cell');
    for (let j = 1; j < points.length; j++) {
      const a = points[j - 1], b = points[j];
      assert.ok(Number.isInteger(b[2]) && b[2] > a[2] && b[2] <= horizon, 'ordered actual phase');
      assert.equal(Math.abs(b[0] - a[0]) + Math.abs(b[1] - a[1]), 1, 'one axis-aligned unit leg');
      assert.ok(b[1] >= a[1], 'no upward leg');
    }
    assert.deepEqual(points.at(-1).slice(0, 2), pos(w, p.id), 'path reaches actual endpoint');
    return { id: p.id, points };
  });
  const recordedLegs = paths.flatMap(p => p.points.slice(1).map((point, j) => ({ id: p.id, x0: p.points[j][0], y0: p.points[j][1], x1: point[0], y1: point[1], phase: point[2] })));
  const normalize = row => [row.id, row.x0, row.y0, row.x1, row.y1, row.phase].join(',');
  const auditedLegs = audit.map(row => ({ ...row, phase: row.phase + (frame ? (row.ruleTick - startTick - 1) * 17 : 0) }));
  assert.deepEqual(recordedLegs.map(normalize).sort(), auditedLegs.map(normalize).sort(), 'every physical audit leg appears exactly once in presentation path');
  const poses = paths.map(p => ({ id: p.id, xy: p.points[0].slice(0, 2), next: 1, points: p.points }));
  let pairPhaseChecks = 0;
  for (let phase = 1; phase <= horizon; phase++) {
    const starts = poses.map(p => [...p.xy]);
    const ends = poses.map(p => p.next < p.points.length && p.points[p.next][2] === phase ? p.points[p.next].slice(0, 2) : [...p.xy]);
    const endpointCells = new Set();
    for (let i = 0; i < poses.length; i++) {
      const key = ends[i].join(','); assert.ok(!endpointCells.has(key), 'unique phase-end occupancy'); endpointCells.add(key);
      for (let j = i + 1; j < poses.length; j++) {
        pairPhaseChecks++;
        const overlap = overlapInterval(starts[i], ends[i], starts[j], ends[j]);
        assert.equal(overlap, null, `continuous square penetration: IDs ${poses[i].id}/${poses[j].id} phase ${phase}: ${JSON.stringify(overlap)}`);
      }
    }
    poses.forEach((p, i) => { p.xy = ends[i]; if (p.next < p.points.length && p.points[p.next][2] === phase) p.next++; });
  }
  const step = { kind: frame ? 'four-rule material frame' : 'single rule', startTick, endTick: w.tick, phases: horizon, particleCount: count, mass: count * CFG.massPerCell, pairPhaseChecks, actualUnitLegs: audit.length, before, after, paths, pass: true };
  record.steps.push(step);
  return step;
}
function fixture(model, name, construct, Frame = null) {
  const record = { model: model.name, name, steps: [], assertions: [], pass: false };
  output.fixtures.push(record);
  try {
    construct(new (Frame ?? model.World)(), record, model.name === 'onehop');
    record.pass = true;
  } catch (error) { record.error = error.stack; }
  return record;
}
const models = [
  { name: 'onehop', World: OneHopWorld, Frame: OneHopFrameWorld },
  { name: 'frozen-r4-reference', World: OldWorld, Frame: OldFrameWorld },
];
for (const model of models) {
  fixture(model, 'single-support-slide', (w, r) => {
    add(w, [{ x: 10, y: 419 }]);
    const [grain] = add(w, [{ x: 10, y: 418 }], 480);
    runStep(w, r);
    const p = pos(w, grain);
    assert.equal(p[1], 419); assert.equal(Math.abs(p[0] - 10), 1);
    assert.equal(r.steps[0].paths.find(p => p.id === grain).points.length, 3);
    r.assertions.push('One supported grain takes exactly H1 then D1, with unchanged two-grain count.');
  });
  fixture(model, 'double-support-shoulder-and-release', (w, r, onehop) => {
    add(w, [{ x: 0, y: 419 }]);
    const [grain] = add(w, [{ x: 0, y: 418 }], 480);
    const [releasedSupport] = add(w, [{ x: 1, y: 419 }]);
    assert.equal(w.roughness(grain), 2, 'reference grain is a genuine legacy two-hop candidate');
    const beforeDirection = w.direction(w.slotOf(grain), 1, false);
    runStep(w, r);
    if (onehop) {
      assert.equal(beforeDirection, null); assert.deepEqual(pos(w, grain), [0, 418]);
      r.assertions.push('A two-cell shoulder is not crossed while the adjacent landing cell is supported.');
    } else {
      assert.equal(beforeDirection.dist, 2); assert.deepEqual(pos(w, grain), [2, 419]);
      r.assertions.push('Reference intentionally differs: the ID-1 grain crosses two shoulder cells. No equivalence claim.');
    }
    const priorIds = w.snapshot().map(p => p.id), priorCount = w.count;
    w.remove([releasedSupport]);
    checkGrid(w, priorCount - 1);
    assert.deepEqual(w.snapshot().map(p => p.id), priorIds.filter(id => id !== releasedSupport));
    r.explicitFixtureEdit = { action: 'release exactly the adjacent bottom support', removedId: releasedSupport, fromCount: priorCount, toCount: w.count };
    runStep(w, r);
    if (onehop) assert.deepEqual(pos(w, grain), [1, 419]);
    r.assertions.push(onehop ? 'After the explicit support release, the one-hop grain is no longer trapped and reaches the now-open adjacent landing cell. Each episode conserves every remaining ID.' : 'After the explicit support release, the reference grain stays at its already-reached two-hop endpoint. Each episode conserves every remaining ID.');
  });
  fixture(model, 'opposing-slides-one-shared-landing', (w, r) => {
    add(w, [8, 9, 10, 12, 13, 14].map(x => ({ x, y: 419 })));
    const grains = add(w, [{ x: 10, y: 418 }, { x: 12, y: 418 }], 480);
    runStep(w, r);
    assert.equal(grains.filter(id => pos(w, id)[0] === 11 && pos(w, id)[1] === 419).length, 1);
    assert.equal(grains.filter(id => pos(w, id)[1] === 418).length, 1);
    r.assertions.push('Exactly one opposing grain wins the shared landing; the other remains supported. No transient penetration or duplicate occupancy.');
  });
  fixture(model, 'following-slides-shared-vacated-cell', (w, r, onehop) => {
    add(w, Array.from({ length: 12 }, (_, x) => ({ x, y: 419 })));
    add(w, [8, 9, 10].map(x => ({ x, y: 418 })));
    const [lower] = add(w, [{ x: 11, y: 418 }], 480);
    const [upper] = add(w, [{ x: 10, y: 417 }], 480);
    runStep(w, r);
    assert.deepEqual(pos(w, lower), [12, 419]);
    const upperPath = r.steps[0].paths.find(p => p.id === upper).points;
    assert.deepEqual(upperPath.slice(0, 3), [[10, 417, 0], [11, 417, 9], [11, 418, 11]]);
    if (onehop) assert.deepEqual(pos(w, upper), [11, 418]);
    else {
      assert.deepEqual(pos(w, upper), [13, 419]);
      r.intentionalModelDifference = 'After the same collision-safe follow into the vacated cell, frozen r4 permits a further two-cell shoulder crossing to (13,419). Onehop remains at (11,418).';
    }
    r.assertions.push('The upper grain legally follows into the lower grain’s vacated source cell. Analytic relative-motion checks cover their complete overlapping swept corridors.');
  });
  fixture(model, 'one-cell-channel-through-roof-aperture', (w, r) => {
    const corridor = [];
    for (let y = 410; y <= 419; y++) corridor.push({ x: 10, y }, { x: 12, y });
    corridor.push({ x: 9, y: 410 }, { x: 13, y: 410 });
    const walls = add(w, corridor), wallStarts = walls.map(id => [id, pos(w, id)]);
    const payload = add(w, [{ x: 11, y: 409 }, { x: 11, y: 407 }], 480);
    for (let step = 0; step < 2; step++) {
      runStep(w, r);
      for (const [id, start] of wallStarts) assert.deepEqual(pos(w, id), start, 'corridor and roof stay stationary during the transit window');
      for (const id of payload) assert.equal(pos(w, id)[0], 11, 'remain inside the exact one-cell channel');
    }
    assert.deepEqual(payload.map(id => pos(w, id)), [[11, 419], [11, 418]]);
    assert.equal(w.count, 24);
    r.assertions.push('Both payload grains cross the exact one-cell roof aperture and reach the downstream end within two rules; no deletion, size reduction, artificial solidification, or wall pinning. All 24 grains are conserved.');
    r.limitation = 'Finite transit guarantee only. At-rest granular walls can move in later rules once they accumulate enough gravity credit; this fixture does not assert rigid terrain or perpetual aperture stability.';
  });
  fixture(model, 'frameworld-four-rule-path-continuity', (w, r) => {
    add(w, [{ x: 10, y: 419 }]);
    const [grain] = add(w, [{ x: 10, y: 418 }], 480);
    runStep(w, r, true);
    assert.equal(pos(w, grain)[1], 419);
    assert.equal(w.framePending, true, 'physics does not self-acknowledge final presentation');
    assert.equal(w.ready(), false, 'pending presentation blocks readiness');
    w.completePresentation();
    assert.equal(w.framePending, false);
    r.assertions.push('All 68 frame phases are checked, including holds across rule boundaries. Pending presentation blocks readiness until completePresentation is explicitly called.');
  }, model.Frame);
}
output.finalSourceHashes = hashes();
assert.deepEqual(output.finalSourceHashes, initialHashes, 'all imported candidate and frozen reference sources stayed unchanged');
output.summary = {
  pass: output.fixtures.every(f => f.pass),
  fixtures: output.fixtures.length,
  passed: output.fixtures.filter(f => f.pass).length,
  failed: output.fixtures.filter(f => !f.pass).length,
  oracleSelfTests: output.oracleSelfTests.length,
  analyticPairPhaseChecks: output.fixtures.flatMap(f => f.steps).reduce((n, s) => n + s.pairPhaseChecks, 0),
  actualUnitLegs: output.fixtures.flatMap(f => f.steps).reduce((n, s) => n + s.actualUnitLegs, 0),
  productionSourcesUnchanged: true,
  visualAcceptanceEstablished: false,
};
writeFileSync(new URL('../evidence/onehop-collision-fixtures.json', root), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(output.summary, null, 2));
for (const f of output.fixtures) console.log(`${f.pass ? 'PASS' : 'FAIL'} ${f.model}: ${f.name}${f.error ? `\n${f.error}` : ''}`);
if (!output.summary.pass) process.exitCode = 1;
