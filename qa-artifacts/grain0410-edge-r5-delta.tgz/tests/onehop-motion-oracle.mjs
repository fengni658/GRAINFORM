/**
 * Input-driven, deliberately small motion oracle for the one-hop material rule.
 * Run: node motion-oracle.mjs
 * Relocating into candidate/tests only requires changing the next two defaults.
 * Optional environment overrides are paths relative to THIS FILE, not cwd.
 * This is a legality/conservation oracle, not a full replacement simulator.
 */
const TARGET_ROOT = new URL(process.env.MOTION_ORACLE_ROOT || '../', import.meta.url);
const OUTPUT = new URL(process.env.MOTION_ORACLE_OUTPUT || '../evidence/onehop-motion-oracle.json', import.meta.url);
const {World, CFG} = await import(new URL('ca-world.mjs', TARGET_ROOT));
const {Game} = await import(new URL('game.mjs', TARGET_ROOT));
const {writeFileSync} = await import('node:fs');
const {createHash} = await import('node:crypto');
const W = 232, H = 420, CAPACITY = W * H;
function assert(ok, message) { if (!ok) throw Error(message); }
assert(CFG.width === W && CFG.height === H, 'unexpected domain');
const key = (x, y) => `${x},${y}`;
const inside = (x, y) => Number.isInteger(x) && Number.isInteger(y) && x >= 0 && x < W && y >= 0 && y < H;
const empty = (occupied, x, y) => inside(x, y) && !occupied.has(key(x, y));

// Independent declarative nearest-neighbour rule. There is no call to candidate
// empty(), direction(), roughness(), grid access, velocity, or move scheduling.
function nearestDirection(occupied, reserved, x, y, dx, useReservations = true) {
  const target = [x + dx, y], landing = [x + dx, y + 1];
  if (!empty(occupied, ...target) || !empty(occupied, ...landing)) return null;
  if (useReservations && (reserved.has(key(...target)) || reserved.has(key(...landing)))) return null;
  const column = Array.from({length: 8}, (_, n) => empty(occupied, x + dx, y + 1 + n));
  const stop = column.indexOf(false);
  return {dx, dist: 1, depth: stop === -1 ? 8 : stop};
}

class MotionOracle {
  constructor(name, world) {
    this.name = name;
    this.world = world;
    this.occupied = new Map();
    this.particles = new Map();
    this.freeHandles = [];
    this.nextFresh = 0;
    this.tick = null;
    this.lastPhase = new Map();
    this.pendingSlide = new Map();
    this.reservationPhase = null;
    this.reserved = new Set();
    this.colorsBorn = new Map();
    this.colorsRemoved = new Map();
    this.stats = {births: 0, removals: 0, reusedHandles: 0, unitMoves: 0, verticalLegs: 0, horizontalLegs: 0, slideDescents: 0, snapshotChecks: 0, snapshotParticleChecks: 0, directionPreferenceChecks: 0, secondHorizontalLegs: 0, maxLive: 0, admissionCalls: 0, removalCalls: 0};
    assert(world.count === 0, `${name}: oracle must start from empty input state`);
    const admit = world.admit.bind(world), remove = world.remove.bind(world);
    world.admit = (points, color, batch, initialVy = 0) => {
      // Birth expectations come exclusively from the submitted input. The public
      // generation/slot handle contract is modelled with a plain free-handle stack.
      const input = points.map(p => ({x: p.x, y: p.y, color, batch}));
      const seen = new Set();
      for (const p of input) {
        assert(inside(p.x, p.y) && empty(this.occupied, p.x, p.y) && !seen.has(key(p.x, p.y)), `${name}: invalid birth input`);
        seen.add(key(p.x, p.y));
      }
      const result = admit(points, color, batch, initialVy);
      for (const p of input) {
        const reused = this.freeHandles.length > 0;
        const id = reused ? this.freeHandles.pop() + CAPACITY : this.nextFresh++;
        assert(!this.particles.has(id), `${name}: duplicate birth ID ${id}`);
        this.particles.set(id, {...p, id});
        this.occupied.set(key(p.x, p.y), id);
        this.stats.births++;
        this.stats.reusedHandles += Number(reused);
        this.colorsBorn.set(color, (this.colorsBorn.get(color) || 0) + 1);
      }
      this.stats.admissionCalls++;
      this.stats.maxLive = Math.max(this.stats.maxLive, this.particles.size);
      this.compareSnapshot('birth');
      return result;
    };
    world.remove = ids => {
      const input = [...ids];
      assert(new Set(input).size === input.length && input.every(id => this.particles.has(id)), `${name}: invalid removal input`);
      this.endRuleStep();
      const result = remove(input);
      for (const id of input) {
        const p = this.particles.get(id);
        assert(this.occupied.get(key(p.x, p.y)) === id, `${name}: removal source mismatch`);
        this.occupied.delete(key(p.x, p.y));
        this.particles.delete(id);
        this.freeHandles.push(id);
        this.stats.removals++;
        this.colorsRemoved.set(p.color, (this.colorsRemoved.get(p.color) || 0) + 1);
      }
      this.stats.removalCalls++;
      this.compareSnapshot('remove');
      return result;
    };
    world.audit = (id, ox, oy, x, y, phase) => this.onMove(id, ox, oy, x, y, phase);
  }
  onMove(id, ox, oy, x, y, phase) {
    const tick = this.world.tick;
    if (this.tick !== tick) {
      this.endRuleStep();
      this.tick = tick;
      this.lastPhase.clear();
      this.reserved.clear();
      this.reservationPhase = null;
    }
    const prefix = `${this.name} tick=${tick} id=${id} phase=${phase}`;
    const p = this.particles.get(id);
    assert(p && p.x === ox && p.y === oy && this.occupied.get(key(ox, oy)) === id, `${prefix}: source/ID mismatch`);
    assert(inside(ox, oy) && inside(x, y), `${prefix}: out of bounds`);
    assert(empty(this.occupied, x, y), `${prefix}: occupied destination`);
    const dx = x - ox, dy = y - oy;
    assert(Math.abs(dx) + Math.abs(dy) === 1 && dy >= 0, `${prefix}: non-unit/upward path`);
    assert(Number.isInteger(phase) && phase > (this.lastPhase.get(id) || 0), `${prefix}: unordered phase`);
    assert(![10, 13, 16].includes(phase), `${prefix}: forbidden second horizontal leg`);
    if (dx !== 0) {
      assert([9, 12, 15].includes(phase) && dy === 0 && Math.abs(dx) === 1, `${prefix}: invalid horizontal phase`);
      assert(inside(ox, oy + 1) && this.occupied.has(key(ox, oy + 1)), `${prefix}: unsupported horizontal source`);
      assert(empty(this.occupied, x, y + 1), `${prefix}: horizontal crosses a shoulder`);
      assert(!this.pendingSlide.has(id), `${prefix}: slide without completed descent`);
      const reservationPhase = `${tick}:${phase}`;
      if (reservationPhase !== this.reservationPhase) {
        assert(this.pendingSlide.size === 0, `${prefix}: incomplete previous slide round`);
        this.reserved.clear();
        this.reservationPhase = reservationPhase;
      }
      const chosen = nearestDirection(this.occupied, this.reserved, ox, oy, dx);
      const other = nearestDirection(this.occupied, this.reserved, ox, oy, -dx);
      assert(chosen && (!other || chosen.depth >= other.depth), `${prefix}: illegal/reserved/lower-depth selected direction`);
      this.reserved.add(key(x, y));
      this.reserved.add(key(x, y + 1));
      this.pendingSlide.set(id, {x, y, descentPhase: phase + 2});
      this.stats.horizontalLegs++;
      this.stats.directionPreferenceChecks++;
    } else {
      assert(dy === 1, `${prefix}: invalid vertical leg`);
      if (phase >= 9) {
        const slide = this.pendingSlide.get(id);
        assert(slide && phase === slide.descentPhase && ox === slide.x && oy === slide.y, `${prefix}: unpaired slide descent`);
        this.pendingSlide.delete(id);
        this.stats.slideDescents++;
      } else {
        assert(phase >= 1 && phase <= 8 && !this.pendingSlide.has(id), `${prefix}: invalid gravity phase`);
      }
      this.stats.verticalLegs++;
    }
    this.occupied.delete(key(ox, oy));
    this.occupied.set(key(x, y), id);
    p.x = x; p.y = y;
    this.lastPhase.set(id, phase);
    this.stats.unitMoves++;
  }
  endRuleStep() { assert(this.pendingSlide.size === 0, `${this.name}: unfinished horizontal-then-down move`); }
  compareSnapshot(label = 'frame') {
    this.endRuleStep();
    const actual = this.world.snapshot();
    assert(actual.length === this.particles.size && actual.length === this.world.count && this.occupied.size === this.particles.size, `${this.name} ${label}: count/lost-grain mismatch`);
    const ids = new Set(), cells = new Set(), colors = new Map();
    for (const a of actual) {
      const e = this.particles.get(a.id), k = key(a.x, a.y);
      assert(e && !ids.has(a.id) && !cells.has(k), `${this.name} ${label}: duplicate/unknown particle or cell`);
      assert(a.x === e.x && a.y === e.y && a.color === e.color && a.batch === e.batch && this.occupied.get(k) === a.id, `${this.name} ${label}: independent snapshot mismatch ${a.id}`);
      assert(inside(a.x, a.y), `${this.name} ${label}: snapshot bounds`);
      ids.add(a.id); cells.add(k);
      colors.set(a.color, (colors.get(a.color) || 0) + 1);
    }
    for (const [color, born] of this.colorsBorn) assert((colors.get(color) || 0) + (this.colorsRemoved.get(color) || 0) === born, `${this.name}: color conservation ${color}`);
    assert(this.stats.births - this.stats.removals === actual.length, `${this.name}: global conservation`);
    this.stats.snapshotChecks++;
    this.stats.snapshotParticleChecks += actual.length;
  }
  summary() {
    this.compareSnapshot('final');
    const canonical = [...this.particles.values()].sort((a, b) => a.id - b.id).map(p => [p.id, p.x, p.y, p.color, p.batch]);
    return {name: this.name, ...this.stats, ruleSteps: this.world.metrics.stepCalls, live: this.particles.size, colorsBorn: Object.fromEntries(this.colorsBorn), colorsRemoved: Object.fromEntries(this.colorsRemoved), conservation: this.stats.births - this.stats.removals === this.particles.size, stateSha256: createHash('sha256').update(JSON.stringify(canonical)).digest('hex')};
  }
}

function exhaustDirectionDecisions() {
  const world = new World();
  const positions = [[116, 200], [0, 200], [231, 200], [116, 411], [116, 418], [116, 419]];
  let cases = 0, decisions = 0, illegal = 0;
  const depths = new Set();
  // 11 Boolean occupancy cells: immediate target plus eight cells below it,
  // and both old two-cell shoulder destinations. Two independent reservation
  // bits, on/off reservation mode, both directions, walls and floor boundaries.
  for (const [x, y] of positions) for (const dx of [-1, 1]) {
    const cells = [[x + dx, y], ...Array.from({length: 8}, (_, n) => [x + dx, y + 1 + n]), [x + 2 * dx, y], [x + 2 * dx, y + 1]];
    world.x[0] = x; world.y[0] = y;
    for (let mask = 0; mask < 2 ** cells.length; mask++) {
      const occupied = new Map();
      for (let i = 0; i < cells.length; i++) {
        const [xx, yy] = cells[i];
        if (!inside(xx, yy)) continue;
        const on = !!(mask & (1 << i));
        world.grid[yy * W + xx] = on ? 1 : 0;
        if (on) occupied.set(key(xx, yy), true);
      }
      for (let reservationMask = 0; reservationMask < 4; reservationMask++) {
        world.reserveEpoch++;
        const reserved = new Set();
        for (let bit = 0; bit < 2; bit++) if (reservationMask & (1 << bit)) {
          const xx = x + dx, yy = y + bit;
          if (inside(xx, yy)) { reserved.add(key(xx, yy)); world.reserveStamp[yy * W + xx] = world.reserveEpoch; }
        }
        for (const useReservations of [false, true]) {
          const expected = nearestDirection(occupied, reserved, x, y, dx, useReservations);
          const actual = world.direction(0, dx, useReservations);
          assert(JSON.stringify(actual) === JSON.stringify(expected), `direction mismatch x=${x} y=${y} dx=${dx} mask=${mask} reserved=${reservationMask} mode=${useReservations}`);
          cases++;
          if (actual) { decisions++; depths.add(actual.depth); } else illegal++;
        }
      }
    }
    for (const [xx, yy] of cells) if (inside(xx, yy)) world.grid[yy * W + xx] = 0;
  }
  return {cases, legalDirections: decisions, rejectedDirections: illegal, depthsCovered: [...depths].sort((a, b) => a - b), occupancyBits: 11, reservationBits: 2, positions, independentExpected: 'Map occupancy plus a contiguous eight-cell Boolean depth column'};
}

function retainedR4ShoulderCounterexample() {
  // An isolated copy of the OLD two-cell policy for a particle with roughness=2.
  // No sibling baseline checkout is needed to rerun the candidate tests.
  function oldR4Direction(occupied, x, y, dx) {
    for (const dist of [1, 2]) {
      const xx = x + dx * dist;
      if (!empty(occupied, xx, y)) return null;
      if (!empty(occupied, xx, y + 1)) continue;
      let depth = 0;
      for (let yy = y + 1; yy < y + 9 && empty(occupied, xx, yy); yy++) depth++;
      return {dx, dist, depth};
    }
    return null;
  }
  const world = new World(), x = 100, y = 418;
  const occupied = new Map([[key(x, y), 1], [key(x, y + 1), 2], [key(x + 1, y + 1), 3], [key(x - 1, y), 4]]);
  world.x[0] = x; world.y[0] = y; world.reserveEpoch = 1;
  for (const k of occupied.keys()) { const [xx, yy] = k.split(',').map(Number); world.grid[yy * W + xx] = 1; }
  const oldDecision = oldR4Direction(occupied, x, y, 1);
  const oneHopExpected = nearestDirection(occupied, new Set(), x, y, 1);
  const candidateDecision = world.direction(0, 1, false);
  assert(oldDecision?.dist === 2 && oneHopExpected === null && candidateDecision === null, 'old two-cell shoulder counterexample lost');
  return {occupied: [...occupied.keys()], source: [x, y], oldR4RoughnessTwoPolicy: oldDecision, oneHopExpected, candidateDecision, intendedChange: 'Old roughness=2 may move across the supported immediate neighbour to a hole two cells away; one-hop must stay. No old trajectory-equivalence claim is made.', oldPolicyPath: [[100, 418, 0], [101, 418, 9], [102, 418, 10], [102, 419, 11]], oneHopPath: [[100, 418, 0]]};
}

function runRealGame() {
  const seed = 1, game = new Game({seed}), oracle = new MotionOracle('real-game-seed-1', game.world);
  const targets = [28, 212, 76, 164, 116, 28, 212, 52, 188, 116];
  const drops = [], clearEvents = [];
  const capturedEvents = new Set();
  const emit = game.emit.bind(game);
  game.emit = (type, data) => { emit(type, data); if (type === 'clear') { const e = game.events.at(-1); if (!capturedEvents.has(e.id)) { capturedEvents.add(e.id); clearEvents.push({...e}); } } };
  game.start();
  let frames = 0;
  // Includes a natural 4-neighbour spanning-component clear and two subsequent
  // real admissions, exercising generation IDs after actual Game removals.
  for (let n = 0; n < 26; n++) {
    assert(game.state === 'playing' && game.phase === 'falling', `game unavailable before drop ${n}`);
    const targetX = targets[n % targets.length];
    game.move(targetX - game.active.x);
    if (n % 3 === 1) game.rotate();
    const piece = {index: n + 1, color: game.active.color, targetX, rotate: n % 3 === 1, shape: game.active.shape.map(p => [...p]), x: game.active.x};
    assert(game.drop(), `real drop failed ${n}`);
    oracle.compareSnapshot('drop');
    let pieceFrames = 0;
    while (game.phase !== 'falling' && game.state === 'playing') {
      assert(pieceFrames < 1200, `game settlement did not complete ${n}`);
      game.step();
      oracle.compareSnapshot('control-frame');
      assert(game.world.count + game.rawCleared === game.added, 'real Game conservation');
      if (game.awaitingPresentation) assert(game.completePresentation(game.consumedToken + 1), 'presentation acknowledgement failed');
      frames++; pieceFrames++;
    }
    drops.push({...piece, frames: pieceFrames, live: game.world.count, rawCleared: game.rawCleared});
    if ((n + 1) % 6 === 0) console.log(`motion oracle: real Game ${n + 1}/26 drops, ${oracle.stats.unitMoves.toLocaleString()} unit moves, cleared ${game.rawCleared}`);
  }
  assert(clearEvents.length > 0 && game.rawCleared > 0 && oracle.stats.reusedHandles > 0, 'natural clear / post-clear ID reuse coverage missing');
  assert(oracle.colorsBorn.size === 4, 'real four-colour coverage missing');
  return {...oracle.summary(), seed, controls: {targets, rotateWhenZeroBasedIndexModulo3Equals: 1, input: 'Game.start, Game.move, Game.rotate, Game.drop, Game.step, Game.completePresentation'}, frames, pieces: game.pieces, rawCleared: game.rawCleared, clearEvents, drops};
}

function runSupportCut() {
  const world = new World(), oracle = new MotionOracle('input-built-multicolour-support-cut', world);
  const points = (x0, x1, y0, y1) => { const out = []; for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) out.push({x, y}); return out; };
  // The full-width foundation cannot spread sideways. Three blocks rest on it;
  // the lower 36-cell-height supports are later removed through the public API.
  world.admit(points(0, W - 1, 384, H - 1), 4, 10, 0);
  world.admit(points(24, 59, 372, 383), 1, 11, 0);
  world.admit(points(98, 133, 368, 383), 2, 12, 0);
  world.admit(points(172, 207, 372, 383), 3, 13, 0);
  let frames = 0;
  function settle() {
    let steps = 0;
    do {
      assert(steps++ < 1600, 'support-cut settlement failed');
      world.step(); oracle.compareSnapshot('rule-frame'); world.completePresentation(); frames++;
    } while (!world.ready());
    return steps;
  }
  const beforeFrames = settle();
  const beforeMoves = oracle.stats.unitMoves;
  const cutIds = [...oracle.particles.values()].filter(p => p.batch === 10 && p.x >= 70 && p.x <= 161).map(p => p.id);
  assert(cutIds.length === 92 * 36, 'support cut input geometry changed');
  const belowBefore = [...oracle.particles.values()].filter(p => p.batch === 12).map(p => ({id: p.id, y: p.y}));
  world.remove(cutIds);
  const afterFrames = settle();
  const descended = belowBefore.filter(p => oracle.particles.get(p.id).y > p.y).length;
  assert(descended > 0 && oracle.stats.unitMoves > beforeMoves, 'support cut failed to wake/move supported particles');
  const movesAfterCutBeforeRefill = oracle.stats.unitMoves - beforeMoves;
  // A final fresh input reuses removed slots; no expected state is read back.
  world.admit(points(108, 123, 40, 47), 2, 14, 480);
  const refillFrames = settle();
  return {...oracle.summary(), frames, beforeFrames, afterFrames, refillFrames, cutCount: cutIds.length, formerlySupportedParticles: belowBefore.length, descendedAfterCut: descended, movesAfterCutBeforeRefill, note: 'Geometry is admitted from explicit test inputs; removal IDs are selected from the independent oracle by known batch and cut rectangle.'};
}

console.log('r5 independent onehop admissibility/conservation oracle; not historical 551-frame trajectory equality');
const started = Date.now();
const directionExhaustion = exhaustDirectionDecisions();
console.log(`motion oracle: ${directionExhaustion.cases.toLocaleString()} independent direction cases passed`);
const shoulderCounterexample = retainedR4ShoulderCounterexample();
const realGame = runRealGame();
const supportCut = runSupportCut();
const runs = [realGame, supportCut];
const total = fields => Object.fromEntries(fields.map(field => [field, runs.reduce((sum, run) => sum + run[field], 0)]));
const report = {
  schema: 'onehop-motion-oracle-v1', pass: true,
  candidateRoot: TARGET_ROOT.href,
  method: 'A Map keyed by integer coordinates and a Map keyed by opaque-generation IDs start empty, receive only explicit admission/removal inputs, and replay actual audit events after validating each unit leg against their own previous state. Every control/rule frame is compared to the actual snapshot. Actual snapshots never populate expected motion state.',
  assertions: ['source coordinate and ID agree', 'destination is in bounds and empty', 'ID, color and batch preserved except explicit births/removals', 'vertical legs are exactly down one', 'horizontal legs are exactly +/- one with support below source and emptiness below destination', 'no phases 10/13/16', 'slide descent pairs with its horizontal leg', 'per-particle phases strictly increase', 'selection never chooses a shallower legal direction', 'reservations reconstructed independently from accepted paths', 'no duplicate IDs/cells or lost grains', 'per-colour and global conservation after every frame'],
  limitations: ['This small oracle validates emitted moves and final occupancy; it does not prove every eligible move was emitted or independently reproduce velocity/credit/chunk scheduling or random tie breaks.', 'The legacy contrast is an inline isolated r4 roughness=2 direction policy, not a claim of full trajectory equivalence.', 'Swept/interpolated collision fixtures are maintained separately.'],
  directionExhaustion, shoulderCounterexample,
  totals: {...total(['frames', 'ruleSteps', 'births', 'removals', 'reusedHandles', 'unitMoves', 'verticalLegs', 'horizontalLegs', 'slideDescents', 'snapshotChecks', 'snapshotParticleChecks', 'directionPreferenceChecks', 'secondHorizontalLegs']), conservation: runs.every(r => r.conservation)},
  runs, elapsedMs: Date.now() - started,
};
writeFileSync(OUTPUT, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({pass: report.pass, output: OUTPUT.pathname, totals: report.totals, elapsedMs: report.elapsedMs}, null, 2));
