# GRAINFORM 0.4.10 UI micro candidate

2026-10-09. Separate candidate copied from frozen r10. No publish, upload or deploy. No physical, queue, contour, presentation or scheduling changes.

## Runtime delta

Only `app.mjs` differs among the 10 manifest runtime files; the other 9 are byte-identical. The original r10 directory still matches its runtime manifest. All recursive candidate differences are in `DIFF-MANIFEST.json`; runtime comparisons are in `RUNTIME-COMPARISON.json`.

- Cache static HUD nodes, six text-node groups and five touch buttons.
- Compare text, boolean DOM properties, dataset, ARIA and slow class before writing.
- Compare the last raw progress-width target because CSSOM may normalize fractional percentages.
- Construct final artificial-QA strings before the single text comparison.
- Evaluate touch permission once per updateUI and reuse pending-start within that invocation.
- Preserve all updateUI call sites, input-status direct paths, announce/release/focus ordering, QA 400ms output, actual pending/hidden/dialog reads and frame requests.

`MINIMAL-RUNTIME.patch` is the app-only patch. `TESTS.patch` contains test changes. package.json is unchanged, so the new differential test is an explicit separate command; it is not included in the prior 76-test npm result. Copied candidate RUNTIME-MANIFEST.json and historical reports are r10 provenance, not the micro candidate's new integrity source; use the external comparison manifests above.

## Passed checks, separate scopes

1. Existing aggregate `npm test`: exit 0, 76/76, 6373.984503ms. Existing `npm-test.log` and `npm-test.exitcode` preserved, not rerun during differential-test recovery. This aggregate includes the improved real-runtime mocked-DOM boot smoke; it does not include the newly created UI differential test.
2. `node --test candidate/tests/ui-dedup.test.mjs` from this bundle root: exit 0, 7/7, 1149.211388ms. See `ui-dedup.log` and `ui-dedup.exitcode`.
3. Node syntax checks for app.mjs and the new differential test: exit 0.

The differential harness executes byte-identical frozen r10 app source and candidate app source with the same controlled worker messages and instrumented mock DOM. Renderer and presentation queue are lightweight stubs. Tests compare final full mock-DOM/QA/storage state and ordered external effects after each scripted step. They also instrument UI entry counts and DOM setter/query counts. The reference app fixture SHA256 is asserted in the test.

Coverage: 49 independent-dependency checkpoints; falling/settling/flash pause/resume with ACK-first and snapshot-first paths; hidden and live dialog state; clear announcements and repeated event IDs; over focus with/without a dialog; restart/new epochs/stale messages; failure; settings and palette/redraw calls; storage success/failure/reset/cross-tab paths; exact ARIA; direct input-status paths; QA output at strict >400ms; artificial text and rounded fractional CSSOM width.

## Observed call counts, not CPU savings

For each 20 accepted stable snapshots, updateUI remains 20 calls:

- Falling: DOM write calls 600 -> 0; all DOM queries 680 -> 20; activeInputAllowed calls 100 -> 20.
- Settling: DOM write calls 600 -> 0; all DOM queries 580 -> 0; activeInputAllowed calls 100 -> 20.
- Flash: DOM write calls 600 -> 0; all DOM queries 580 -> 0; activeInputAllowed calls 100 -> 20.
- Ten unchanged artificial-QA direct UI updates: 320 writes -> 0, including 10 original progress-width writes -> 0.

These are deterministic mock instrumentation counts. They do not measure DOM mutations, layout work, actual browser CPU, frame budgets, FPS or the original 102.1ms gap. Each real value transition still writes as needed. Real browser DOM/focus/ARIA comparison and performance verification remain with the parent. No additional trace or heavy benchmark was run here.

Both patches pass `patch --dry-run -p1` against the unchanged frozen r10 directory (exit 0). An initial dry-run invocation used an incorrect relative patch path and exited 1 before reading/applying any patch; that command error is retained in `patch-dry-run.initial-path-error.*`.
