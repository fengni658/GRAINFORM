# Independent dynamic-paint allocation micro

Only ca-layer.mjs differs from frozen r10. No UI, contour, physics, cache schedule, queue, ACK, particle-count or rate change. Not a combined/frozen product revision; not uploaded.

The cached dynamic pass now iterates the original moving Set directly, resolves each existing body once, and passes presented x/y scalars to tinyGrain. It skips missing bodies exactly as the old map/filter. Fallback retains bodies Map iteration order and uses presented coordinates too. Stable paint calls do not receive positions. Raw cell x-.5 and circle x+dx operations retain their order, zero coordinates are not truthy-fallback cases, style/tint and paintRank order remains unchanged. Selection retains default body coordinates.

Structural allocation reduction per cached draw: removes four temporary arrays (moving spread, mapped bodies, filtered bodies, dynamic bodies) and one body clone for each painted body with a presented position. Fallback removes one dynamic array and the corresponding positioned-body clones. No claim of zero allocations for the frame: queue sample, synchronize, contour and static work remain. No GC, CPU percentage or real Chrome speed improvement has been established.

Equivalence scope is the production synchronous pure resolveColor function. Old code captured the entire batch before painting; the new iterator reads each item when used. A custom callback that re-enters and mutates the body/position collections is outside this equivalence claim. Worker events cannot interrupt the synchronous draw.

Completed results, with actual terminal statuses:
- Original r10 versus candidate:340 exact RGBA comparisons, zero differences, exit0.
- Expanded364 draws:2724962 exact Canvas method calls/property setters, same order and numeric arguments;364 RGBA comparisons zero differences;2680712 frozen-body checks plus serialized body/position/path invariance, exit0.
- Candidate incremental cache versus full-reference:340 exact RGBA, exit0 on completed rerun. Original startup-only pixels.log retained as incomplete, not claimed passed.
- Full7 slot groups including320 reuse cycles:exit0. Node76/76:exit0. Wrapper exit0. Logs recorded before resumption are retained, not rerun merely to duplicate results.

Coverage:intermediate alphas, standard/contrast palette, DPR1/1.5/2 and other sizes, stable dirty tiles, clipping/tile boundaries, delete/reuse generation, clear/reset, duplicate path IDs and missing body, zero coordinates, fallback/rawCells, selection/highlight. Nine other runtime hashes match frozen r10.

Reproduce rendering comparisons from replay/: node run-old-new-pixels.mjs; node command-parity.mjs. Scripts need the existing @napi-rs/canvas Node package; the two launchers currently point to the documented dot dependency root. Set up an equivalent dependency root when moving environments. The model tests/pixel-equivalence-node.mjs runs the separate340 full-reference suite with normal Node package resolution. No historical experiment directory is required. To replay76/slots, apply patch/ca-layer.mjs to a complete r10 copy and run node tests/run-test-gates.mjs <fresh-output-directory>.

This micro does not establish resolution of r10 Canvas19.8ms, warm worker21.3ms or cold main58.4ms peaks.
