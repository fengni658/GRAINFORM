# GRAINFORM 0.4.10 r11 experimental candidate

Based on frozen r10. Exactly two runtime files change: app.mjs (HUD/UI deduplication) and ca-layer.mjs (dynamic-paint temporary allocation removal). Other eight runtime hashes, including material world, worker, queue implementation, contour and motion paths, remain identical. No new movement tuning, particle reduction, refresh reduction or ACK change.

UI: cache static HUD nodes/groups/buttons; compare text/properties/dataset/ARIA/class/target width before writes; evaluate shared touch permission once per updateUI. Preserve update call sites and ordering, direct input-status paths, hidden/dialog live reads, focus/announcements, QA400ms output and settings/storage behavior. The independent7 UI differential tests are separate from the existing76-test aggregate and explicitly run by verify:r11.

Paint: remove four cached dynamic-pass arrays and per-positioned-body clones by iterating moving Set in its original order and passing exact x/y scalars. Fallback keeps bodies Map order; stable painting receives no positions. Default selection, missing-body filtering, zero coordinates, float arithmetic order, style/tint, dirty tiles and paintRank remain. Production resolveColor is a pure query. Callbacks that synchronously re-enter and mutate collections are outside equivalence; this is not a general reentrancy guarantee.

## Validation scopes
The unified tests/run-r11-gates.mjs runs each command independently, persists exit codes/signals/errors and returns nonzero for any failed gate. It does not infer success from an earlier PASS line.
- Base wrapper: original76 Node tests and full7 slots groups (including320 reuse), each exit0.
- UI differential:7/7, separate exit0. Compares original frozen r10 app with candidate mock-DOM state and ordered effects; covers independent dependencies, pause/resume/ACK order, focus/over/clear/reset/stale epochs, failure, settings/storage, ARIA/direct paths and CSSOM normalization.
- Original r10 paint versus candidate:340 exact RGBA, zero differences, exit0.
- Expanded paint:364 exact RGBA and2724962 exact Canvas commands/property writes;2680712 frozen-body checks plus body/position/path serialization invariance, exit0. Includes DPR1/1.5/2 and additional sizes, palette changes, phases, dirty tiles, deletion/reuse, clear/reset, missing and duplicate path IDs, coordinate0, fallback/rawCells and selection.
- Candidate incremental cache versus full-reference:340 exact RGBA, exit0.
- Separate short native worker protocol/final endpoint gate tests: exit0 (also covered in76 aggregate).

These are correctness results, not measured GC/CPU savings. UI structural counts and paint allocation reduction were established in separate micro reports; composition does not prove actual browser performance.

## Known risks retained
r10 real QA had twentieth settling1.837/1.835s, but draw rates59.9/50.7/s. A second-round Canvas draw19.8ms, warm worker peak21.3ms and cold main58.4ms remained. r11 must independently measure these budgets and debt after composition; this report does not erase or attribute them. Earlier102ms scheduling/delivery gap has no proven root cause. No promise of steady60FPS or eliminated GC stalls.

Replay: npm run verify:r11 -- <fresh-output-directory>. Existing npm test remains the original76; npm run verify:ui-dedup is the explicit new7. Paint/raster scripts require @napi-rs/canvas. Their recorded dot installation is /opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules; normal full-reference suite uses Node package resolution. Independent unpack verification checks imports and runs UI/worker tests. Candidate runtime integrity is RUNTIME-MANIFEST.json, not copied r10 historical manifests.

Experimental candidate only. Parent owns independent Chromium review and any subsequent publication; no GitHub or Sites action performed here.
