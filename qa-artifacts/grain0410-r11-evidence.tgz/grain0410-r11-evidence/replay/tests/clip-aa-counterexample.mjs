import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
const require=createRequire(import.meta.url),{createCanvas}=require('@napi-rs/canvas');
function paint(c,clip){c.setTransform(2,0,0,2,0,0);c.fillStyle='#eac370';if(clip){c.save();c.setTransform(1,0,0,1,0,0);c.beginPath();c.rect(32,32,32,32);c.clip();c.setTransform(2,0,0,2,0,0);}c.beginPath();c.arc(31.67,31.67,.61,0,Math.PI*2);c.fill();if(clip)c.restore();}
const reference=createCanvas(576,864),clipped=createCanvas(576,864);paint(reference.getContext('2d'),false);paint(clipped.getContext('2d'),true);
const a=reference.getContext('2d').getImageData(60,60,4,4).data,b=clipped.getContext('2d').getImageData(60,60,4,4).data;
const differences=[];for(let i=0;i<a.length;i++)if(a[i]!==b[i])differences.push({channelOffset:i,reference:a[i],clipped:b[i]});
const result={backend:'existing @napi-rs/canvas',sampleDeviceRect:{x:60,y:60,width:4,height:4},clipDeviceRect:{x:32,y:32,width:32,height:32},arcWorld:{x:31.67,y:31.67,radius:.61},scale:2,differences,conclusion:'Integer device clipping changes antialias coverage for this arc; use uncut same-origin scratch raster and exact pixel copy.'};
await writeFile(new URL('../evidence/clip-aa-counterexample.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
