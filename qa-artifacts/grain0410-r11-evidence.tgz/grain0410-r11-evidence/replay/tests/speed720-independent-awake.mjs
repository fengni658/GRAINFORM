// Self-contained fixed-720 independent full-awake test. Only dependency: candidate ca-world.mjs.
// Default for final model/tests placement: ../ca-world.mjs. Optional argv[2]: target path from cwd.
import assert from 'node:assert/strict';
import {resolve} from 'node:path'; import {pathToFileURL} from 'node:url';
const input=process.argv[2]?pathToFileURL(resolve(process.argv[2])):new URL('../ca-world.mjs',import.meta.url);
const {World}=await import(input.href);
const W=232,H=420,CAP=720,FPS=240,G=900;
// Independent full-awake sparse occupancy engine. Does not import old or new Q/move/direction/step.
class Ref{
 constructor(){this.tick=0;this.n=0;this.seed=0x842199;this.ps=new Map();this.cells=new Map();this.events=[]}
 key(x,y){return y*W+x} empty(x,y){return x>=0&&x<W&&y>=0&&y<H&&!this.cells.has(this.key(x,y))}
 admit(pts,color,batch,v0){for(const {x,y}of pts){const id=this.n++;this.ps.set(id,{id,x,y,color,batch,v0,birth:this.tick,path:[[x,y]]});this.cells.set(this.key(x,y),id)}}
 remove(ids){for(const id of ids){const p=this.ps.get(id);this.cells.delete(this.key(p.x,p.y));this.ps.delete(id)}}
 floorQ(v0,n){n=BigInt(Math.max(0,n));const s=BigInt(Math.round(v0*100)),d=72000n-s;if(750n*n<=2n*d)return(4n*s*n+750n*n*n)/96000n;return(54000000n*n-d*d)/18000000n}
 random(){let s=this.seed;s^=s<<13;s^=s>>>17;s^=s<<5;this.seed=s>>>0;return this.seed/4294967296}
 side(p,dx){if(!this.empty(p.x+dx,p.y)||!this.empty(p.x+dx,p.y+1))return null;let depth=0;for(let yy=p.y+1;yy<=p.y+8&&this.empty(p.x+dx,yy);yy++)depth++;return{dx,depth}}
 step(){this.tick++;this.events=[];const ps=[...this.ps.values()].sort((a,b)=>b.y-a.y+0||((this.tick%2)?a.x-b.x:b.x-a.x));for(const p of ps){const age=this.tick-p.birth;let budget=Number(this.floorQ(p.v0,age)-this.floorQ(p.v0,age-1));assert.ok(budget>=0&&budget<=3);p.path=[[p.x,p.y]];let slips=0;while(budget>0){let dx=0;if(!this.empty(p.x,p.y+1)){if(slips>=3||p.y+1>=H)break;const l=this.side(p,-1),r=this.side(p,1);if(!l&&!r)break;dx=!l?r.dx:!r?l.dx:l.depth>r.depth?l.dx:r.depth>l.depth?r.dx:this.random()<.5?-1:1;slips++}const ox=p.x,oy=p.y;this.cells.delete(this.key(ox,oy));p.x+=dx;p.y++;this.cells.set(this.key(p.x,p.y),p.id);p.path.push([p.x,p.y]);this.events.push([p.id,ox,oy,p.x,p.y,p.path.length-1]);budget--}}}
 snapshot(){return[...this.ps.values()].map(({id,x,y,color,batch})=>({id,x,y,color,batch}))}
 positionAt(id,alpha){const p=this.ps.get(id),t=alpha*17,whole=Math.floor(t),path=p.path;if(whole>=path.length-1)return[path.at(-1)[0]+.5,path.at(-1)[1]+.5];const j=Math.max(0,whole),u=t-j;return[path[j][0]+(path[j+1][0]-path[j][0])*u+.5,path[j][1]+(path[j+1][1]-path[j][1])*u+.5]}
}
const reports=[];let totalEvents=0,pathComparisons=0;
function run(name,points,v0,prepare,steps){const a=new World(),b=new Ref();a.admit(points,1,1,v0);b.admit(points,1,1,v0);let events=[];a.audit=(...e)=>events.push(e);let visited=0,passed=0,woken=0,maxParticleActions=0;function step(stage){events=[];a.step();b.step();assert.deepEqual(events,b.events,name+'/'+stage+' actions');assert.deepEqual(a.snapshot(),b.snapshot(),name+'/'+stage+' state');assert.equal(a.seed,b.seed);const per=new Map();for(const e of events){const n=(per.get(e[0])||0)+1;per.set(e[0],n);assert.ok(n<=3);maxParticleActions=Math.max(maxParticleActions,n)}for(const p of a.snapshot())for(const alpha of[0,.025,.07,.13,.25,.5,1]){assert.deepEqual(a.positionAt(p.id,alpha),b.positionAt(p.id,alpha));pathComparisons++}totalEvents+=events.length;visited+=a.frontStats.visited;passed+=a.frontStats.passed;woken+=a.frontStats.woken}
 prepare(a,b,step);for(let k=0;k<steps;k++)step(k);reports.push({name,points:points.length,birthSpeed:v0,steps,visited,passed,woken,maxParticleActions,pass:true});console.log(JSON.stringify(reports.at(-1)))}
function cone(){const pts=[];for(let y=376;y<420;y++)for(let x=116-(y-376);x<=116+(y-376);x++)pts.push({x,y});return pts}
for(const parity of[0,1])run('aged-cone-'+(parity?'reverse':'forward'),cone(),parity?261:43.2,(a,b,step)=>{for(let k=0;k<3;k++)step('settle');assert.equal(a.chunks.size,0);a.tick=b.tick=256+parity;const ids=a.snapshot().filter(p=>p.y===419&&p.x>=112&&p.x<128).map(p=>p.id);a.remove(ids);b.remove(ids)},8);
for(const reverse of[false,true]){const pts=[],holes=reverse?[222,223]:[16,17];for(let x=0;x<W;x++)if(!holes.includes(x))pts.push({x,y:419});for(let x=reverse?223:0;x<=(reverse?231:16);x++)for(const y of[417,418])pts.push({x,y});run('passed-pending-'+(reverse?'reverse':'forward'),pts,reverse?0:480,(a,b)=>{a.tick=b.tick=256+(reverse?1:0);a.chunks.clear();a.chunks.add(a.chunk(reverse?223:16,418));for(let i=0;i<a.n;i++)if(!a.chunks.has(a.chunk(a.x[i],a.y[i])))assert.ok(!a.empty(a.x[i],a.y[i]+1)&&!a.direction(i,-1,false)&&!a.direction(i,1,false))},4)}
const result={oracle:'Independent sparse full-awake engine; exact BigInt rational Q integral for cap720, gravity900, dt1/240. No copied or modified old oracle.',totalEvents,pathComparisons,reports,pass:true};console.log(JSON.stringify(result,null,2));
