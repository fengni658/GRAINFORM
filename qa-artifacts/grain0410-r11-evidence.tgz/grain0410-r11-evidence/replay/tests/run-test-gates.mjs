// Exit status, not the presence of an earlier PASS line, determines gate success.
import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const out=path.resolve(process.argv[2]??path.join(root,'evidence/test-gates'));
fs.mkdirSync(out,{recursive:true});
const results=[];
for(const [name,args] of [['slots',['run','verify:slots']],['node',['test']]]){
 const r=spawnSync('npm',args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});
 fs.writeFileSync(path.join(out,`${name}.log`),(r.stdout??'')+(r.stderr??''));
 const result={name,command:['npm',...args],exitCode:r.status,signal:r.signal,error:r.error?.message??null,passed:r.status===0&&!r.signal&&!r.error};
 results.push(result);
 console.log(JSON.stringify(result));
}
const passed=results.every(r=>r.passed);
fs.writeFileSync(path.join(out,'exit-status.json'),JSON.stringify({passed,results},null,2)+'\n');
process.exitCode=passed?0:1;
