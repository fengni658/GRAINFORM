import test from 'node:test';
import assert from 'node:assert/strict';
import { MaterialFrameQueue, MATERIAL_FRAME_MS, CALayerRenderer, positionOnPath, validateMaterialFrame } from '../ca-layer.mjs';
import { Game } from '../game.mjs';
import { createSimulationRuntime } from '../simulation-worker.mjs';

const D = MATERIAL_FRAME_MS;
const leg = (id, x, y, dx = 0, dy = 1, end = 68) => ({ id, points: [x, y, 0, x + dx, y + dy, end] });
const frame = (token, { final = false, paths = [leg(1, 30.5, 19.5 + token)] } = {}) => ({
  token, ruleTick: token * 4, phases: 68, durationMs: D, requiresEndpointDraw: final, paths,
});
const close = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-9, `${actual} != ${expected}`);
const receipt = (token, endpointDrawn, epoch = 1) => ({ epoch, token, ruleTick: token * 4, endpointDrawn });
const tokens = q => q.queue.map(f => f.token);

test('20ms selects the actual second interval at alpha .2; sampling alone consumes nothing', () => {
  const q = new MaterialFrameQueue();
  const a = frame(1), b = frame(2);
  q.accept(1, [a, b], 0);
  const plan = q.sample(20);
  assert.equal(plan.index, 1);
  assert.equal(plan.frame, b);
  close(plan.alpha, .2);
  assert.deepEqual(plan.displayQueue, [b]);
  assert.deepEqual(plan.prefix, [a, b]);
  assert.deepEqual(tokens(q), [1, 2]);
  assert.equal(q.read().consumedToken, 0);
  assert.equal(q.read().presentedToken, 0);
  assert.deepEqual(q.didDraw(plan), [receipt(1, false)]);
  assert.deepEqual(tokens(q), [2]);
  close(q.startedAt, D);
  assert.equal(q.read().consumedToken, 1);
  assert.equal(q.read().presentedToken, 0);
  assert.equal(q.read().consumedWithoutEndpoint, 1);
  assert.equal(q.didDraw(plan), null, 'A successful plan cannot commit twice');
});

test('34ms draws the second endpoint and returns two strictly ordered, differently typed receipts', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1), frame(2)], 0);
  const plan = q.sample(34);
  assert.equal(plan.index, 1);
  assert.equal(plan.alpha, 1);
  assert.deepEqual(q.didDraw(plan), [receipt(1, false), receipt(2, true)]);
  assert.equal(q.queue.length, 0);
  assert.equal(q.read().consumedToken, 2);
  assert.equal(q.read().presentedToken, 2);
  assert.equal(q.read().maxConsumedPerDraw, 2);
  assert.equal(q.read().endpointDraws, 1);
  close(q.startedAt, 2 * D);
});

test('before a boundary, no frame is consumed; a lone overdue frame still needs a successful draw', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1)], 0);
  assert.equal(q.didDraw(), null);
  const partial = q.sample(8);
  assert.equal(partial.frame.token, 1);
  close(partial.alpha, 8 / D);
  assert.equal(q.didDraw(partial), null);
  assert.deepEqual(tokens(q), [1]);
  const final = q.sample(1000);
  assert.equal(final.alpha, 1);
  assert.equal(q.read().consumedToken, 0);
  assert.deepEqual(q.didDraw(final), [receipt(1, true)]);
});

test('failed or abandoned drawing cannot commit, and a later sample invalidates the abandoned plan', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1), frame(2)], 0);
  const abandoned = q.sample(20);
  assert.throws(() => { throw Error('Canvas draw failed'); }, /Canvas draw failed/);
  assert.deepEqual(tokens(q), [1, 2]);
  assert.equal(q.read().consumedToken, 0);
  assert.equal(q.didDraw(null), null);
  assert.equal(q.didDraw({ ...abandoned }), null, 'A copied or fabricated ticket is not a draw plan');
  const current = q.sample(21);
  assert.equal(q.didDraw(abandoned), null);
  assert.deepEqual(q.didDraw(current), [receipt(1, false)]);
});

test('a newly accepted successor invalidates an old plan whose displayQueue lacks that frame', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1)], 0);
  const old = q.sample(20);
  q.accept(1, [frame(2)], 20);
  assert.equal(q.didDraw(old), null, 'Old plan must not commit after a new body/path snapshot arrives');
  assert.deepEqual(tokens(q), [1, 2]);
  const current = q.sample(20);
  assert.equal(current.frame.token, 2);
  assert.deepEqual(q.didDraw(current), [receipt(1, false)]);
});

test('pause freezes selection and alpha, invalidates old plans, and resume shifts time exactly once', () => {
  const q = new MaterialFrameQueue();
  q.accept(7, [frame(1), frame(2)], 0);
  const beforePause = q.sample(20);
  q.setPaused(true, 20);
  assert.equal(q.didDraw(beforePause), null);
  const paused = q.sample(10000);
  assert.equal(paused.frame.token, 2);
  close(paused.alpha, .2);
  assert.deepEqual(paused.positions, beforePause.positions);
  q.setPaused(false, 10020);
  assert.equal(q.didDraw(paused), null);
  const resumed = q.sample(10020);
  close(resumed.alpha, .2);
  assert.deepEqual(q.didDraw(resumed), [receipt(1, false, 7)]);
  close(q.startedAt, 10000 + D);
  const later = q.sample(10034);
  assert.equal(later.alpha, 1);
  assert.deepEqual(q.didDraw(later), [receipt(2, true, 7)]);
});

test('reset and epoch changes isolate paths and all stale draw plans', () => {
  const q = new MaterialFrameQueue();
  q.accept(7, [frame(1), frame(2)], 0);
  const stale = q.sample(34);
  q.reset(8);
  assert.equal(q.didDraw(stale), null);
  assert.equal(q.accept(7, [frame(1)], 35), false);
  assert.equal(q.queue.length, 0);
  assert.equal(q.startedAt, null);
  q.accept(8, [frame(1, { final: true })], 100);
  close(q.sample(100).alpha, 0);
  assert.equal(q.didDraw(stale), null);
  assert.deepEqual(q.didDraw(q.sample(117)), [receipt(1, true, 8)]);
  assert.equal(q.startedAt, null);
});

test('intermediate starvation preserves the original next interval; final barrier ends that episode', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1)], 0);
  q.didDraw(q.sample(20));
  assert.equal(q.queue.length, 0);
  close(q.startedAt, D);
  q.accept(1, [frame(2, { final: true })], 25);
  const late = q.sample(25);
  close(late.alpha, .5);
  assert.equal(q.didDraw(late), null);
  assert.deepEqual(q.didDraw(q.sample(34)), [receipt(2, true)]);
  assert.equal(q.startedAt, null);
  q.accept(1, [frame(3)], 500);
  close(q.sample(500).alpha, 0);
  close(q.startedAt, 500);
});

test('a final barrier can be selected partway through but is never consumed before its endpoint draw', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1), frame(2, { final: true })], 0);
  assert.deepEqual(q.didDraw(q.sample(20)), [receipt(1, false)]);
  assert.deepEqual(tokens(q), [2]);
  assert.equal(q.read().presentedToken, 0);
  assert.throws(() => q.accept(1, [frame(3)], 21), /barrier/);
  const partial = q.sample(25);
  close(partial.alpha, .5);
  assert.equal(q.didDraw(partial), null);
  assert.deepEqual(tokens(q), [2]);
  assert.deepEqual(q.didDraw(q.sample(34)), [receipt(2, true)]);
  assert.equal(q.startedAt, null);
});

test('empty-path final barriers still require alpha-one drawing', () => {
  const q = new MaterialFrameQueue();
  q.accept(1, [frame(1, { final: true, paths: [] })], 0);
  const partial = q.sample(8);
  assert.deepEqual(partial.positions, []);
  assert.equal(q.didDraw(partial), null);
  assert.equal(q.queue.length, 1);
  assert.deepEqual(q.didDraw(q.sample(17)), [receipt(1, true)]);
});

test('buffer remains bounded at two and duplicates never consume an extra slot', () => {
  const q = new MaterialFrameQueue();
  const a = frame(1), b = frame(2);
  q.accept(1, [a, b], 0);
  q.accept(1, [a, b], 10);
  assert.deepEqual(tokens(q), [1, 2]);
  assert.throws(() => q.accept(1, [frame(3)], 12), /two frames/);
  assert.equal(q.read().maxPending, 2);
  q.didDraw(q.sample(20));
  q.accept(1, [frame(3)], 20);
  assert.deepEqual(tokens(q), [2, 3]);
  assert.equal(q.read().maxPending, 2);
  assert.throws(() => validateMaterialFrame({ ...frame(4), requiresEndpointDraw: 'yes' }), /barrier/);
});

class CellContext {
  cells = [];
  save() {}
  restore() {}
  fillRect(x, y, width, height) { this.cells.push([x + width / 2, y + height / 2]); }
}

test('selected displayQueue prevents old starts and future bodies contaminating all three moving-ID cases', () => {
  const first = frame(1, { paths: [leg(1, 30.5, 20.5), leg(2, 40.5, 20.5)] });
  const second = frame(2, { paths: [leg(1, 30.5, 21.5), leg(3, 50.5, 20.5)] });
  const bodies = [
    { id: 1, x: 30.5, y: 22.5, color: 1 },
    { id: 2, x: 40.5, y: 21.5, color: 1 },
    { id: 3, x: 50.5, y: 21.5, color: 2 },
    { id: 4, x: 60.5, y: 20.5, color: 2 },
  ];
  const q = new MaterialFrameQueue();
  q.accept(1, [first, second], 0);
  const plan = q.sample(20);
  const renderer = new CALayerRenderer({ rawCells: true, createCanvas: () => ({ getContext: () => null }) });
  renderer.apply({ reset: true, removed: [], upsert: bodies });
  renderer.synchronize(plan.displayQueue, plan);
  assert.deepEqual([...renderer.moving], [1, 3]);
  assert.equal(renderer.positions.has(2), false, 'First-only ID is now stationary at its endpoint');
  assert.deepEqual(renderer.positions.get(1), [30.5, 21.5]);
  assert.deepEqual(renderer.positions.get(3), [50.5, 20.5]);
  const screen = new CellContext();
  renderer.configure(288, 432, 'standard');
  renderer.draw(screen);
  assert.deepEqual(screen.cells, [[30.5, 21.5], [40.5, 21.5], [50.5, 20.5], [60.5, 20.5]]);
  assert.deepEqual(tokens(q), [1, 2], 'Rendering preparation itself does not consume');
});

test('successor is sampled along the original axis-separated legs without cutting through an obstacle', () => {
  const obstacle = [30.5, 21.5];
  const path = { id: 1, points: [30.5, 20.5, 0, 31.5, 20.5, 9, 31.5, 21.5, 11] };
  const first = frame(1, { paths: [leg(1, 30.5, 19.5)] });
  const second = frame(2, { paths: [path] });
  const original = structuredClone(path.points);
  validateMaterialFrame(second);
  const q = new MaterialFrameQueue();
  q.accept(1, [first, second], 0);
  for (let phase = 0; phase <= 68; phase += .125) {
    const plan = q.sample(D + D * phase / 68);
    assert.equal(plan.frame.token, 2);
    const [x, y] = plan.positions[0].xy;
    const expected = positionOnPath(path, phase / 68);
    close(x, expected[0]); close(y, expected[1]);
    const overlaps = Math.abs(x - obstacle[0]) < 1 - 1e-9 && Math.abs(y - obstacle[1]) < 1 - 1e-9;
    assert.equal(overlaps, false, `Unit cells overlap at phase ${phase}`);
  }
  assert.deepEqual(path.points, original);
  assert.deepEqual(tokens(q), [1, 2]);
  assert.deepEqual(positionOnPath(path, 8.5 / 68), [31, 20.5]);
  assert.deepEqual(positionOnPath(path, 10.5 / 68), [31.5, 21]);
});

function consumeUntilFinal(g, { max = 300 } = {}) {
  let middle = 0;
  for (let step = 0; step < max; step++) {
    assert.equal(g.step(), true);
    const f = g.pendingMaterialFrame;
    assert.ok(f && f.token === g.presentationToken);
    if (f.requiresEndpointDraw) return { final: f, middle };
    assert.equal(g.completePresentation(f.token, { endpointDrawn: false }), true);
    assert.equal(g.presentedToken, 0);
    assert.equal(g.world.framePending, true);
    assert.equal(g.world.ready(), false);
    middle++;
  }
  assert.fail('Actual CA failed to reach its final quiet barrier');
}

test('real Game may consume all middle frames, but final false ACK cannot unlock spawn', () => {
  const g = new Game({ seed: 1 });
  g.start(); g.drop();
  const { final, middle } = consumeUntilFinal(g);
  assert.ok(middle > 0);
  assert.equal(g.world.chunks.size, 0);
  assert.equal(g.phase, 'settling');
  const frozen = g.world.snapshot(), pieceId = g.pieceId;
  const consumed = g.consumedToken;
  assert.equal(g.completePresentation(final.token, { endpointDrawn: false }), false);
  assert.equal(g.consumedToken, consumed);
  assert.equal(g.presentedToken, 0);
  assert.equal(g.world.framePending, true);
  for (let i = 0; i < 5; i++) g.step();
  assert.equal(g.phase, 'settling');
  assert.equal(g.pieceId, pieceId);
  assert.equal(g.active, null);
  assert.deepEqual(g.world.snapshot(), frozen);
  assert.equal(g.completePresentation(final.token, { endpointDrawn: true }), true);
  assert.equal(g.consumedToken, final.token);
  assert.equal(g.presentedToken, final.token);
  assert.equal(g.world.presentedTick, final.ruleTick);
  assert.equal(g.world.framePending, false);
  g.step();
  assert.equal(g.phase, 'falling');
  assert.equal(g.pieceId, pieceId + 1);
});

test('real bridge cannot start clear after consumed-only final ACK; endpoint allows the original twelve-tick flash', () => {
  const g = new Game({ seed: 1 });
  g.state = 'playing'; g.phase = 'settling';
  const floor = Array.from({ length: 232 }, (_, i) => ({ x: 28 + i, y: 419, color: 1 }));
  const supported = Array.from({ length: 40 }, (_, i) => ({ x: 124 + i, y: 418, color: 2 }));
  assert.equal(g.world.addMany(floor).accepted, true);
  assert.equal(g.world.addMany(supported).accepted, true);
  g.added = 272;
  const { final } = consumeUntilFinal(g);
  assert.equal(g.completePresentation(final.token, { endpointDrawn: false }), false);
  for (let i = 0; i < 20; i++) g.step();
  assert.equal(g.phase, 'settling');
  assert.equal(g.pendingClear.length, 0);
  assert.equal(g.rawCleared, 0);
  assert.equal(g.world.count, 272);
  assert.equal(g.completePresentation(final.token, { endpointDrawn: true }), true);
  g.step();
  assert.equal(g.phase, 'flash');
  assert.equal(g.pendingClear.flat().length, 232);
  for (let i = 0; i < 11; i++) { g.step(); assert.equal(g.rawCleared, 0); }
  g.step();
  assert.equal(g.rawCleared, 232);
  assert.equal(g.world.count, 40);
  assert.equal(g.phase, 'settling');
  assert.equal(g.active, null, 'Post-clear support recovery needs its own final barrier');
});

test('Game keeps consumed and endpoint cursors distinct and rejects malformed, duplicate, future, and non-head receipts', () => {
  const g = new Game({ seed: 1 });
  g.start(); g.drop(); g.step(); g.step();
  assert.equal(g.presentationToken, 2);
  assert.equal(g.completePresentation(2, { endpointDrawn: true }), false);
  assert.equal(g.completePresentation(1, { endpointDrawn: 'yes' }), false);
  assert.equal(g.completePresentation(0, { endpointDrawn: false }), false);
  assert.equal(g.completePresentation(1, { endpointDrawn: false }), true);
  assert.equal(g.consumedToken, 1);
  assert.equal(g.presentedToken, 0);
  assert.equal(g.completePresentation(1, { endpointDrawn: true }), false);
  assert.equal(g.completePresentation(2, { endpointDrawn: true }), true);
  assert.equal(g.consumedToken, 2);
  assert.equal(g.presentedToken, 2);
  assert.equal(g.completePresentation(3, { endpointDrawn: true }), false);
  g.reset(4);
  assert.equal(g.consumedToken, 0);
  assert.equal(g.presentedToken, 0);
  assert.equal(g.completePresentation(1), false);
});

class RuntimeClock {
  t = 0;
  next = 0;
  timers = new Map();
  now = () => this.t;
  set = (callback, delay) => {
    const id = ++this.next;
    this.timers.set(id, { callback, at: this.t + delay });
    return id;
  };
  clear = id => this.timers.delete(id);
  to(target) {
    let callbacks = 0;
    while (this.timers.size) {
      const [id, timer] = [...this.timers].sort((a, b) => a[1].at - b[1].at)[0];
      if (timer.at > target + 1e-7) break;
      assert.ok(++callbacks < 10000, 'Timer loop must remain bounded');
      this.timers.delete(id);
      this.t = Math.max(this.t, timer.at);
      timer.callback();
    }
    this.t = Math.max(this.t, target);
  }
}

test('actual worker and Game distinguish consumption from endpoint proof through a full gap clear, with bounded buffers and conserved time', () => {
  const clock = new RuntimeClock(), messages = [], frames = new Map();
  const runtime = createSimulationRuntime({
    now: clock.now, timeOrigin: 1000, setTimer: clock.set, clearTimer: clock.clear,
    post: message => {
      const copy = structuredClone(message);
      messages.push(copy);
      if (copy.snapshot?.materialFrame) frames.set(`${copy.epoch}:${copy.snapshot.materialFrame.token}`, copy.snapshot.materialFrame);
    },
  });
  let commandId = 0;
  const command = (name, value) => runtime.receive({ type: 'command', id: ++commandId, epoch: runtime.epoch, pieceId: runtime.game?.pieceId, name, value });
  const ack = (token, endpointDrawn, epoch = runtime.epoch) => runtime.receive({ type: 'presented', token, endpointDrawn, epoch });
  const conserved = () => {
    const s = runtime.stats();
    assert.ok(Math.abs(s.clockConservationErrorMs) < 1e-6);
    close(s.simSeconds + s.debtSeconds, s.activeWallSeconds);
    assert.ok(s.pendingMaterialFrames <= 2);
    assert.ok(s.maxPendingMaterialFrames <= 2);
    assert.equal(messages.some(m => m.type === 'fatal'), false);
    return s;
  };
  try {
    runtime.receive({ type: 'init', qa: true });
    command('qa-bridge', { fixture: 'early-clear', seed: 1 });
    command('drop');
    assert.equal(runtime.game.phase, 'settling');
    assert.equal(runtime.game.added, 2488);
    clock.to(1000);
    let s = conserved();
    assert.equal(s.pendingMaterialFrames, 2);
    assert.equal(s.consumedToken, 0);
    assert.equal(s.presentedToken, 0);
    assert.equal(frames.get(`${runtime.epoch}:1`).requiresEndpointDraw, false);

    ack(2, false); // A non-head token cannot free a slot.
    ack(1, false, runtime.epoch - 1);
    ack(1, null);
    s = conserved();
    assert.equal(s.rejectedPresentationAcks, 3);
    assert.equal(s.pendingMaterialFrames, 2);
    assert.equal(s.consumedToken, 0);

    const stepsBefore = s.steps;
    ack(1, false);
    s = conserved();
    assert.equal(s.pendingMaterialFrames, 1, 'A consumed middle frame releases exactly one buffer slot');
    assert.equal(s.consumedToken, 1);
    assert.equal(s.presentedToken, 0);
    assert.equal(runtime.game.presentedToken, 0);
    clock.to(clock.t);
    s = conserved();
    assert.equal(s.pendingMaterialFrames, 2);
    assert.equal(s.steps, stepsBefore + 1, 'The worker uses the released credit without losing retained debt');

    let barrier = null;
    for (let attempt = 0; attempt < 300; attempt++) {
      s = conserved();
      if (!s.pendingMaterialFrames) { clock.to(clock.t + D); continue; }
      const head = frames.get(`${runtime.epoch}:${s.consumedToken + 1}`);
      assert.ok(head, 'Every consumed token must have a published full path frame');
      if (head.requiresEndpointDraw) { barrier = head; break; }
      ack(head.token, false);
      clock.to(clock.t);
      assert.equal(runtime.game.presentedToken, 0);
      assert.equal(runtime.game.rawCleared, 0);
    }
    assert.ok(barrier, 'Real CA must reach its final quiet barrier');
    assert.equal(runtime.game.world.chunks.size, 0);
    const beforeBarrier = conserved();
    ack(barrier.token, false);
    ack(barrier.token, null);
    clock.to(clock.t + 200);
    s = conserved();
    assert.equal(s.rejectedPresentationAcks, beforeBarrier.rejectedPresentationAcks + 2);
    assert.equal(s.pendingMaterialFrames, beforeBarrier.pendingMaterialFrames, 'Rejected barrier ACKs must not remove worker materialFrames');
    assert.equal(s.consumedToken, beforeBarrier.consumedToken);
    assert.equal(s.presentedToken, 0);
    assert.equal(s.steps, beforeBarrier.steps, 'No extra control tick may pass the blocked quiet barrier');
    assert.equal(runtime.game.phase, 'settling');
    assert.equal(runtime.game.pendingClear.length, 0);
    assert.equal(runtime.game.rawCleared, 0);
    assert.equal(runtime.game.world.count, 2488);

    ack(barrier.token, true);
    assert.equal(runtime.stats().presentedToken, barrier.token);
    assert.equal(runtime.game.presentedToken, barrier.token);
    assert.equal(runtime.game.world.presentedTick, barrier.ruleTick);
    clock.to(clock.t);
    assert.equal(runtime.game.rawCleared, 2488, 'Only real endpoint proof may release the original clear flow');
    assert.equal(runtime.game.world.count, 0);
    for (let attempt = 0; runtime.game.phase !== 'falling' && attempt < 10; attempt++) {
      s = conserved();
      if (s.pendingMaterialFrames) {
        const head = frames.get(`${runtime.epoch}:${s.consumedToken + 1}`);
        assert.ok(head);
        ack(head.token, head.requiresEndpointDraw);
      }
      clock.to(clock.t + D);
    }
    assert.equal(runtime.game.phase, 'falling');
    assert.ok(runtime.game.active);
    s = conserved();
    assert.equal(s.maxPendingMaterialFrames, 2);
    assert.ok(s.presentedToken >= barrier.token);

    const oldEpoch = runtime.epoch;
    command('restart', { seed: 2 });
    ack(1, true, oldEpoch);
    s = conserved();
    assert.equal(s.consumedToken, 0);
    assert.equal(s.presentedToken, 0);
    assert.equal(s.pendingMaterialFrames, 0);
    assert.equal(s.rejectedPresentationAcks, 1);
  } finally {
    runtime.dispose();
  }
});
