// Differential UI-only regression: real app source, controlled worker messages,
// instrumented mock DOM and light renderer/queue stubs. No browser timing claim.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
const baseline = readFileSync(new URL('./reference/ui/r10-app.mjs', import.meta.url), 'utf8');
const candidate = readFileSync(new URL('../app.mjs', import.meta.url), 'utf8');
const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const plain = value => JSON.parse(JSON.stringify(value));
const sourceHash = createHash('sha256').update(baseline).digest('hex');
assert.equal(sourceHash, '3a475e9bfa5102c131c0570eb2288f50b1b77fe6b81867e504d81e5d08886fb4');

async function harness(source, {qa = false} = {}) {
  let now = 0, rafId = 0, timerId = 0, worker, packetSeq = 0, packetEpoch = 1, storageFails = false;
  const nodes = new Map(), effects = [], writes = [], queries = [], rafs = new Map(), timers = new Map(), listeners = new Map(), storage = new Map();
  const counts = {ui:0,input:0,active:0};
  const effect = (...args) => effects.push(plain(args));
  const write = (id, name, value) => writes.push([id, name, value]);
  function classes(id) {
    const values = new Set();
    return {
      add(...names) { for (const name of names) {write(id, 'class.add', name); values.add(name);} },
      remove(...names) { for (const name of names) {write(id, 'class.remove', name); values.delete(name); if(name === 'held') effect('release-held', id);} },
      contains(name) {return values.has(name);},
      toggle(name, force) {const enabled = force === undefined ? !values.has(name) : !!force; write(id, 'class.toggle', `${name}:${enabled}`); if(enabled) values.add(name);else values.delete(name);return enabled;},
      values() {return [...values].sort();}
    };
  }
  class Context {
    setTransform(){} fillRect(){} clearRect(){effect('canvas-clear',this.id);} save(){} restore(){} translate(){} scale(){} beginPath(){} rect(){} clip(){}
    fill(){effect('canvas-fill',this.id,this.fillStyle);} drawImage(){} stroke(){}
  }
  class Element {
    constructor(id) {
      this.id=id;this.handlers=new Map();this.attrs=new Map();this.open=false;this.tagName=id.includes('Canvas')?'CANVAS':'BUTTON';this.width=id.startsWith('next')?192:576;this.height=id.startsWith('next')?128:864;this.context=new Context();this.context.id=id;this.classList=classes(id);
      this.dataset=new Proxy({}, {set:(o,k,v)=>{write(id,`dataset.${k}`,String(v));o[k]=String(v);return true;}});
      let width='';this.style={};Object.defineProperty(this.style,'width',{enumerable:true,get:()=>width,set:value=>{write(id,'style.width',String(value));width=String(value).endsWith('%')?`${Number(Number.parseFloat(value).toFixed(5))}%`:String(value);}});
      for(const [name, initial] of Object.entries({textContent:'',disabled:false,hidden:false,checked:false})) {
        let value=initial;Object.defineProperty(this,name,{enumerable:true,get:()=>value,set:next=>{value=name==='textContent'?String(next??''):!!next;write(id,name,value);if(id==='announcer'&&name==='textContent')effect('announce',value);if(id==='qaOutput'&&name==='textContent')effect('qa-output',JSON.parse(value));}});
      }
    }
    setAttribute(name,value){value=String(value);write(this.id,`attr.${name}`,value);this.attrs.set(name,value);}
    getAttribute(name){return this.attrs.get(name)??null;}
    addEventListener(name,fn){this.handlers.set(name,fn);}
    focus(options){document.activeElement=this;effect('focus',this.id,options??null);}
    showModal(){this.open=true;effect('dialog-open',this.id);}
    close(){this.open=false;effect('dialog-close',this.id);}
    closest(){return get('settingsDialog');}
    setPointerCapture(id){effect('pointer-capture',this.id,id);}
    getContext(){return this.context;}
    getBoundingClientRect(){return {width:288,height:432};}
  }
  const get=id=>{if(!nodes.has(id))nodes.set(id,new Element(id));return nodes.get(id);};
  for(const match of html.matchAll(/\bid="([^"]+)"/g))get(match[1]);
  const buttons=['left','right','rotate','down','drop'].map(action=>{const b=get(`control-${action}`);b.dataset.action=action;return b;});
  const dialogs=['settingsDialog','helpDialog','restartDialog'].map(get);
  const groups=new Map(Object.entries({score:2,level:2,cleared:1,pieces:1,best:3,'best-label':3}).map(([name,count])=>[`[data-${name}]`,Array.from({length:count},(_,i)=>get(`data-${name}-${i}`))]));
  const document={getElementById:id=>{queries.push(`id:${id}`);return get(id);},querySelectorAll:selector=>{queries.push(selector);return selector==='#touchControls button'?buttons:selector==='dialog'?dialogs:selector==='dialog[open]'?dialogs.filter(d=>d.open):groups.get(selector)??[];},documentElement:get('html'),body:get('body'),hidden:false,activeElement:null,addEventListener:(name,fn)=>listeners.set(`document:${name}`,fn),createElement:()=>new Element('cache')};
  class Renderer {synchronize(){}apply(){}configure(w,h,palette){effect('palette',palette);}draw(){effect('draw');}drawSelection(){}read(){return {};}fallback(reason){effect('fallback',reason);}}
  class Queue {constructor(){this.queue=[];this.pausedAt=null;}reset(epoch){this.queue=[];effect('presentation-reset',epoch);}sample(){return null;}accept(epoch,frames){effect('presentation-accept',epoch,frames);}setPaused(paused,t){this.pausedAt=paused?t:null;effect('presentation-pause',paused,t);}didDraw(){return null;}read(){return {pending:this.queue.length,paused:this.pausedAt!==null};}}
  class Worker {constructor(){worker=this;}postMessage(message){effect('post',message);}}
  const window={addEventListener:(name,fn)=>listeners.set(`window:${name}`,fn)};
  const context=vm.createContext({console,document,window,Worker,URL,URLSearchParams,structuredClone,Map,Set,Math,Number,String,JSON,Uint32Array,performance:{now:()=>now,timeOrigin:1000},location:{search:qa?'?qa&seed=1':'?seed=1',reload:()=>effect('reload')},localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>{if(storageFails)throw Error('blocked storage');storage.set(key,String(value));effect('storage-set',key,String(value));}},matchMedia:()=>({matches:false}),devicePixelRatio:1,requestAnimationFrame:fn=>{const id=++rafId;rafs.set(id,fn);effect('raf-request',id);return id;},cancelAnimationFrame:id=>{rafs.delete(id);effect('raf-cancel',id);},setTimeout:(fn,delay)=>{const id=++timerId;timers.set(id,{fn,delay});effect('timer-set',id,delay);return id;},clearTimeout:id=>{timers.delete(id);effect('timer-clear',id);},CALayerRenderer:Renderer,MaterialFrameQueue:Queue,__counts:counts});
  const expose=`window.__uiTest = {
    updateUI, updateInputStatus, pause, resume, openDialog, closeDialog, fail, handleEvents, applySettings, saveSettings,
    patch(value) {
      if ('snapshot' in value) snapshot = {...snapshot, ...value.snapshot};
      if ('diagnostics' in value) diagnostics = {...diagnostics, ...value.diagnostics};
      if ('ready' in value) ready = value.ready;
      if ('failed' in value) failed = value.failed;
      if ('pauseRequested' in value) pauseRequested = value.pauseRequested;
      if ('pauseReason' in value) pauseReason = value.pauseReason;
      if ('awaitingFull' in value) bodyStore.awaitingFull = value.awaitingFull;
      if ('best' in value) best = value.best;
      if ('savedBest' in value) savedBest = value.savedBest;
      if ('storageAvailable' in value) storageAvailable = value.storageAvailable;
      if ('pending' in value) { pending.clear(); for (const [i,name] of value.pending.entries()) pending.set(100+i,{name,resolve:()=>{},sentAt:performance.now(),epoch}); }
    }
  };`;
  source=source.replace(/^import .*\n/, '').replace(/\bexport /g,'').replaceAll('import.meta.url',JSON.stringify('file:///grainform/app.mjs'))
    .replace('function updateUI() {','function updateUI() { __counts.ui++;')
    .replace('function updateInputStatus() {','function updateInputStatus() { __counts.input++;')
    .replace('function activeInputAllowed() {','function activeInputAllowed() { __counts.active++;')
    .replace('window.grainformQA = qa;',`${expose}\nwindow.grainformQA = qa;`);
  vm.runInContext(source,context,{filename:'app-ui-under-test.mjs'});await window.grainformBoot;
  assert.ok(window.__uiTest,'app booted');
  let snapshot={state:'ready',phase:'ready',active:null,next:null,score:0,level:1,cleared:0,rawCleared:0,pieces:0,time:0,tick:0,events:[],bodyCount:0,pieceId:0,clearIds:[]};
  const h={get,groups,buttons,dialogs,document,window,counts,effects,writes,queries,storage,ui:window.__uiTest,
    clearCounts(){effects.length=0;writes.length=0;queries.length=0;for(const k of Object.keys(counts))counts[k]=0;},
    at(value){now=value;},
    patch(value){window.__uiTest.patch(plain(value));window.__uiTest.updateUI();},
    emit(message){worker.onmessage({data:plain(message)});},
    snapshot(patch={},options={}){if(options.epoch)packetEpoch=options.epoch;snapshot={...snapshot,...patch};h.emit({type:'snapshot',epoch:packetEpoch,seq:++packetSeq,mode:'full',snapshot,bodyPatch:{reset:true,upsert:[],removed:[],revision:0},diagnostics:options.diagnostics??{},sentAt:now,sentTimeOrigin:1000});},
    ready(){h.emit({type:'ready',epoch:packetEpoch});},
    ack(name,state='playing'){const post=[...effects].reverse().find(e=>e[0]==='post'&&e[1].type==='command'&&e[1].name===name);assert.ok(post,`pending ${name}`);h.emit({type:'ack',id:post[1].id,epoch:packetEpoch,applied:true,state});},
    event(id,name,extra={}){const node=get(id);const fn=node.handlers.get(name);assert.ok(fn,`${id}:${name}`);fn({currentTarget:node,target:node,preventDefault(){},...extra});},
    dispatch(scope,name,event={}){const fn=listeners.get(`${scope}:${name}`);assert.ok(fn,`${scope}:${name}`);fn(event);},
    flushDraw(){const item=rafs.entries().next().value;if(item){rafs.delete(item[0]);item[1](now);}},
    storageFailure(value){storageFails=value;},
    state(){return plain({nodes:[...nodes].sort(([a],[b])=>a.localeCompare(b)).map(([id,n])=>[id,{text:n.textContent,disabled:n.disabled,hidden:n.hidden,checked:n.checked,open:n.open,dataset:n.dataset,width:n.style.width,classes:n.classList.values(),attrs:[...n.attrs].sort()}]),focus:document.activeElement?.id??null,qa:window.grainformQA.read(),storage:[...storage].sort()});}
  };
  return h;
}
async function pair(options){const a=await harness(baseline,options),b=await harness(candidate,options);const p={a,b,steps:0,check(label){assert.deepEqual(b.state(),a.state(),`${label}: final UI and QA`);assert.deepEqual(b.effects,a.effects,`${label}: ordered effects`);this.steps++;},step(label,fn){fn(a);fn(b);this.check(label);}};p.check('boot');return p;}
const active={x:40,y:20,color:1,shape:[[0,0],[1,0],[0,1],[1,1]]};
function startPlaying(h,phase='falling'){h.snapshot({state:'playing',phase,active:phase==='falling'?active:null,next:{color:2,shape:[[0,0]]}});h.ready();}

 test('stable snapshots eliminate redundant DOM writes and reduce selectors without skipping UI callbacks',async()=>{
  for(const phase of ['falling','settling','flash']) {
    const p=await pair();p.step(`start ${phase}`,h=>startPlaying(h,phase));p.a.clearCounts();p.b.clearCounts();
    for(let i=0;i<20;i++)p.step(`repeat ${phase} ${i}`,h=>h.snapshot({tick:i,time:.25}));
    const expectedQueries=phase==='falling'?200:100;
    assert.equal(p.a.writes.length,600);assert.equal(p.b.writes.length,0);assert.equal(p.a.counts.ui,20);assert.equal(p.b.counts.ui,20);
    assert.equal(p.a.counts.active,100);assert.equal(p.b.counts.active,20);
    assert.equal(p.a.queries.filter(q=>!q.startsWith('id:')).length,expectedQueries);assert.equal(p.b.queries.filter(q=>!q.startsWith('id:')).length,phase==='falling'?20:0);
    assert.equal(p.a.queries.filter(q=>q.startsWith('id:')).length,480);assert.equal(p.b.queries.filter(q=>q.startsWith('id:')).length,0);
    console.log(JSON.stringify({phase,snapshots:20,baseline:{writes:p.a.writes.length,queries:p.a.queries.length,activeChecks:p.a.counts.active},candidate:{writes:p.b.writes.length,queries:p.b.queries.length,activeChecks:p.b.counts.active}}));
  }
});

test('same state and phase independently react to every UI dependency; final values and effects match',async()=>{
  const p=await pair();p.step('playing',h=>startPlaying(h));
  const patches=[
    {ready:false},{ready:true},{failed:true},{failed:false},{pauseRequested:true},{pauseReason:'changed while pending'},{pauseRequested:false},{pauseReason:'new pause reason'},
    {pending:['start']},{pending:[]},{pending:['resume']},{pending:[]},{pending:['restart']},{pending:[]},{pending:['left','right']},{pending:[]},
    {awaitingFull:true},{awaitingFull:false},{snapshot:{active:null}},{snapshot:{active}},
    {diagnostics:{slowdown:true}},{diagnostics:{slowdown:false}},{snapshot:{qaFixture:{artificial:true}}},{snapshot:{qaFixture:null}},
    {snapshot:{score:1234.4}},{snapshot:{score:1234.6}},{snapshot:{level:12}},{snapshot:{cleared:101,rawCleared:321}},{snapshot:{rawCleared:null}},{snapshot:{pieces:42}},{snapshot:{time:8.99}},{snapshot:{time:9}},
    {snapshot:{next:{color:4,shape:[[0,0]]}}},{snapshot:{next:null}},{best:1234,savedBest:1234},{savedBest:1000},{storageAvailable:false},{storageAvailable:true},{best:2000,savedBest:2000},
    {snapshot:{state:'paused'}},{snapshot:{state:'over'}},{snapshot:{state:'ready'}},{snapshot:{state:'playing'}}
  ];
  for(const [i,patch] of patches.entries())p.step(`dependency ${i}`,h=>h.patch(patch));
  p.step('hidden same state',h=>{h.document.hidden=true;h.ui.updateUI();});assert.equal(p.b.get('resumeButton').disabled,true);
  p.step('visible same state',h=>{h.document.hidden=false;h.ui.updateUI();});
  p.step('dialog current open',h=>{h.get('settingsDialog').open=true;h.ui.updateUI();});assert.ok(p.b.buttons.every(b=>b.disabled));
  p.step('dialog current closed',h=>{h.get('settingsDialog').open=false;h.ui.updateUI();});assert.ok(p.b.buttons.every(b=>!b.disabled));
  console.log(`dependency differential checkpoints: ${p.steps}`);
});

test('fractional progress cache uses target rather than CSSOM serialization; artificial text stays final',async()=>{
  const p=await pair();p.step('start',h=>startPlaying(h));p.step('fraction and artificial',h=>h.patch({snapshot:{cleared:101,qaFixture:{artificial:true}},diagnostics:{slowdown:true}}));
  assert.equal(p.b.get('levelProgress').style.width,'5.61111%');p.a.clearCounts();p.b.clearCounts();
  for(let i=0;i<10;i++)p.step(`stable artificial ${i}`,h=>h.ui.updateUI());
  assert.equal(p.a.writes.filter(w=>w[1]==='style.width').length,10);assert.equal(p.b.writes.length,0);assert.equal(p.a.writes.length,320);
  assert.equal(p.b.get('stateLabel').textContent,'流动中 · 人工QA');assert.equal(p.b.get('clockNotice').textContent,'人工QA底桥与上部支撑（非自然投料） · 当前运行较慢，操作可能稍有延迟。');
  p.step('artificial removed',h=>h.patch({snapshot:{qaFixture:null}}));assert.ok(!p.b.get('clockNotice').textContent.includes('人工QA'));
  p.step('progress rollover',h=>h.patch({snapshot:{cleared:1800}}));assert.equal(p.b.get('levelProgress').style.width,'5%');
});

test('pause/resume ACK order, all phases, hidden and dialogs preserve aria, release and focus',async()=>{
  for(const phase of ['falling','settling','flash']) {
    const p=await pair();p.step('playing',h=>startPlaying(h,phase));
    p.step('pause requested',h=>h.ui.pause('测试暂停'));
    assert.equal(p.b.get('overlay').getAttribute('aria-busy'),'true');assert.equal(p.b.get('overlay').getAttribute('aria-labelledby'),'pauseTitle');assert.equal(p.b.get('resumeButton').disabled,true);
    p.step('pause ACK first',h=>h.ack('pause','paused'));assert.equal(p.b.get('pauseButton').getAttribute('aria-label'),'继续游戏');
    p.step('paused snapshot',h=>h.snapshot({state:'paused'}));
    p.step('resume requested',h=>h.ui.resume());assert.equal(p.b.get('resumeButton').disabled,true);
    p.step('resume snapshot first',h=>h.snapshot({state:'playing'}));assert.ok(p.b.buttons.every(b=>b.disabled));
    p.step('resume ACK',h=>h.ack('resume'));assert.equal(p.b.get('overlay').getAttribute('aria-busy'),'false');assert.equal(p.b.get('pauseButton').getAttribute('aria-label'),'暂停游戏');
    p.step('open settings',h=>h.event('settingsButton','click'));p.step('settings pause ACK',h=>h.ack('pause','paused'));p.step('close settings',h=>h.ui.closeDialog(h.get('settingsDialog')));assert.equal(p.b.document.activeElement.id,'settingsButton');
    p.step('hidden',h=>{h.document.hidden=true;h.dispatch('document','visibilitychange');h.ui.updateUI();});assert.equal(p.b.get('resumeButton').disabled,true);
    p.step('shown',h=>{h.document.hidden=false;h.dispatch('document','visibilitychange');});assert.equal(p.b.window.grainformQA.read().state,'paused');
  }
});

test('clear events, over focus, restart epochs, stale packets and failure preserve effect order',async()=>{
  const p=await pair();p.step('playing',h=>startPlaying(h));
  p.step('clear flash',h=>h.snapshot({phase:'flash',active:null,score:200,rawCleared:232,cleared:100,events:[{id:1,type:'clear',rawCount:232,count:100}]}));
  assert.match(p.b.get('announcer').textContent,/消除 232/);p.step('same clear ID',h=>h.snapshot());
  p.step('over with dialog',h=>{h.get('helpDialog').open=true;h.snapshot({state:'over'});});assert.notEqual(p.b.document.activeElement?.id,'againButton');
  p.step('restart new epoch',h=>{h.get('helpDialog').open=false;h.window.grainformQA.command('restart',{seed:1});h.snapshot({state:'playing',phase:'falling',active,events:[],score:0,pieces:0,time:0,cleared:0,rawCleared:0},{epoch:2});h.ack('restart');});
  p.step('stale packets',h=>{for(const type of ['ack','visibility','ready','fatal'])h.emit({type,epoch:1,id:999,hidden:true,state:'paused',message:'old error'});});
  p.step('over focus',h=>h.snapshot({state:'over',score:42}));assert.equal(p.b.document.activeElement.id,'againButton');
  const announceIndex=p.b.effects.findLastIndex(e=>e[0]==='announce'&&String(e[1]).includes('本局结束'));
  const focusIndex=p.b.effects.findLastIndex(e=>e[0]==='focus'&&e[1]==='againButton');assert.ok(announceIndex<focusIndex);
  p.step('fatal same state',h=>h.emit({type:'fatal',epoch:2,message:'mock error'}));assert.equal(p.b.get('overlay').getAttribute('aria-labelledby'),'errorTitle');assert.equal(p.b.get('inputStatus').textContent,'模拟已停止');
});

test('settings/storage changes and real redraw calls remain equivalent',async()=>{
  const p=await pair();p.step('playing',h=>startPlaying(h));p.step('initial draw',h=>h.flushDraw());
  p.step('contrast on',h=>{h.get('contrastToggle').checked=true;h.event('contrastToggle','change');h.flushDraw();});assert.ok(p.b.effects.some(e=>e[0]==='palette'&&e[1]==='contrast'));
  p.step('reduce motion',h=>{h.get('motionToggle').checked=true;h.event('motionToggle','change');h.flushDraw();});assert.equal(p.b.window.grainformQA.read().settings.motion,false);
  p.step('storage settings',h=>{h.dispatch('window','storage',{key:'grainform:0.4.8:grid:settings',newValue:JSON.stringify({contrast:false,motion:true})});h.flushDraw();});
  p.step('new record',h=>h.snapshot({score:100,pieces:2,rawCleared:40}));assert.match(p.b.get('endRecord').textContent,/已保存/);
  p.step('cross tab record',h=>{h.storage.set('grainform:0.4.8:grid:best','300');h.dispatch('window','storage',{key:'grainform:0.4.8:grid:best'});h.ui.updateUI();});assert.equal(p.b.groups.get('[data-best]')[0].textContent,'300');
  p.step('failed score save',h=>{h.storageFailure(true);h.snapshot({score:400});});assert.match(p.b.get('endRecord').textContent,/未能保存/);
  p.step('failed settings save',h=>{h.get('motionToggle').checked=true;h.event('motionToggle','change');});
  p.step('reset succeeds',h=>{h.storageFailure(false);h.event('confirmReset','click');h.ui.updateUI();});assert.equal(p.b.groups.get('[data-best]')[0].textContent,'0');
});

test('QA400ms output and direct input-status path remain live when all HUD values are unchanged',async()=>{
  const p=await pair({qa:true});p.step('playing',h=>startPlaying(h));p.a.clearCounts();p.b.clearCounts();
  for(const t of [1,400,401,600,801,802])p.step(`qa time ${t}`,h=>{h.at(t);h.ui.updateUI();});
  assert.equal(p.b.effects.filter(e=>e[0]==='qa-output').length,2);assert.equal(p.b.writes.filter(w=>w[0]==='qaOutput').length,2);assert.equal(p.b.counts.ui,6);
  p.step('direct input resync',h=>{h.ui.patch({awaitingFull:true});h.ui.updateInputStatus();});assert.equal(p.b.get('inputStatus').textContent,'正在重新同步棋盘…');
  p.step('direct pending status',h=>{h.ui.patch({awaitingFull:false,pending:['left','right']});h.ui.updateInputStatus();});assert.equal(p.b.get('inputStatus').textContent,'处理中 · 2');
});
