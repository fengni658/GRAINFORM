import test from 'node:test';import assert from 'node:assert/strict';import {createRequire}from'node:module';import{MaterialContour,clipMaterialContour}from'../ca-contour.mjs';import{CALayerRenderer,materialStyle}from'../ca-layer.mjs';
const{createCanvas}=createRequire(import.meta.url)('@napi-rs/canvas');
const patch=(upsert=[],removed=[],reset=false)=>({upsert,removed,reset});
const bodies=points=>new Map(points.map(([x,y,color=1],id)=>[id,{id,x:x+.5,y:y+.5,color}]));
function full(bs,pos){const c=new MaterialContour();c.invalidate(patch([...bs.values()],[],true));return c.update(bs,pos)}
function mask(shape,bs){const c=createCanvas(512,512),ctx=c.getContext('2d');ctx.scale(8,8);clipMaterialContour(ctx,shape,new Map([...bs.keys()].map(id=>[id,materialStyle(id)])));ctx.fillStyle='white';ctx.fillRect(0,0,64,64);return c}
function alpha(c,x,y){return c.getContext('2d').getImageData(Math.floor(x*8),Math.floor(y*8),1,1).data[3]}
function equalMask(a,b,bs){assert.deepEqual(mask(a,bs).getContext('2d').getImageData(0,0,512,512).data,mask(b,bs).getContext('2d').getImageData(0,0,512,512).data)}
test('contour incremental cache equals full rebuild through all fractional unit phases, delete/refill/reset and recolor',()=>{const bs=bodies(Array.from({length:121},(_,i)=>[20+i%11,20+Math.floor(i/11),1+i%4])),c=new MaterialContour();c.invalidate(patch([...bs.values()],[],true));for(let n=0;n<30;n++){const id=n%11,b=bs.get(id),up={...b,color:1+(n+2)%4};bs.set(id,up);c.invalidate(patch([up]));const pos=new Map(Array.from({length:11},(_,id)=>[id,[bs.get(id).x,bs.get(id).y-(n%5)/4]]));equalMask(c.update(bs,pos),full(bs,pos),bs)}const removed=[60,61,62];for(const id of removed)bs.delete(id);c.invalidate(patch([],removed));equalMask(c.update(bs,new Map()),full(bs,new Map()),bs);c.invalidate(patch([],[],true));bs.clear();equalMask(c.update(bs,new Map()),full(bs,new Map()),bs);assert.equal(c.records.size,0);assert.equal(c.links.size,0);assert.equal(c.preserved.size,0)});
test('both diagonal cases remain separate and retain their own material colors',()=>{for(const points of [[[10,10,1],[11,11,4]],[[11,10,2],[10,11,3]]]){const bs=bodies(points),s=full(bs,new Map());assert.equal(s.loops.length,2);for(const loop of s.loops)assert.equal(new Set(loop.map(p=>p[2])).size,1);assert.deepEqual([...new Set(s.loops.flat().map(p=>p[2]))].sort(),points.map(p=>p[2]).sort())}});
test('isolated grains and thin zigzag streams retain their actual subpixel centers',()=>{for(const points of [[[10,10]],Array.from({length:12},(_,i)=>[10+Math.floor(i/2),10+Math.ceil(i/2)])])for(const offset of [0,.25,.5,.75]){const bs=bodies(points),pos=new Map([...bs.values()].map(b=>[b.id,[b.x+offset,b.y]])),s=full(bs,pos),c=mask(s,bs);assert.equal(s.preserve.length,bs.size);for(const p of pos.values())assert(alpha(c,p[0],p[1])>200)}});
test('one-cell void stays open and disconnected heaps do not bridge',()=>{const pts=[];for(let y=10;y<20;y++)for(let x=10;x<20;x++)if(x!==15||y!==15)pts.push([x,y]);const bs=bodies(pts),s=full(bs,new Map());assert(s.loops.some(l=>l.linear));assert.equal(alpha(mask(s,bs),15.5,15.5),0);const heaps=bodies([[10,10],[10,11],[11,10],[11,11],[13,10],[13,11],[14,10],[14,11]]),m=mask(full(heaps,new Map()),heaps);assert.equal(alpha(m,12.5,10.5),0)});
test('dense stable bed does no contour or stable repaint work for unchanged draws',()=>{const c=new MaterialContour(),bs=bodies(Array.from({length:10000},(_,i)=>[10+i%200,200+Math.floor(i/200)]));c.invalidate(patch([...bs.values()],[],true));c.update(bs,new Map());const count=c.metrics.rebuilds;c.update(bs,new Map());assert.equal(c.metrics.rebuilds,count);assert.equal(c.metrics.lastUpdatedGrains,0);const b=bs.get(0);c.update(bs,new Map([[0,[b.x,b.y-.25]]]));assert.equal(c.metrics.lastUpdatedGrains,1);assert(c.metrics.lastUpdatedSquares<=12);assert.equal(c.records.size,bs.size)});
test('renderer restores context after contour failure',()=>{const ctx=createCanvas(288,432).getContext('2d'),r=new CALayerRenderer({createCanvas:()=>createCanvas(288,432)});r.configure(288,432,'a');r.contour.update=()=>{throw Error('forced contour failure')};let saves=0,restores=0;const save=ctx.save.bind(ctx),restore=ctx.restore.bind(ctx);ctx.save=()=>{saves++;save()};ctx.restore=()=>{restores++;restore()};assert.throws(()=>r.draw(ctx),/forced/);assert.equal(saves,restores)});
test('attached straight and bent stream outlets retain each grain center at fractional phases',()=>{
 const core=[];for(let y=20;y<=23;y++)for(let x=10;x<=13;x++)core.push([x,y]);
 const streams=[Array.from({length:7},(_,i)=>[14+i,21]),[[14,21],[15,21],[15,20],[16,20],[16,19],[17,19]],Array.from({length:7},(_,i)=>[11,19-i])];
 for(const stream of streams)for(const offset of[0,.25,.5,.75]){const bs=bodies([...core,...stream]),pos=new Map([...bs.values()].map(b=>[b.id,[b.x+offset,b.y]])),s=full(bs,pos),m=mask(s,bs);for(const [id,p]of pos)if(id>=core.length)assert(alpha(m,p[0],p[1])>180,`stream center absent at ${p}, offset${offset}`);}
});
test('a one-cell bridge between two thick cores retains unconditional glyph rescue',()=>{
 const points=[];for(const x of[10,11,13,14])for(const y of[10,11])points.push([x,y]);points.push([12,10]);
 for(const offset of[0,.25,.5,.75]){const bs=bodies(points),id=points.length-1,pos=new Map([...bs.values()].map(b=>[b.id,[b.x+offset,b.y]])),s=full(bs,pos),p=s.preserve.find(p=>p[0]===id);assert(p&&!p[3]);assert(alpha(mask(s,bs),12.5+offset,10.5)>200)}
});
test('surface tip does not get unconditional glyph exemption, but subpixel center remains covered',()=>{
 const points=[];for(let y=12;y<=17;y++)for(let x=10;x<=15;x++)points.push([x,y]);points.push([12,11]);
 for(const offset of[0,.25,.5,.75]){const bs=bodies(points),id=points.length-1,pos=new Map([...bs.values()].map(b=>[b.id,[b.x+offset,b.y]])),s=full(bs,pos),p=s.preserve.find(p=>p[0]===id);assert(p?.[3]);assert(alpha(mask(s,bs),12.5+offset,11.5)>180)}
});
test('core support changes revisit the second-neighbor halo and match a full reconstruction',()=>{
 const bs=bodies([[10,10],[10,11],[11,10],[11,11],[12,10],[13,10],[14,10]]),c=new MaterialContour();c.invalidate(patch([...bs.values()],[],true));c.update(bs,new Map());for(const id of[0,1,2]){bs.delete(id);c.invalidate(patch([],[id]));const s=c.update(bs,new Map());equalMask(s,full(bs,new Map()),bs)}
});
test('attached center protection is continuous through fine downward subphases',()=>{
 const points=[];for(let y=12;y<=17;y++)for(let x=10;x<=15;x++)points.push([x,y]);points.push([12,11]);const bs=bodies(points),id=points.length-1;
 for(const offset of[-.25,-.2,-.179,-.17,-.15,-.1,0,.1,.25]){const pos=new Map([[id,[12.5,11.5+offset]]]),s=full(bs,pos);assert(s.preserve.find(p=>p[0]===id)?.[3]);assert(alpha(mask(s,bs),12.5,11.5+offset)>180,`lost center at offset${offset}`)}
});
test('a diagonally adjacent isolated grain is not treated as attached to thick material',()=>{
 const bs=bodies([[10,10],[11,10],[10,11],[11,11],[12,12]]),s=full(bs,new Map());assert.equal(s.loops.length,2);assert.equal(s.preserve.find(p=>p[0]===4)?.[3],0);
 const single=bodies([[12,12]]),styles=new Map([...bs.keys()].map(id=>[id,materialStyle(id)]));assert(alpha(mask(s,bs),12.5,12.5)>200);
});
test('the mask keeps attached straight and bent stream outlets connected to their core',()=>{
 const core=[];for(let y=20;y<=23;y++)for(let x=10;x<=13;x++)core.push([x,y]);const streams=[Array.from({length:7},(_,i)=>[14+i,21]),[[14,21],[15,21],[15,20],[16,20],[16,19],[17,19]]];
 for(const stream of streams)for(const offset of[0,.25,.5,.75]){const bs=bodies([...core,...stream]),pos=new Map([...bs.values()].map(b=>[b.id,[b.x+offset,b.y]])),c=mask(full(bs,pos),bs),data=c.getContext('2d').getImageData(0,0,512,512).data,seen=new Uint8Array(512*512),start=Math.floor(21.5*8)*512+Math.floor((11.5+offset)*8),queue=[start];seen[start]=1;for(let i=0;i<queue.length;i++){const q=queue[i];for(const p of[q-1,q+1,q-512,q+512])if(p>=0&&p<seen.length&&!seen[p]&&data[p*4+3]>=16){seen[p]=1;queue.push(p)}}for(const[id,p]of pos)if(id>=core.length)assert(seen[Math.floor(p[1]*8)*512+Math.floor(p[0]*8)],`disconnected outlet at ${p}, offset${offset}`)}
});
test('crossing the rounded attachment boundary does not abruptly remove the top of a grain',()=>{
 const points=[];for(let y=12;y<=17;y++)for(let x=10;x<=15;x++)points.push([x,y]);points.push([12,11]);const bs=bodies(points),id=points.length-1,values=[];
 for(const y of[10.999999,11.000001]){const s=full(bs,new Map([[id,[12.5,y]]])),m=mask(s,bs);values.push(m.getContext('2d').getImageData(100,83,1,1).data[3])}
 assert(values[0]>200&&values[1]>200);assert(Math.abs(values[0]-values[1])<=2);
});
