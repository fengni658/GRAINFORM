import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {CALayerRenderer as Frozen} from './reference/ca-layer.mjs';
import {CALayerRenderer as Candidate} from '../ca-layer.mjs';
class Context{constructor(){this.arcs=0;this.clears=0;this.images=0;this.clearedPixels=0;this.copiedPixels=0;}save(){}restore(){}setTransform(){}clearRect(x,y,w,h){this.clears++;this.clearedPixels+=w*h;}beginPath(){}arc(){this.arcs++;}fill(){}drawImage(...args){this.images++;if(args.length===9)this.copiedPixels+=args[7]*args[8];}fillRect(){}}
function run(Renderer,{width=576,targetId=0}={}){
 const caches=[],screen=new Context(),renderer=new Renderer({createCanvas:()=>{const c=new Context();caches.push(c);return{width:0,height:0,getContext:()=>c};}});
 const bodies=Array.from({length:13824},(_,id)=>({id,x:28.5+id%232,y:419.5-Math.floor(id/232),color:1+id%4,sleep:true}));
 renderer.apply({reset:true,upsert:bodies,removed:[]});renderer.configure(width,Math.round(width*1.5),'standard');
 const output=[];function draw(name){const before={arcs:caches.reduce((s,c)=>s+c.arcs,0),copies:caches.reduce((s,c)=>s+c.images,0),pixels:caches.reduce((s,c)=>s+c.copiedPixels,0)};renderer.draw(screen);output.push({name,...renderer.read(),cacheArcCalls:caches.reduce((s,c)=>s+c.arcs,0)-before.arcs,internalTileCopies:caches.reduce((s,c)=>s+c.images,0)-before.copies,internalCopiedPixels:caches.reduce((s,c)=>s+c.copiedPixels,0)-before.pixels});}
 draw('initial-static-13824');const one=id=>({token:id+1,ruleTick:id+1,paths:[{id,points:[bodies[id].x,bodies[id].y,0,bodies[id].x,bodies[id].y+1,1]}]});
 renderer.synchronize([one(targetId)],null);draw('one-id-becomes-moving');
 renderer.synchronize([one(targetId)],{positions:[{id:targetId,xy:[bodies[targetId].x,bodies[targetId].y+.25]}]});draw('same-membership-only-position-changes');
 renderer.synchronize([one(targetId),one(targetId+1)],null);draw('one-extra-id-becomes-moving');
 renderer.synchronize([one(targetId+1)],null);draw('one-id-becomes-stable');return output;
}
const scenarios=[];
for(const spec of [{name:'lower-left-edge',width:576,targetId:0},{name:'interior-bed',width:576,targetId:6388},{name:'interior-bed-actual-browser-size',width:324,targetId:6388}]){
 const frozen=run(Frozen,spec),candidate=run(Candidate,spec);
 assert.deepEqual(frozen.map(x=>x.lastStablePaints),[13824,13823,0,13822,13823]);
 for(const index of [1,3,4]){assert.ok(candidate[index].lastStablePaints>0&&candidate[index].lastStablePaints<500);assert.equal(candidate[index].fullCacheRebuilds,1);assert.ok(candidate[index].internalTileCopies>0);assert.equal(candidate[index].lastCacheCopiedPixels,candidate[index].internalCopiedPixels);}
 assert.equal(candidate[2].lastStablePaints,0);assert.equal(candidate[2].internalTileCopies,0);
 scenarios.push({...spec,fixture:{layout:'13824 contiguous occupied cells, 232 columns, bottom-up rows from y=419.5',target:{x:28.5+spec.targetId%232,y:419.5-Math.floor(spec.targetId/232)},logicalTile:{x:Math.floor((28.5+spec.targetId%232)/16)*16,y:Math.floor((419.5-Math.floor(spec.targetId/232))/16)*16,size:16}},frozen,candidate});
}
const report={kind:'deterministic renderer work counts for explicitly described synthetic bed; not actual batch-six timing or browser FPS',scenarios};await writeFile(new URL('../evidence/cache-operation-comparison.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(scenarios.map(s=>({name:s.name,width:s.width,target:s.fixture.target,logicalTile:s.fixture.logicalTile,steps:s.candidate.map((r,i)=>({name:r.name,frozenStablePaints:s.frozen[i].lastStablePaints,candidateStablePaints:r.lastStablePaints,dirtyTiles:r.lastDirtyTiles,internalCopies:r.internalTileCopies,internalCopiedPixels:r.internalCopiedPixels}))}))));
