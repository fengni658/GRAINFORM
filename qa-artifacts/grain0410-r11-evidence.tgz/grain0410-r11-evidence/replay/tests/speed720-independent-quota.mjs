// Self-contained fixed-720 independent quota test. Only dependency: candidate ca-world.mjs.
// Default for final model/tests placement: ../ca-world.mjs. Optional argv[2]: target path from cwd.
// The full historical 480/720-source/hash audit remains archived separately; this tests the 720 deliverable.
import assert from 'node:assert/strict';import{resolve}from'node:path';import{pathToFileURL}from'node:url';
const input=process.argv[2]?pathToFileURL(resolve(process.argv[2])):new URL('../ca-world.mjs',import.meta.url),{World,CFG}=await import(input.href);
const CAP=720,FPS=240,G=900;assert.equal(CFG.maxSpeed,CAP);assert.equal(CFG.dt,1/FPS);assert.equal(CFG.gravity,G);
// Independent analytic integral, derived from area under min(v0+g*t,CAP).
function independentQ(v0,n){const t=Math.max(0,n)/FPS;return t<=(CAP-v0)/G?v0*t+G*t*t/2:CAP*t-(CAP-v0)*(CAP-v0)/(2*G)}
// Exact independent rational floor for nominal two-decimal birth speeds and integer material ages.
function exactFloor(s,n){n=BigInt(Math.max(0,n));s=BigInt(s);const d=72000n-s;return 750n*n<=2n*d?(4n*s*n+750n*n*n)/96000n:(54000000n*n-d*d)/18000000n}
// Preserved pre-fix numeric evaluation order, solely for historical negative/short-age comparison.
// It is not the independent correctness oracle above.
function oldNumericQ(v0,n){const t=Math.max(0,n)*(1/240),cap=Math.max(0,(720-v0)/900),a=Math.min(t,cap);return v0*a+.5*900*a*a+720*Math.max(0,t-cap)}
function oldQuota(v0,n){return Math.min(8,Math.floor(oldNumericQ(v0,n)+1e-9)-Math.floor(oldNumericQ(v0,n-1)+1e-9))}
// Parameter source: game.mjs drop birth speed 180*min(1.45,.24+(level-1)*.065+min(.4,pieces*.002)).
// Covers all nominal integer-level/integer-piece values through saturation, plus World0/adapter480 defaults.
const speeds=new Set([0,48000]);for(let level=1;level<=25;level++)for(let pieces=0;pieces<=201;pieces++)speeds.add(Math.min(26100,4320+(level-1)*1170+Math.min(7200,pieces*36)));
const w=new World();let qChecks=0,quotaChecks=0,shortSame=0,continuityChecks=0,longChecks=0;
for(const s of speeds){const v0=s/100;for(let n=0;n<=384;n++){assert.ok(Math.abs(w.transportQ(v0,n)-independentQ(v0,n))<1e-9);assert.equal(BigInt(Math.floor(w.transportQ(v0,n)+1e-9)),exactFloor(s,n));qChecks++;const got=w.transportQuota(v0,n),want=n?Number(exactFloor(s,n)-exactFloor(s,n-1)):0;assert.equal(got,want);assert.ok(Number.isInteger(got)&&got>=0&&got<=3);quotaChecks++;assert.equal(got,oldQuota(v0,n));shortSame++}const n=(CAP-v0)*FPS/G,e=1e-5,at=w.transportQ(v0,n);assert.ok(Math.abs(at-independentQ(v0,n))<1e-9);assert.ok(Math.abs(w.transportQ(v0,n+e)-at-CAP/FPS*e)<1e-9);if(n>e)assert.ok(Math.abs(at-w.transportQ(v0,n-e)-CAP/FPS*e)<1e-9);continuityChecks++;for(const age of[9999799,9999800,9999801,10000000,2**32,2**40]){assert.equal(w.transportQuota(v0,age),Number(exactFloor(s,age)-exactFloor(s,age-1)));assert.equal(w.transportQuota(v0,age),3);longChecks++}}
assert.equal(oldQuota(480,9999800),4,'Preserved original floating-point failure must remain observable');
const realSteps=[];for(const v0 of[0,43.2,180,261,480]){const a=new World();a.admit([{x:100,y:100}],1,1,v0);a.tick=9999799;let calls=0,values=[],events=[];const native=a.transportQuota.bind(a);a.transportQuota=(...args)=>{calls++;const value=native(...args);values.push(value);return value};a.audit=(...v)=>events.push(v);a.step();assert.equal(calls,1);assert.deepEqual(values,[3]);assert.equal(events.length,3);assert.equal(a.y[0],103);assert.equal(a.pathN[0],4);realSteps.push({v0,age:a.tick,quota:3,moves:3})}
console.log(JSON.stringify({pass:true,parameters:{cap:CAP,fps:FPS,gravity:G},birthSpeeds:speeds.size,qChecks,quotaChecks,shortSame,continuityChecks,longChecks,originalFailure:{v0:480,age:9999800,quota:oldQuota(480,9999800)},realSteps},null,2));
