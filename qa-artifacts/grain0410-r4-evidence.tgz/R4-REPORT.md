# 0.4.10 edge-contour-r4: fixed-timeline selection, final endpoint barrier

Purpose: test the single endpoint-lock mechanism confirmed by external r3 timing. This is an unpublished experiment requiring actual moving-edge acceptance, not a declaration that all remaining teeth are fixed.

## Evidence motivating the experiment

The actual r3 DPR2 slope-3 retains attached2–3CSSpx short horizontal teeth. Same-pose deletion of every protection circle leaves the main tooth row. In a deterministic replay, all13 captured endpoint poses match every one of4608 presented ID/XY coordinates. Within replay token59, horizontal stages9/10 generate the strong tooth pattern; vertical stage11 reduces it. The parent-provided external r3 timing probe recorded alpha1 on95.35% of second-slope draws and87.35% of high-density draws, with successor usually already received before ACK. These facts support testing endpoint exposure, not changing glyph guards or selecting only attractive phases.

## One protocol change

Sample builds a frozen draw plan using the actual fixed time interval. If a head interval has expired and a successor is available, select the successor and retain its true fractional alpha. The selector does not mutate or ACK. The selected displayQueue excludes expired head paths so future endpoint bodies are recovered by the correct actual paths.

After a successful entire draw, didDraw(theExplicitPlan) returns an ordered array of receipts. Crossed intermediate frames have endpointDrawn=false; the selected frame only has endpointDrawn=true at alpha1. Game and Worker track consumedToken separately from presentedToken. Final quiet frames carry requiresEndpointDraw; a false receipt is rejected atomically and cannot clear framePending or update endpoint proof. Final true endpoint acknowledgement still precedes checking/clear/spawn. Pause, hidden time exclusion, epoch, ordered tokens, queue≤2, and full fixed simulation debt remain.

Four runtime files change: ca-layer.mjs (queue + selected synchronization), app.mjs (commit explicit plan/ordered receipts), game.mjs (barrier/cursors), simulation-worker.mjs (receipt forwarding/cursors). The r3 raster batching section, all contour code, ca-world/ca-frame-world/ca-adapter and positionOnPath are unchanged. No physical rule, trajectory geometry, duration, texture, smoothing or resolution changed.

## Completed local constraints

New17-test timeline suite covers20ms successor alpha≈.2,34ms crossing two intervals, immutable/stale/failed plans, new-accept invalidation, pause/resume/epoch, retained starvation origin, empty-path barrier, max2, mixed-ID future-body cases, original axis-separated obstacle path, actualGame spawn and272-particle bridge clear gates, and realWorker+Game2488-particle natural clear. Consumed-only final or null ACKs are rejected without deleting pending frame; true endpoint permits original12-tick flash. Actual Worker retains clock-conservation error<1e-6ms and maxPending2.

Aggregate npm test includes51 previous tests plus17 new. Existing252 exact reference RGBA poses,320 slots and551-frame physics/path parity are also required in final logs. These do not claim browser frame cadence or dynamic visual success.

## Browser instructions and schema change

Overlay only the nine revision files onto a separate complete r3 directory and verify previous/new hashes. didDraw now returns an ACK array, not one object. Update external wrappers accordingly; runtime app already loops it. Do not interpret consumedToken as an endpoint draw. Each receipt explicitly reports endpointDrawn. queue.sample still returns frame/alpha/positions and additionally displayQueue/index. Do not edit runtime to fit old external probes.

Run npm test (68), verify:pixels:browser (252), verify:slots, verify:parity and verify:browser. Recheck actual natural clears, final alpha1 successful draw before final ACK, rejected false-barrier receipts, pause/hidden/resume, restart stale epoch, resync and bounded indexes. Same explicit poses must remain pixel-equivalent; wall-clock pose selection intentionally changes.

For actual first/second drop at DPR1/1.5/2, record continuous real video separately from timing. Inspect middle-flow attached horizontal teeth, not only endpoint/settled screenshots. Collect true draw-plan alpha/token and ordered receipts, successor availability and release events. Preserve failures and report if more intermediate phases merely change the tooth pattern without adequate visible improvement.

Re-run unprofiled sixth/high-density timing. Split active settling from input/ACK and falling gaps; report activity-only draw count/rate, draw-start gaps, complete rAF/draw percentiles, over-budget counts/consecutive lengths, queue, peak and last-active-draw debt, and later settled recovery separately. Existing r3 batching remains; do not attribute all debt to protocol or claim60fps from callback CPU timings. With max2 and commit-only-after-draw, sustained very low rAF can still cause debt.

No publishing included. Frozen r3 remains available as the performance-fixed but visually incomplete baseline.
