import assert from 'node:assert/strict';
import {writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {World as Candidate,CFG} from '../ca-world.mjs';
import {World as Reference} from './reference/transport/ca-world.mjs';
const reports=[];
const pointsCone=(cx,y0)=>{let p=[];for(let y=y0;y<420;y++)for(let x=cx-(y-y0);x<=cx+(y-y0);x++)p.push({x,y});return p};
function paired(name,points,removeAt,parity){
 const a=new Candidate(),b=new Reference();const events=[[],[]];
 for(const [k,w]of [a,b].entries()){w.admit(points,2,4,480);w.audit=(...v)=>events[k].push(v)}
 let steps=0,moves=0,woken=0,passed=0,newChunks=0,maxHeap=0;let oldIds=[];
 function awake(){for(let i=0;i<b.n;i++)if(b.live[i])b.chunks.add(b.chunk(b.x[i],b.y[i]));b.chunks.delete=()=>false;}
 function check(stage){
  assert.deepEqual(events[0],events[1],`${name}/${stage}: exact action stream`);
  assert.deepEqual(a.snapshot(),b.snapshot(),`${name}/${stage}: identity/occupancy/color/batch`);
  assert.equal(a.seed,b.seed,`${name}/${stage}: RNG state`);
  for(const p of a.snapshot())for(const alpha of [0,.03125,.1,.25,.5,.875,1])assert.deepEqual(a.positionAt(p.id,alpha),b.positionAt(p.id,alpha),`${name}/${stage}: path ${p.id} @ ${alpha}`);
  for(let i=0;i<a.n;i++)if(a.live[i]&&!a.chunks.has(a.chunk(a.x[i],a.y[i])))assert.ok(!a.empty(a.x[i],a.y[i]+1)&&!a.direction(i,-1,false)&&!a.direction(i,1,false),`${name}/${stage}: legal sleeping ID ${a.identity[i]}`);
 }
 function step(stage){events[0]=[];events[1]=[];awake();a.step();b.step();check(stage);steps++;moves+=events[0].length;woken+=a.frontStats?.woken||0;passed+=a.frontStats?.passed||0;newChunks+=a.frontStats?.newChunks||0;maxHeap=Math.max(maxHeap,a.frontStats?.peakHeap||0)}
 for(let k=0;k<3;k++)step(`settle-${k}`);
 assert.equal(a.chunks.size,0,`${name}: fixture must genuinely sleep`);
 while((a.tick&1)!==parity||a.tick<32)step('idle');
 const ids=a.snapshot().filter(removeAt).map(p=>p.id);assert.ok(ids.length);oldIds=[...ids];a.remove(ids);b.remove(ids);
 const removal=ids.length;
 for(let k=0;k<12;k++)step(`support-${k}`);
 // Reuse one vacated slot far above the bed with subcell first-step budget.
 const free={x:4,y:80};a.admit([free],3,9,0);b.admit([free],3,9,0);
 const reused=a.identity[a.grid[a.cell(free.x,free.y)]-1];assert.ok(reused>=a.live.length);assert.ok(oldIds.every(id=>!a.has(id)));
 for(let k=0;k<14;k++)step(`reuse-${k}`);
 reports.push({name,initial:points.length,removed:removal,steps,moves,woken,passed,newChunks,maxHeap,reused,passedChecks:true});
 console.log(JSON.stringify(reports.at(-1)));
}
paired('centered-cone-odd',pointsCone(116,376),p=>p.y===419&&p.x>=112&&p.x<128,0);
paired('centered-cone-even',pointsCone(116,376),p=>p.y===419&&p.x>=104&&p.x<120,1);
const wedge=[];for(let y=372;y<420;y++)for(let x=0;x<=y-372;x++)wedge.push({x,y});
paired('left-wall-wedge',wedge,p=>p.y===419&&p.x<8,0);
paired('right-wall-wedge',wedge.map(p=>({x:231-p.x,y:p.y})),p=>p.y===419&&p.x>=224,1);
const digest=p=>createHash('sha256').update(readFileSync(new URL(p,import.meta.url))).digest('hex');
const result={sourceSha256:digest('../ca-world.mjs'),referenceSha256:digest('./reference/transport/ca-world.mjs'),reports,notes:['Reference reinserts all live chunks before every step and disables chunk deletion.','Compared exact actions, identity/occupancy/color/batch, RNG and positionAt seven phases each step.','Sleeping cache state and derived vy are intentionally excluded.','No source mutations or performance benchmark.']};
writeFileSync(new URL('../evidence/wakefront-audit.json',import.meta.url),JSON.stringify(result,null,2));
