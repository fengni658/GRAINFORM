import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {World as Candidate} from '../ca-world.mjs';
import {World as Reference} from './reference/transport/ca-world.mjs';
const reports=[];
for(const mirror of [false,true]){
 const fallX=mirror?223:16,holes=mirror?[222,223]:[16,17];const points=[];for(let x=0;x<232;x++)if(!holes.includes(x))points.push({x,y:419});for(let x=mirror?223:0;x<=(mirror?231:16);x++)for(const y of [417,418])points.push({x,y});
 const a=new Candidate(),b=new Reference();a.tick=b.tick=mirror?1:0;a.admit(points,1,1,480);b.admit(points,1,1,480);a.chunks.clear();a.chunks.add(a.chunk(fallX,418));
 // Verify the chosen dormant population has no legal move before the first step.
 for(let i=0;i<a.n;i++)if(a.live[i]&&!a.chunks.has(a.chunk(a.x[i],a.y[i])))assert.ok(!a.empty(a.x[i],a.y[i]+1)&&!a.direction(i,-1,false)&&!a.direction(i,1,false));
 const followX=mirror?224:15,followId=a.identity[a.grid[a.cell(followX,417)]-1];let ea=[],eb=[];a.audit=(...v)=>ea.push(v);b.audit=(...v)=>eb.push(v);const steps=[];
 for(let n=0;n<4;n++){
  ea=[];eb=[];for(let i=0;i<b.n;i++)if(b.live[i])b.chunks.add(b.chunk(b.x[i],b.y[i]));b.chunks.delete=()=>false;a.step();b.step();assert.deepEqual(ea,eb);assert.deepEqual(a.snapshot(),b.snapshot());assert.equal(a.seed,b.seed);
  const visited=Array.from(a.frontVisited).filter(v=>v===a.frontEpoch).length;assert.equal(visited,a.frontStats.visited);
  const i=a.slotOf(followId);const legal=a.empty(a.x[i],a.y[i]+1)||!!a.direction(i,-1,false)||!!a.direction(i,1,false);
  if(n===0){assert.ok(a.frontStats.passed>0);assert.equal(a.y[i],417);assert.ok(legal);assert.ok(a.potential[a.chunk(a.x[i],a.y[i])]);assert.ok(a.chunks.has(a.chunk(a.x[i],a.y[i])));assert.ok(a.last.pending>0)}
  if(n===1)assert.ok(a.y[i]>417);
  for(const p of a.snapshot())for(const alpha of [0,.01,.07,.14,.33,.5,1])assert.deepEqual(a.positionAt(p.id,alpha),b.positionAt(p.id,alpha));
  steps.push({tick:a.tick,moves:a.last.moves,pending:a.last.pending,front:{...a.frontStats},follower:{id:followId,x:a.x[i],y:a.y[i],legal}});
 }
 reports.push({name:mirror?'right-to-left-mirrored':'left-to-right',points:points.length,pass:true,steps});
}
writeFileSync(new URL('../evidence/wakefront-passed.json',import.meta.url),JSON.stringify(reports,null,2));console.log(JSON.stringify(reports,null,2));
