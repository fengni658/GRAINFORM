import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {Game as A} from './reference/no-sync/game.mjs';
import {Game as B,SHAPES} from '../game.mjs';
const a=new A({seed:1}),b=new B({seed:1}),held=[];let states=0;
for(const g of [a,b]){g.world.addMany(Array.from({length:232},(_,i)=>({x:i+28,y:419,color:1})).filter(p=>p.x<120||p.x>=168));g.added=184;g.world.step();g.world.completePresentation();g.next={shape:SHAPES[0].map(p=>p.slice()),color:1};g.start();g.active.x=120;g.drop();}
for(let n=0;n<1000;n++){
 assert.deepEqual(a.snapshot(),b.snapshot());const fa=a.frame({full:n%7===0}),fb=b.frame({full:n%7===0});assert.deepEqual(fa,fb);states++;
 for(const frame of [fa,fb]){for(const body of frame.bodyPatch.upsert)Object.freeze(body);if(n<2)held.push([frame.bodyPatch,JSON.stringify(frame.bodyPatch)]);}
 if(a.phase==='falling')break;a.step();b.step();if(a.awaitingPresentation){assert.equal(a.completePresentation(a.consumedToken+1),b.completePresentation(b.consumedToken+1));}
}
assert.equal(a.rawCleared,2488);assert.equal(a.world.count,0);assert.equal(a.phase,'falling');for(const [ref,saved]of held)assert.equal(JSON.stringify(ref),saved);
const report={passed:true,states,rawCleared:a.rawCleared,live:a.world.count,retainedPatches:held.length,scope:'Exact complete snapshot and ordered patch/revision/materialFrame parity through final presentation gate, 12 flash ticks and full 2488 removal'};writeFileSync(new URL('../evidence/sync-clear-parity.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
