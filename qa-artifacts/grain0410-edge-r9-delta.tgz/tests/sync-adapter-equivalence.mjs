import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {Game as BaselineGame} from './reference/no-sync/game.mjs';
import {CAWorld as BaselineWorld} from './reference/no-sync/ca-adapter.mjs';
import {Game as CandidateGame, SHAPES} from '../game.mjs';
import {CAWorld as CandidateWorld} from '../ca-adapter.mjs';
import {CALayerRenderer,positionOnPath} from '../ca-layer.mjs';
const require=createRequire(import.meta.url),{createCanvas}=require(process.env.CANVAS_MODULE??'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');
const report={passed:false,baseline:'../grain0410-wakefront-micro/model',candidate:'../grain0410-edge-r9',scope:'R9 new-physics baseline versus identical physics plus B sync: Node correctness and exact RGBA only, no timing claims',gameStates:0,worldStates:0,patches:0,rgbaComparisons:0,frozenBodies:0,retainedSnapshots:0,reuseCycles:0,drops:[],checks:[]};
const equal=(a,b,label)=>assert.deepEqual(a,b,label);
function freezePatch(p){for(const b of p.upsert){Object.freeze(b);report.frozenBodies++;}return p;}
function worldState(a,b,label){equal(a.snapshot(),b.snapshot(),label+' snapshot');equal([...a.cache],[...b.cache],label+' ordered cache');equal([...a.changedBodies],[...b.changedBodies],label+' ordered changed');equal([...a.removedBodies],[...b.removedBodies],label+' ordered removed');equal(a.revision,b.revision,label+' revision');equal(a.consumedRevision,b.consumedRevision,label+' consumed revision');equal([...a.chunks],[...b.chunks],label+' wake order');equal(a.materialPaths(),b.materialPaths(),label+' material paths');report.worldStates++;}
function patch(a,b,full=false){const pa=a.consumeChanges({full}),pb=b.consumeChanges({full});equal(pa,pb,'bodyPatch with insertion order');freezePatch(pa);freezePatch(pb);report.patches++;return[pa,pb];}
function renderPair(pa,pb,fa,fb,label){
 for(const width of [324,486,648])for(const alpha of fa?[0,.125,.5,.875,1]:[1]){
  const bytes=[pa,pb].map((p,i)=>{const canvas=createCanvas(width,width*1.5),c=canvas.getContext('2d'),r=new CALayerRenderer({createCanvas:()=>createCanvas(width,width*1.5)}),f=i?fb:fa,q=f?[f]:[];r.apply(p);r.configure(width,width*1.5,'standard');r.synchronize(q,f?{frame:f,alpha,positions:f.paths.map(path=>({id:path.id,xy:positionOnPath(path,alpha)}))}:null);c.setTransform(width/288,0,0,width/288,0,0);c.fillStyle='#0d1315';c.fillRect(0,0,288,432);c.save();c.beginPath();c.rect(28,0,232,420);c.clip();r.draw(c);c.restore();return Buffer.from(c.getImageData(0,0,width,width*1.5).data);});
  assert(bytes[0].equals(bytes[1]),`${label}: RGBA ${width} alpha ${alpha}`);report.rgbaComparisons++;
 }
}

// Retain/freeze published objects across movement, sleep, wake, remove and reuse.
{
 const a=new BaselineWorld(),b=new CandidateWorld(),points=[{x:50,y:417,color:1},{x:50,y:418,color:1},{x:50,y:419,color:1},{x:90,y:419,color:2}];
 equal(a.addMany(points,{batch:7,initialVy:0}),b.addMany(points,{batch:7,initialVy:0}));
 let [pa,pb]=patch(a,b,true);const held=[pa,pb],saved=JSON.stringify(held);
 for(let j=0;j<5;j++){a.step();b.step();worldState(a,b,'sleep '+j);patch(a,b,j===3);}
 const old=b.cache.get(3),revision=b.revision;b.sync();assert.equal(b.cache.get(3),old);assert.equal(b.revision,revision);assert.equal(b.changedBodies.size,0);
 a.remove([2]);b.remove([2]);worldState(a,b,'support removed');patch(a,b);
 for(let j=0;j<5;j++){a.step();b.step();worldState(a,b,'wake '+j);patch(a,b);}
 const q=[{x:60,y:100,color:4}];equal(a.addMany(q,{batch:99}),b.addMany(q,{batch:99}));worldState(a,b,'generation reused');patch(a,b,true);
 assert.equal(JSON.stringify(held),saved,'Old published bodies stayed immutable');report.retainedSnapshots+=2;
 for(let j=0;j<320;j++){
  const ids=a.snapshot().map(p=>p.id);a.remove(ids);b.remove(ids);
  equal(a.addMany(points,{batch:j+10}),b.addMany(points,{batch:j+10}));worldState(a,b,'reuse '+j);
  if(j%3===0)patch(a,b,j%9===0);report.reuseCycles++;
 }
 patch(a,b);assert.equal(JSON.stringify(held),saved);
 report.checks.push('Ordered delta/full/reset, coalesced remove+reuse, 320 generations, wake/sleep, retained frozen body references');
}
// Read slots directly, preserve the old changed predicate, and copy every field.
{
 const w=new CandidateWorld();w.addMany([{x:50,y:100,color:1}],{batch:1});let previous=w.consumeChanges({full:true}).upsert[0];Object.freeze(previous);
 w.snapshot=()=>{throw Error('sync must not call snapshot')};w.bodies=()=>{throw Error('sync must not call bodies')};
 for(const [field,value]of [['color',3],['x',23],['y',101]]){const before={...previous},revision=w.revision;w[field][0]=value;w.sync();const p=w.consumeChanges();assert.equal(p.upsert.length,1);assert.equal(p.revision,revision+1);assert.notEqual(p.upsert[0],previous);equal(previous,before);previous=Object.freeze(p.upsert[0]);}
 const before={...previous},revision=w.revision;w.chunks.clear();w.sync();const p=w.consumeChanges();assert.equal(p.upsert[0].sleep,true);assert.equal(p.revision,revision+1);equal(previous,before);
 report.checks.push('Direct slot reads; original x/y/color/sleep changed predicate retained; id and batch outputs exact through legal births and generation reuse');
}

function replay(seed,count,offset,label,setup){
 const a=new BaselineGame({seed}),b=new CandidateGame({seed});if(setup){setup(a);setup(b);}a.start();b.start();
 const held=[];let serial=0;
 function checkpoint(name,{draw=false,full=false}={}){
  equal(a.snapshot(),b.snapshot(),name+' complete game snapshot');worldState(a.world,b.world,name);report.gameStates++;
  const fa=a.frame({full}),fb=b.frame({full});equal(fa,fb,name+' frame/bodyPatch/materialFrame');freezePatch(fa.bodyPatch);freezePatch(fb.bodyPatch);report.patches++;
  if(held.length<6&&fa.bodyPatch.upsert.length){held.push([fa.bodyPatch,JSON.stringify(fa.bodyPatch)],[fb.bodyPatch,JSON.stringify(fb.bodyPatch)]);report.retainedSnapshots+=2;}
  if(draw)renderPair({reset:true,upsert:[...a.world.cache.values()],removed:[]},{reset:true,upsert:[...b.world.cache.values()],removed:[]},fa.materialFrame,fb.materialFrame,name);
  serial++;
 }
 checkpoint(label+' start',{full:true});
 for(let j=0;j<count&&a.state==='playing';j++){
  const i=j+offset;equal(a.move([-4,3,-1,4,-4,1][i%6]*24),b.move([-4,3,-1,4,-4,1][i%6]*24));if(i&1)equal(a.rotate(),b.rotate());equal(a.drop(),b.drop());checkpoint(label+' drop '+j,{full:j%3===0});let n=0;
  while(a.phase!=='falling'&&a.state==='playing'&&n<1000){a.step();b.step();n++;checkpoint(label+' step '+j+'/'+n,{full:serial%17===0,draw:j<2&&(n===1||n===2||a.world.chunks.size===0)&&a.phase==='settling'});if(a.awaitingPresentation)equal(a.completePresentation(a.consumedToken+1),b.completePresentation(b.consumedToken+1));}
  assert(n<1000,'Settling completed');checkpoint(label+' settled '+j);report.drops.push({label,drop:j+1,ticks:n,live:a.world.count,cleared:a.rawCleared});console.log(JSON.stringify({progress:'drop complete',...report.drops.at(-1),gameStates:report.gameStates,rgbaComparisons:report.rgbaComparisons}));
 }
 for(const [ref,saved]of held)assert.equal(JSON.stringify(ref),saved,'Published historical patch must stay immutable');
 equal(a.pause(),b.pause());a.step();b.step();checkpoint(label+' pause');equal(a.resume(),b.resume());a.reset(seed+1);b.reset(seed+1);checkpoint(label+' reset',{full:true});
}
replay(1,23,50,'dense-23');
replay(91571,6,0,'seed91571-six');
replay(1,1,0,'shifted-preexisting-bed',g=>{g.world.addMany(Array.from({length:232},(_,i)=>({x:i+28,y:419,color:1})).filter(p=>p.x<120||p.x>=168));g.added=184;g.world.step();g.world.completePresentation();g.next={shape:SHAPES[0].map(p=>p.slice()),color:1};});
report.passed=true;writeFileSync(new URL('../evidence/sync-parity.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
