import test from 'node:test';
import assert from 'node:assert/strict';
import { Worker } from 'node:worker_threads';
import { setTimeout as delay } from 'node:timers/promises';
import { CALayerRenderer, MaterialFrameQueue, MATERIAL_FRAME_MS, positionOnPath, validateMaterialFrame } from '../ca-layer.mjs';

// Exercise the actual module's worker entry point. Only the browser transport
// names are bridged: Game, runtime, performance and timers are not substituted.
const bridge = `
  import { parentPort, workerData } from 'node:worker_threads';
  globalThis.self = globalThis;
  globalThis.postMessage = (message, transfer) => parentPort.postMessage(message, transfer);
  await import(workerData.moduleURL);
  if (typeof self.onmessage !== 'function') throw Error('Worker entry point was not installed');
  parentPort.on('message', data => self.onmessage({ data }));
  postMessage({ type: 'bridge-ready' });
`;
const near = (a, b, message = `${a} != ${b}`) => assert.ok(Math.abs(a - b) < 1e-6, message);

class WorkerSession {
  messages = [];
  waiters = new Set();
  frames = new Map();
  bodies = new Map();
  epoch = 0;
  pieceId = 0;
  commandId = 0;
  sequence = 0;
  fractionalTimes = 0;
  diagonalLegs = 0;
  maxPending = 0;
  error = null;

  constructor() {
    this.worker = new Worker(new URL(`data:text/javascript,${encodeURIComponent(bridge)}`), {
      workerData: { moduleURL: new URL('../simulation-worker.mjs', import.meta.url).href },
    });
    this.worker.on('error', error => this.fail(error));
    this.worker.on('message', message => {
      try { this.observe(message); } catch (error) { this.fail(error); }
      const index = this.messages.push(message) - 1;
      for (const waiter of [...this.waiters]) if (index >= waiter.from && waiter.predicate(message)) waiter.resolve(message);
    });
  }

  fail(error) {
    this.error ??= error;
    for (const waiter of [...this.waiters]) waiter.reject(this.error);
  }

  observe(message) {
    assert.notEqual(message.type, 'fatal', message.message);
    if (message.epoch > this.epoch) {
      this.epoch = message.epoch; this.pieceId = 0; this.sequence = 0; this.bodies.clear();
    }
    if (message.epoch === this.epoch && Number.isInteger(message.pieceId)) this.pieceId = message.pieceId;
    if (message.type !== 'snapshot') return;
    const { snapshot, diagnostics: d, bodyPatch: patch } = message;
    assert.equal(message.epoch, this.epoch);
    assert.equal(message.seq, this.sequence + 1, 'No worker packet is silently skipped');
    assert.equal(message.baseSeq, message.mode === 'full' ? null : this.sequence);
    this.sequence = message.seq; this.pieceId = snapshot.pieceId;
    assert.equal(patch.reset, message.mode === 'full');
    const previousBodies = new Map(this.bodies);
    if (patch.reset) this.bodies.clear();
    for (const id of patch.removed) this.bodies.delete(id);
    for (const body of patch.upsert) this.bodies.set(body.id, body);
    assert.equal(this.bodies.size, snapshot.bodyCount, 'Delta/full reconstruction conserves live IDs');
    assert.equal(snapshot.added - snapshot.rawCleared, snapshot.bodyCount, 'No grains vanish or appear');
    assert.ok(d.pendingMaterialFrames >= 0 && d.pendingMaterialFrames <= 2);
    assert.ok(d.maxPendingMaterialFrames <= 2);
    assert.ok(d.pendingTimers <= 1);
    near(d.clockConservationErrorMs, 0, 'Real monotonic clock debt is conserved');
    this.maxPending = Math.max(this.maxPending, d.pendingMaterialFrames);
    assert.ok(Number.isFinite(message.sentAt) && Number.isFinite(message.sentTimeOrigin));

    for (const frame of message.presentationFrames ?? []) validateMaterialFrame(frame);
    const frame = snapshot.materialFrame;
    if (!frame) return;
    validateMaterialFrame(frame);
    assert.equal(frame.phases, 68);
    near(frame.durationMs, MATERIAL_FRAME_MS);
    assert.ok(frame.ruleTick > 0, 'Quiet substeps may end a frame before its fourth rule tick');
    const key = `${message.epoch}:${frame.token}`;
    assert.equal(this.frames.has(key), false, 'A new material frame is published once');
    this.frames.set(key, frame);
    for (const path of frame.paths) {
      assert.equal(path.mode, 'substep-arc', 'Actual r6 frames use explicit complete paths');
      const points = path.points, body = this.bodies.get(path.id), previous = previousBodies.get(path.id);
      assert.ok(body, 'Every path refers to a live grain');
      assert.deepEqual(positionOnPath(path, 0), points.slice(0, 2));
      assert.deepEqual(positionOnPath(path, 1), [body.x, body.y], 'Path ends at its published body');
      if (previous) assert.deepEqual(points.slice(0, 2), [previous.x, previous.y], 'Path starts at the preceding published pose');
      for (let j = 3; j < points.length; j += 3) {
        if (!Number.isInteger(points[j + 2])) this.fractionalTimes++;
        if (points[j] !== points[j - 3] && points[j + 1] !== points[j - 2]) this.diagonalLegs++;
      }
    }
  }

  send(message) { if (this.error) throw this.error; this.worker.postMessage(message); }
  waitFor(predicate, { from = this.messages.length, timeout = 6000 } = {}) {
    if (this.error) return Promise.reject(this.error);
    const existing = this.messages.slice(from).find(predicate);
    if (existing) return Promise.resolve(existing);
    return new Promise((resolve, reject) => {
      const finish = callback => value => { clearTimeout(timer); this.waiters.delete(waiter); callback(value); };
      const waiter = { predicate, from, resolve: finish(resolve), reject: finish(reject) };
      const timer = setTimeout(() => waiter.reject(Error(`Timed out waiting for worker packet; last=${JSON.stringify(this.messages.at(-1)?.diagnostics)}`)), timeout);
      this.waiters.add(waiter);
    });
  }
  async init(qa = true) {
    await this.waitFor(m => m.type === 'bridge-ready', { from: 0 });
    const from = this.messages.length;
    this.send({ type: 'init', seed: 1, qa });
    await this.waitFor(m => m.type === 'ready', { from });
    return this.resync();
  }
  async command(name, value, extra = {}) {
    const id = ++this.commandId, from = this.messages.length;
    this.send({ type: 'command', id, epoch: this.epoch, pieceId: this.pieceId, name, value, ...extra });
    const ack = await this.waitFor(m => m.type === 'ack' && m.id === id, { from });
    assert.equal(ack.error, undefined);
    return ack;
  }
  async resync() {
    const from = this.messages.length, epoch = this.epoch;
    this.send({ type: 'resync', epoch });
    return this.waitFor(m => m.type === 'snapshot' && m.mode === 'full' && m.epoch === epoch, { from });
  }
  receipt(token, endpointDrawn, epoch = this.epoch) { this.send({ type: 'presented', token, endpointDrawn, epoch }); }
  async close() { await this.worker.terminate(); if (this.error) throw this.error; }
}

function draw(queue, packet, time) {
  // Real CALayer draw code, using a recording 2D surface rather than a browser.
  // This verifies draw/receipt ordering, not raster appearance or browser timing.
  const renderer = new CALayerRenderer({ rawCells: true, createCanvas: () => ({ getContext: () => null }) });
  renderer.apply(packet.bodyPatch);
  renderer.configure(288, 432, 'standard');
  const plan = queue.sample(time), cells = [];
  assert.ok(plan);
  renderer.synchronize(plan.displayQueue, plan);
  renderer.draw({ save() {}, restore() {}, fillRect(x, y, w, h) { cells.push([x + w / 2, y + h / 2]); } });
  assert.equal(cells.length, packet.snapshot.bodyCount, 'Complete draw retains every grain');
  for (const [x, y] of cells) assert.ok(Number.isFinite(x) && Number.isFinite(y));
  return { plan, receipts: queue.didDraw(plan) };
}

test('real worker sends valid complete paths, retains two-frame credit, and isolates pause/resync/restart', { timeout: 15000 }, async t => {
  const h = new WorkerSession(); t.after(() => h.close());
  await h.init();
  assert.equal((await h.command('qa-bridge', { fixture: 'early-clear', seed: 1 })).applied, true);
  assert.equal((await h.command('drop')).applied, true);
  await h.waitFor(m => m.diagnostics?.pendingMaterialFrames === 2, { from: 0 });
  let packet = await h.resync();
  assert.equal(packet.snapshot.bodyCount, 2488);
  assert.equal(packet.snapshot.phase, 'settling');
  const [first, second] = packet.presentationFrames;
  assert.equal(first.requiresEndpointDraw, false);
  assert.equal(second.requiresEndpointDraw, false);
  // Real-time transport may have zero/one-action first substeps. The complete
  // episode test below still requires actual fractional arc times and diagonals.
  for (const f of [first, second]) for (const p of f.paths) assert.equal(p.mode, 'substep-arc');
  const blockedSteps = packet.diagnostics.steps;
  await delay(70);
  packet = await h.resync();
  assert.equal(packet.diagnostics.steps, blockedSteps, 'Native timers cannot overrun the two-frame queue');
  assert.equal(packet.diagnostics.presentationBlocked, true);
  assert.ok(packet.diagnostics.debtSeconds > 0);

  assert.equal((await h.command('pause')).applied, true);
  packet = await h.resync();
  const paused = packet.diagnostics, queue = new MaterialFrameQueue();
  queue.accept(h.epoch, packet.presentationFrames, 0);
  queue.accept(h.epoch, packet.presentationFrames, 5);
  assert.equal(queue.queue.length, 2, 'Full resync does not duplicate frame credit');
  const stalePlan = queue.sample(20);
  queue.setPaused(true, 20);
  assert.equal(queue.didDraw(stalePlan), null);
  near(queue.sample(1000).alpha, .2);
  await delay(50);
  packet = await h.resync();
  assert.equal(packet.snapshot.state, 'paused');
  assert.equal(packet.diagnostics.running, false);
  assert.equal(packet.diagnostics.steps, paused.steps);
  near(packet.diagnostics.activeWallSeconds, paused.activeWallSeconds);
  near(packet.diagnostics.debtSeconds, paused.debtSeconds);

  h.receipt(second.token, false);
  h.receipt(first.token, false, h.epoch - 1);
  h.receipt(first.token, null);
  packet = await h.resync();
  assert.equal(packet.diagnostics.rejectedPresentationAcks, 3);
  assert.equal(packet.diagnostics.pendingMaterialFrames, 2);
  const partial = draw(queue, packet, 1000);
  near(partial.plan.alpha, .2);
  assert.deepEqual(partial.receipts, [{ epoch: h.epoch, token: first.token, ruleTick: first.ruleTick, endpointDrawn: false }]);
  for (const receipt of partial.receipts) h.send({ type: 'presented', ...receipt });
  packet = await h.resync();
  assert.equal(packet.diagnostics.pendingMaterialFrames, 1);
  assert.equal(packet.diagnostics.consumedToken, first.token);
  assert.equal(packet.diagnostics.presentedToken, 0);
  assert.equal(packet.snapshot.presentedToken, 0);
  assert.equal(packet.snapshot.rawCleared, 0);

  queue.setPaused(false, 1000);
  near(queue.sample(1000).alpha, .2);
  const resumedFrom = h.messages.length;
  assert.equal((await h.command('resume')).applied, true);
  await h.waitFor(m => m.diagnostics?.pendingMaterialFrames === 2, { from: resumedFrom });
  packet = await h.resync();
  assert.equal(packet.diagnostics.steps, paused.steps + 1, 'Exactly one freed credit admits one new native-timer step');
  queue.accept(h.epoch, packet.presentationFrames, 1000);
  assert.equal(queue.queue.length, 2);
  assert.equal(packet.diagnostics.maxPendingMaterialFrames, 2);

  const oldEpoch = h.epoch, oldFrames = packet.presentationFrames;
  const preRestartPlan = queue.sample(1020);
  assert.equal((await h.command('restart', { seed: 2 })).applied, true);
  assert.equal(h.epoch, oldEpoch + 1);
  await h.command('pause');
  queue.reset(h.epoch);
  assert.equal(queue.didDraw(preRestartPlan), null);
  assert.equal(queue.accept(oldEpoch, oldFrames, 1020), false);
  h.receipt(oldFrames[0].token, true, oldEpoch);
  const staleCommand = await h.command('drop', undefined, { epoch: oldEpoch });
  assert.equal(staleCommand.applied, false);
  assert.equal(staleCommand.reason, 'stale-round');
  packet = await h.resync();
  const fullSyncs = packet.diagnostics.fullSyncs;
  h.send({ type: 'resync', epoch: oldEpoch });
  packet = await h.resync();
  assert.equal(packet.diagnostics.fullSyncs, fullSyncs + 1, 'Stale resync cannot publish into a new round');
  assert.equal(packet.snapshot.bodyCount, 0);
  assert.equal(packet.diagnostics.pendingMaterialFrames, 0);
  assert.equal(packet.diagnostics.consumedToken, 0);
  assert.equal(packet.diagnostics.presentedToken, 0);
  assert.equal(packet.diagnostics.rejectedPresentationAcks, 1);
  assert.equal(h.maxPending, 2);
  t.diagnostic(`Actual worker observed ${h.frames.size} frames, ${h.fractionalTimes} fractional times and ${h.diagonalLegs} downhill slip legs.`);
});

test('real worker cannot clear before a final alpha-one draw, including an empty-path quiet barrier', { timeout: 15000 }, async t => {
  const h = new WorkerSession(); t.after(() => h.close());
  await h.init();
  assert.equal((await h.command('qa-bridge', { seed: 1 })).applied, true);
  await h.waitFor(m => m.snapshot?.materialFrame?.requiresEndpointDraw, { from: 0 });
  let packet = await h.resync();
  const final = packet.presentationFrames.at(-1), queue = new MaterialFrameQueue();
  assert.equal(final.requiresEndpointDraw, true);
  assert.equal(final.paths.length, 0, 'An immobile QA support bridge exercises an empty complete-path frame');
  assert.equal(packet.snapshot.bodyCount, 272);
  queue.accept(h.epoch, packet.presentationFrames, 0);
  const partial = draw(queue, packet, MATERIAL_FRAME_MS / 2);
  assert.equal(partial.plan.alpha, .5);
  assert.equal(partial.receipts, null);
  assert.equal(queue.read().consumedToken, 0);
  const barrierSteps = packet.diagnostics.steps;
  h.receipt(final.token, false);
  h.receipt(final.token, null);
  await delay(100);
  packet = await h.resync();
  assert.equal(packet.diagnostics.rejectedPresentationAcks, 2);
  assert.equal(packet.diagnostics.steps, barrierSteps);
  assert.equal(packet.diagnostics.pendingMaterialFrames, 1);
  assert.equal(packet.diagnostics.consumedToken, 0);
  assert.equal(packet.diagnostics.presentedToken, 0);
  assert.equal(packet.snapshot.phase, 'settling');
  assert.equal(packet.snapshot.rawCleared, 0);
  assert.deepEqual(packet.snapshot.clearIds, []);
  assert.equal(packet.snapshot.bodyCount, 272);

  // Freeze the real worker while testing the main-thread endpoint receipt, so
  // there is no timer race between receipt observation and the first clear tick.
  await h.command('pause');
  packet = await h.resync();
  const endpoint = draw(queue, packet, MATERIAL_FRAME_MS);
  assert.equal(endpoint.plan.alpha, 1);
  assert.deepEqual(endpoint.receipts, [{ epoch: h.epoch, token: final.token, ruleTick: final.ruleTick, endpointDrawn: true }]);
  assert.equal(queue.startedAt, null);
  assert.equal(queue.didDraw(endpoint.plan), null, 'Successful draw ticket cannot commit twice');
  for (const receipt of endpoint.receipts) h.send({ type: 'presented', ...receipt });
  packet = await h.resync();
  assert.equal(packet.diagnostics.pendingMaterialFrames, 0);
  assert.equal(packet.diagnostics.consumedToken, final.token);
  assert.equal(packet.diagnostics.presentedToken, final.token);
  assert.equal(packet.snapshot.presentedToken, final.token);
  assert.equal(packet.snapshot.rawCleared, 0, 'A receipt itself does not run game logic while paused');
  const resumedFrom = h.messages.length;
  await h.command('resume');
  const cleared = await h.waitFor(m => m.snapshot?.rawCleared === 232, { from: resumedFrom });
  const start = cleared.snapshot.events.find(e => e.type === 'clear-start');
  const end = cleared.snapshot.events.find(e => e.type === 'clear');
  assert.ok(start && end);
  assert.equal(end.controlTick - start.controlTick, 12, 'Original twelve-control-tick flash survives native timer catch-up');
  assert.equal(cleared.snapshot.bodyCount, 40);
  assert.equal(cleared.snapshot.active, null, 'Remaining supported material must settle behind its own presentation barrier');
  assert.equal(cleared.snapshot.added - cleared.snapshot.rawCleared, 40);
});

test('a complete natural drop keeps every path leg and grain until its real final draw releases spawning', { timeout: 15000 }, async t => {
  const h = new WorkerSession(); t.after(() => h.close());
  await h.init(false);
  assert.equal((await h.command('start')).applied, true);
  const pieceId = h.pieceId;
  assert.equal((await h.command('drop')).applied, true);
  const queue = new MaterialFrameQueue();
  let packet, final, consumed = 0;
  for (let attempt = 0; attempt < 180; attempt++) {
    await h.waitFor(m => m.epoch === h.epoch && m.snapshot?.materialFrame &&
      m.snapshot.materialFrame.token > consumed &&
      ((m.diagnostics.pendingMaterialFrames === 2 && m.snapshot.materialFrame.token >= consumed + 2) ||
        m.snapshot.materialFrame.requiresEndpointDraw), { from: 0 });
    packet = await h.resync();
    queue.accept(h.epoch, packet.presentationFrames, 0);
    assert.equal(packet.snapshot.rawCleared, 0);
    assert.equal(packet.snapshot.bodyCount, 2304);
    assert.equal(packet.snapshot.phase, 'settling');
    assert.equal(packet.snapshot.pieceId, pieceId);
    assert.equal(packet.snapshot.active, null);
    assert.equal(packet.snapshot.presentedToken, 0);
    const occupied = new Set(packet.bodyPatch.upsert.map(b => `${b.x},${b.y}`));
    assert.equal(occupied.size, 2304, 'The conserved discrete grid has no duplicate occupied cells');
    final = queue.queue[0];
    if (final.requiresEndpointDraw) break;
    assert.equal(queue.queue.length, 2);
    const result = draw(queue, packet, queue.startedAt + MATERIAL_FRAME_MS * 1.25);
    assert.equal(result.receipts.length, 1);
    assert.equal(result.receipts[0].endpointDrawn, false);
    consumed = result.receipts[0].token;
    h.send({ type: 'presented', ...result.receipts[0] });
  }
  assert.ok(final?.requiresEndpointDraw, 'Bounded actual drop must reach a quiet barrier');
  assert.ok(consumed > 2, 'Several complete moving frames passed through the real transport');
  assert.ok(h.fractionalTimes > 0 && h.diagonalLegs > 0);
  const before = packet.diagnostics;
  const partial = draw(queue, packet, queue.startedAt + MATERIAL_FRAME_MS * .5);
  assert.equal(partial.receipts, null);
  h.receipt(final.token, false);
  await delay(40);
  packet = await h.resync();
  assert.equal(packet.diagnostics.rejectedPresentationAcks, before.rejectedPresentationAcks + 1);
  assert.equal(packet.diagnostics.steps, before.steps);
  assert.equal(packet.snapshot.phase, 'settling');
  assert.equal(packet.snapshot.pieceId, pieceId);
  assert.equal(packet.snapshot.active, null);
  const endpoint = draw(queue, packet, queue.startedAt + MATERIAL_FRAME_MS + .001);
  assert.equal(endpoint.plan.alpha, 1);
  assert.deepEqual(endpoint.receipts, [{ epoch: h.epoch, token: final.token, ruleTick: final.ruleTick, endpointDrawn: true }]);
  const from = h.messages.length;
  h.send({ type: 'presented', ...endpoint.receipts[0] });
  const spawned = await h.waitFor(m => m.snapshot?.phase === 'falling' && m.snapshot.pieceId === pieceId + 1, { from });
  assert.equal(spawned.snapshot.bodyCount, 2304);
  assert.equal(spawned.snapshot.rawCleared, 0);
  assert.equal(spawned.diagnostics.presentedToken, final.token);
  assert.ok(spawned.snapshot.active);
  assert.equal(h.maxPending, 2);
  t.diagnostic(`Complete natural episode: ${h.frames.size} material frames, ${consumed} consumed-only receipts, final token ${final.token}.`);
});
