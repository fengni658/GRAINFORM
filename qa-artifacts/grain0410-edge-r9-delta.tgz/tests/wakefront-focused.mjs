import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {World as Candidate} from '../ca-world.mjs';
import {World as Reference} from './reference/transport/ca-world.mjs';
const a=new Candidate(),b=new Reference(),reports=[];let ea=[],eb=[];a.audit=(...v)=>ea.push(v);b.audit=(...v)=>eb.push(v);
const points=[];for(let y=390;y<420;y++)for(let x=116-(y-390);x<=116+(y-390);x++)points.push({x,y});
a.admit(points,1,1,480);b.admit(points,1,1,480);let passed=0,woken=0,stepCount=0;
function step(stage){ea=[];eb=[];for(let i=0;i<b.n;i++)if(b.live[i])b.chunks.add(b.chunk(b.x[i],b.y[i]));b.chunks.delete=()=>false;a.step();b.step();assert.deepEqual(ea,eb,stage+' exact actions');assert.deepEqual(a.snapshot(),b.snapshot(),stage+' snapshot');assert.equal(a.seed,b.seed);for(const p of a.snapshot())for(const alpha of [0,.1,.5,1])assert.deepEqual(a.positionAt(p.id,alpha),b.positionAt(p.id,alpha));passed+=a.frontStats?.passed||0;woken+=a.frontStats?.woken||0;stepCount++;}
for(let n=0;n<3;n++)step('settle');assert.equal(a.chunks.size,0);
a.admit([{x:113,y:381}],2,2,480);b.admit([{x:113,y:381}],2,2,480);
for(let n=0;n<16;n++)step('fall into sleeping lower chunk');assert.ok(passed>0);reports.push({name:'passed-cursor-on-lower-sleeping-chunk',stepCount,passed,woken,pass:true});
// Exercise stamp epoch wrap on a real support change, independently of material tick wrap.
a.frontEpoch=0xffffffff;const ids=a.snapshot().filter(p=>p.y===419&&p.x>=112&&p.x<116).map(p=>p.id);a.remove(ids);b.remove(ids);step('stamp epoch wrap');assert.equal(a.frontEpoch,1);reports.push({name:'front-epoch-wrap',pass:true,frontEpoch:a.frontEpoch});
// An observer callback removes/reuses an ID still pending in the initial queue.
const c=new Candidate();c.admit([{x:100,y:400},{x:100,y:390}],1,1,480);const old=c.idAt(1);let fresh=null,once=false;c.audit=()=>{if(once)return;once=true;c.remove([old]);c.admit([{x:110,y:390}],2,2,480);fresh=c.idAt(1);};c.step();assert.ok(!c.has(old)&&c.has(fresh));assert.equal(c.frontStats.stale,1);assert.equal(c.frontVisited[1],0);assert.deepEqual(c.positionAt(fresh,0),[110.5,390.5]);c.audit=null;c.step();assert.equal(c.frontVisited[1],c.frontEpoch);assert.equal(c.y[1],392);reports.push({name:'pending-generation-replaced-in-audit-hook',pass:true,staleOldId:old,freshId:fresh});
writeFileSync(new URL('../evidence/wakefront-focused.json',import.meta.url),JSON.stringify(reports,null,2));console.log(JSON.stringify(reports,null,2));
