# GRAINFORM 0.4.10 r9 — transport clock and ordered wake-front
Unpublished QA candidate over frozen r8 (delta SHA256 c86a1808ce19a3ae442f1c2596a8fbf7b44d651cb672e7badfa2ea873ef339c0). This is a game-material approximation, not rigid-circle physics or true contact momentum. Three runtime files change: ca-world.mjs, game.mjs, ca-adapter.mjs. UI, palette, glyph/contour, renderer cache, frame path encoder, worker, queue and final drawing barrier are unchanged.

## Fixed movement model
Four genuine material steps each integrate1/240s inside one60Hz output. Gravity900 logical cells/s², capped transport speed480 cells/s, birth speed equal to the intact piece's natural logical fall speed. Natural and hard drop use the same value; teleport distance creates no impulse. The material clock advances with actual material steps; rendering does not stretch or discard time.

Each slot has birth tick/speed. Q is the analytic integral of capped v0+g*age. Only floorQ(now)-floorQ(previous material tick) is supplied for the current step. Blocked unused integer allowance is discarded; sleep never causes catch-up displacement. Fractional phase comes from the common analytic clock, not a per-region accumulator. The maximum current allowance with these constants is2 actions per step; existing safety cap8 and max3 adjacent slips remain. Temporary subpixel overlap among sand is an explicitly allowed2D material approximation. Fixed external container remains bounded; internal solid obstacles are not a product feature.

An initial fixed bottom-up/alternating-horizontal list is merged with a min-heap of newly awakened IDs. Keys and cursor refer to each unvisited particle's original position for that step. A newly awakened chunk is scanned at most once. A key behind the cursor cannot run again this step; final geometric potential keeps it eligible next step. Full generation handles are validated before execution. Each ID receives its current allowance and runs at most once. There is no newborn keep-awake exception, global retry pass, contact reservation or unbounded queue.

## Reason for ordered waking
Uniform-time integration with old active-region scheduling produced different velocity ages and horizontal gaps across16-cell boundaries. Disabling sleep in a bounded diagnostic removed these gaps. A birth-only patch only softened the first frames; contact reset of velocity plus credit caused severe long settling. These rejected experiments were not combined into r9.
The old-bed support oracle removes16floor cells from a fully settled15776-grain bed. The previous fixed active list produced a16-cell internal gap at rows416/400/384/368 over four steps. Ordered wake-front matches full-awake all1072 moves within the first step and eliminates that endpoint gap.

## Pure sync allocation change
ca-adapter.sync directly reads slots and creates a body only for the exact original changed conditions. Cache order, revision, removal, sleeping status and immutable previously published bodies are preserved. This is independently compared against an identical new-physics baseline using the old sync. B's earlier old-r8 Node CPU median improvement51.1% is historical evidence only, not a measured combined-r9 or Chromium improvement.

## Explicit timing tradeoffs
Same-seed first/shifted-rotated second:46/88 control ticks (about.77/1.47s), compared with r7 35/84 and r8 12/29. First/second final extents remain107x41 and136x67, proxy slopes37.46°/44.58°. Alternating sixth128ticks vs r7 146/r8 66, with13824born/2304cleared/11520live.
Fixed dense twentieth159ticks (about2.65s) vs r7 171/r8 59. First20 total1345ticks,6.4% above r7's1264. Final46080live,0clear,232x237 extent, colors[13824,13824,4608,13824]. All20 rest states have zero full-grid legal actions.
The original relative-time gate and the under2-second twentieth-drop wish remain NOT PASSED. No speed tuning compensates for this. Actual browser hand-feel and absolute frame/debt budgets are pending; no stable60Hz or delivery-ready claim.

## Visual evidence
Offline original324CSS-per-pane first/second comparison includes132 endpoint frames and fixed phase probes (789/1167 candidate poses). The former cap-like protrusions and internal gaps are absent in the inspected worst frames, while grain texture remains. These samples do not mathematically prove every input/phase. The endpoint video is offline60fps, not recorded rAF; the earlier-finished baseline holds its final pose. Actual untouched-game video must be captured before screenshots/heavy logs, then decoded afterward.

## Local verification and reproduction
npm test:76 tests, including actual native-worker pause/restart, two-frame credit and true final alpha1 receipt before clearing. An old early-two-frame fractional-path assertion was adjusted: low initial transport allowance can legitimately yield empty/one-action substeps. The complete real-worker episode still requires actual fractional arc times and diagonal legs. Initial failed log is preserved.
npm run verify:pixels:340 exact same-pose incremental/full-reference RGBA comparisons.
npm run verify:slots:320 reuse cycles.
npm run verify:motion: independent input-map legality and analytic current-Q budget;117877 actions and365148 path-breakpoint/midpoint checks against full-awake same-rule reference across134 output observations. Old551 trajectory equality is intentionally inapplicable.
npm run verify:local: old-bed/support/following/opposing cases, independently authored full-awake multiframe/path checks, passed-cursor pending tests, stamp wrap and generation replacement. No relaxation of action/trajectory equality; sleep/cache-derived status may differ in the full-awake reference.
npm run verify:sync:1984 Game states,2316 World states,2105 ordered patches,225 actual-path RGBA comparisons,320 generations and20 retained snapshots (8,492,126 frozen body checks), plus61-state full2488-grain clear. Exact new-physics snapshot/ordered cache/bodyPatch/revision/material path/immutable historical objects plus actual-path RGBA and full2488-grain clear. Reference inputs are included under tests/reference; no external historical evidence directories are required.
The accompanying evidence contains actual counts, logs, same-time video/frames, and the readonly twentieth-drop per-output counters. Optional fixture inputs are artificial and labeled as such; they are not misrepresented as natural input scenes.

## Work and memory bounds
Old-bed wake oracle:176initial IDs+3072new IDs=3248visits;192initial cells+3840new scanned cells=4032, min-heap peak833. These are workload counts, not a speed benchmark.
Front typed arrays add3,119,700bytes; transport birth fields add1,559,040bytes. Complete CAWorld typed arrays total100,560,915bytes (about95.90MiB), fixed capacity97440. A single-World Node boundary sample observed RSS up to113.29MB; it is not a continuous browser peak or leak test. Actual reset retention and native/browser memory remain QA items.

## Real QA focus
First record natural and hard-drop first/second scenes, moved/rotated second, sixth and twentieth at DPR1/1.5/2 with multiple initial offsets. Look for relaxed contact-to-scatter continuity, no cap edges, chunk seams, systematic horizontal rods, color breakup or thin-stream disappearance.
Measure real active windows separately from idle inputs: actual draw rate, callback/draw/worker p95/p99/max, peak and last SETTLING debt, ACK-to-active0 and final-SETTLING-to-FALLING boundaries. Do not substitute a quiet FALLING draw for the last active draw.
Verify end-to-end full endpoint draw before clear, natural/cascade clears, pause, resync, restart/epochs and several resets with retained World counts. No publishing or main/Sites change is authorized by this candidate package.
