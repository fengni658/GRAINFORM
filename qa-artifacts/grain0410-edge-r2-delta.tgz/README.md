# GRAINFORM 0.4.10 edge-contour-r2

Unpublished single-runtime-file refinement over frozen edge-contour-r1. The original r1 remains unchanged. Apply the exact delta to a separate r1 copy, verify all hashes, and run independent Chromium review before publication.

## One bounded change: glyph protection eligibility and continuous strength

A grain with no full 2×2 support remains a protection candidate. For each nearby thick-core grain, use actual displayed centers and Manhattan distance d to compute contact clamp(2*(1.5-d),0,1). Split that contact between its horizontal and vertical directions. The narrowing strength is the largest axial support minus the largest opposing-pair support.

The protection shape continuously blends from the original identity-fixed glyph to a radius-0.25 patch at the physical presentation center. There is no point-in-path or rounded-cell attachment threshold that abruptly removes a whole grain. Opposing core support preserves a one-cell bridge. A diagonal-only isolated grain remains unguarded/full glyph. Updates revisit the two-cell halo because protection now depends on neighboring 2×2 cores.

No physics, paths, frame cadence, worker, renderer texture, smoothing coefficients, rim width, stable-tile algorithm, or unrelated performance model changed. Only ca-contour.mjs changes among runtime files.

## Fixed acceptance completed locally

- 50 Node tests passed (36 original + 14 contour tests).
- 228 exact RGBA fixture comparisons passed: incremental versus fresh-contour/full-stable reference.
- Independent read-only review: 1001 approach phases retain physical center alpha255; the previously observed added pop at y=11 is removed, with the remaining change matching r1. At y=12 the measured transition is smaller than r1.
- 1212 straight/bent/vertical outlet cases remain connected in both contour masks and painted material.
- Diagonal isolated grain and one-cell bridge masks are byte-identical to r1 at offsets0/.25/.5/.75.
- Existing 551-frame physics/path and 320-cycle identity tests passed; physics sources remain byte-identical to r1.

The local same-path visual contact sheet and offline60fps comparison show less attached short-tooth roughness during the intermediate flow, retaining individual free grains. They are not actual-browser video or FPS evidence. Do not claim all natural grain roughness is eliminated.

## Independent checks required

Run npm test, verify:pixels, verify:pixels:browser, verify:browser, verify:slots and verify:parity. The known monolithic Node verify:edge-sequence is not required: the local @napi-rs/canvas native drawImage retention was separately reproduced, and it must not be confused with browser runtime failure.

Recheck real first/second drops at DPR1/1.5/2, continuous edges, isolated/diagonal grains and connected stream outlets, one-cell bridge/hole, high-density DPR2 timing, and mixed-color edges. Compare with frozen r1 and049; report new CPU cost honestly. Keep the pending browser memory limitations explicit. No deployment is included in this delta.
