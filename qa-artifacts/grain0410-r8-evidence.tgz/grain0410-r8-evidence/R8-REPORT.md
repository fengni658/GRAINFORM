# 0.4.10 r8: single-visit local interleaving
Unpublished QA candidate based on frozen r7. The rejected four-round experiment is archived separately as grain0410-four-round-unfrozen / grain0410-four-round-evidence. It is not part of this revision.

## One runtime change
ca-world.mjs replaces eight whole-ID vertical sweeps plus three whole-ID slip sweeps with one fixed bottom-up ID visit. Each particle repeatedly takes a legal vertical move first, otherwise a complete adjacent diagonal, until no legal move, shared credit exhaustion, or the existing three-slip limit. Every actual move consumes one credit; total credit remains <=8. Direction choice, tick scan parity, cell/ID/color accounting, active chunks and final complete quiet/potential checks are unchanged. Action order labels1..8 describe actual moves; existing substep arc-length recording uses actual geometry. Fixed four-substep presentation intervals, 69-point capacity, r4 queue/final endpoint barrier, r3 cache, contour, glyphs, UI, and all nine other runtime files remain identical to r7.
Sand-to-sand temporary subpixel overlap remains the explicit 2D material approximation. This is not a hard-circle solver. Existing convex external container is checked; the product has no internal solid-obstacle feature.

## Deterministic comparison
Seed1 first/shifted-rotated second: r7 35/84 control ticks -> r8 12/29. Final bounding shapes remain107x41 and136x67; width/height angle proxies37.46 and44.58 degrees unchanged. Final occupancy symmetric differences2 and74cells; second common-cell colors differ at2 cells. During second drop no ID in the original2304-grain bed moved in either model.
Six alternating-offset drops: r7 [35,40,89,84,139,146] -> r8 [12,13,34,27,49,66]; both13824born/2304cleared/11520live.
Dense first20: total1264 ->423 control ticks; twentieth171 ->59. Both46080live,0cleared,232x237 final bounding extent, color counts[13824,13824,4608,13824]. Independent full-grid legality scans at all20 resting states find zero possible vertical/adjacent-diagonal moves. Support removal wakes and drops all8 affected test particles. These are actual settled endpoints, not early sleep.

Sequential isolated Node no-render runs: direction checks61,535,488 ->11,774,274; active particle visits7,860,925 ->2,837,519. Sum of per-g.step process CPU17.273 ->6.079s; wall14.546 ->4.765s. CPU may exceed wall because process counters include other runtime threads. Per-step p95 remains22.24/22.52ms; last-two-drop subset27.78/28.69ms. Total workload is lower, but peak per-step cost is not certified lower. Preflight timings with overlapping work are preserved separately and excluded from the clean claim.

## Visual evidence and limitations
Offline Node raster replay preserves every first/second endpoint. Scan includes137 phases at each available frame0/1/25 and9 phases elsewhere, all endpoints included: r7 sample counts690/1131, r8 355/636. Diagnostic contour reversal depths are not acceptance criteria. Viewed original324CSS contact sheets show no return of the old repeated multi-cell horizontal rods. Particle-level edge roughness remains.
The117-frame endpoint video follows r7 elapsed time and holds r8's settled frame after it finishes. It is offline rendering, not real browser/rAF capture. Rapid local collapse and color boundary quality require actual game video review; first12ticks is intentionally disclosed rather than automatically accepted. No claim of all-phase mathematical smoothness, stable60Hz, or browser speed acceptance.

## Local gates
76 Node tests, including native-worker protocol, pause/restart and final-clear endpoint gate.
340 exact same-pose incremental/full-reference RGBA comparisons; this is not old-physics pixel equality.
320 slot reuse cycles.
Independent new-rule motion oracle:115613 first/second events,41124diagonals, zero2-column moves; total<=8 and slip<=3 per particle/rule, map source/target/support/corridor, bounded external path, substep boundaries, colors/IDs, explicit final-clear fixture.
Additional3611 audited fixture events cover both mirrored follower slopes and scan parities (all progress ratios>=1), opposing targets, heap fall and removed support.
Old551 trajectory equality is intentionally inapplicable. Original goldens remain unmodified.

## Reproduction
Overlay the delta on complete frozen r7; verify REVISION-MANIFEST.json and ten runtime hashes. npm test; npm run verify:local; npm run verify:motion; npm run verify:slots; npm run verify:pixels.
The accompanying evidence/replay directory is self-contained: node fixtures.mjs; node six-check.mjs; node dense-check.mjs r7; node dense-check.mjs local. Run dense commands sequentially without concurrent work for timing. Each rebuilds geometry/accounting/full-grid quiet data, not merely reads stored output.
Visual regeneration: node compare.mjs; node scan.mjs; node worst.mjs; node sequence.mjs 0 117 endpoints. Node requires @napi-rs/canvas; set CANVAS_REQUIRE_FROM to an existing module-resolution file if the supplied dot dependency path does not exist. Compare produces runs.json, then scan/sequence consume it. No browser needed for these offline inputs.

## Actual QA priorities
First record actual full-flow video without screenshots/heavy per-frame logs, then decode across endpoint and intermediate phases at DPR1/1.5/2 and different startup offsets. Judge trigger-to-contact-to-scatter continuity, abrupt order-dependent collapse, thin streams and color boundaries, not just still silhouettes.
Measure actual input ACK -> last SETTLING -> first FALLING, especially six/twenty-drop replay; distinguish active-time draw rate and terminal draw from idle gaps. Record rAF/draw p95/p99/max, activity debt peak/final and worker CPU. Check final material endpoint truly drawn before clear, reset/restart and bounded fixed-capacity world retention. Do not infer native leak absence or stable60Hz from local totals.
