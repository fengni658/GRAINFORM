# Inherited regression evidence: phone board 0.4.11

## Result

No new functional or incremental-raster regression was found in the tested fixtures. **This is not an all-tests-pass claim.** The original absolute-geometry goldens, old pixel oracle, old release-label assertion, raw source-scope gates, and conservative corner-alpha diagnostic retain their recorded FAILs.

Tested runtime: `b-c09a9ea6b2fe85a5f439a6e9424da32ffa62a1a53c10f4f4008ae2e274f45b82`. All 11 candidate files match the parent `MANIFEST.json`. Runtime was never edited by these tests.

### Unchanged tests

- Original 0.4.9 package: 36/36 Node tests, slot tests, six-batch frozen golden parity, and exact pixel oracle pass. This verifies the historical package and its goldens reproduce.
- Exact pre-phone 0.4.10 release: raw Node tests 31 PASS / 5 FAIL. Four failures are obsolete Canvas mocks; one is the hardcoded 0.4.9 label. Mock-only adaptation leaves 35 PASS / 1 label FAIL. Slots and golden parity pass; inherited old pixel oracle fails.
- Final phone candidate: raw Node tests 29 PASS / 7 FAIL. The same five inherited failures remain, plus two old-floor fixture failures. Slots pass unchanged.
- Queue continuity: original test file is byte-for-byte unchanged; 23/23 pass against the final candidate. Its frozen queue comparison uses the original pre-continuity hybrid renderer.
- Raw phone six-batch parity fails immediately at grid-array equality: the old reference allocates 232×420, while the phone runtime allocates 232×500. Old frozen snapshots and expected JSON were not rewritten. This raw failure is not represented as phone-board parity success.
- Raw historical pixel oracle fails, as it already did with 0.4.10 contour rendering, and additionally assumes 432-high geometry. The old oracle remains untouched.

### Separate fixture adaptations

The original source package and all golden JSON remain unchanged. Only disposable copies are adapted:

1. Existing Canvas mock capability additions, identical to the prior approved mock-only adapter.
2. Bottom-relative fixture coordinates 416–419 → 496–499; canvas/DOM heights 432/864/1296 → 512/1024/1536. One `ca-game` bottom-row absolute expected value maps 419 → 499 as the new geometry specification. Counts, mass, score, timing, phase, ACK and cache assertions are unchanged.
3. The adapted full suite is 35 PASS / 1 FAIL; the remaining failure is the original 0.4.9 label assertion. A separate functional selection excludes exactly that named test and passes 35/35. The full-suite FAIL remains in its own log.
4. Both raw and phone-fixture slot suites pass.

### Deep incremental-raster gate

The inherited renderer harness uses actual candidate Game fixtures, logical size 288×512, field height 500, and exact pre-phone queue/path function identity checks. An explicitly labeled disposable R13 renderer reference changes only its drawing height 432 → 512 for the same-pose diagnostic. Original reference source bytes remain bundled separately.

- 185 drawn poses, including six-piece material paths and incremental delete/reuse/reset fixtures
- DPR 1, 1.5 and 2
- 555 exact screen comparisons and 555 exact offscreen-cache comparisons
- 395,550,720 compared pixels; zero pixel differences, zero tolerance
- Unit-leg holds, thin-stream and known-hole checks pass
- 20 idle draws produce no extra contour rebuild, cache rebuild, or cell repaint
- **Conservative alpha-180 corner diagnostic remains FAIL: alpha 124.** It matches the historical R13 same-pose result; its threshold was not relaxed.

Raw inherited motion/render source-scope gates are also retained as FAIL. They were originally restricted to a renderer-only change or original queue source identity and do not authorize the phone geometry/version/queue additions.

## Reproduce from a standalone archive

Keep these paths together:

- `candidate/`
- `validation/inherited-original-gates.mjs`
- `validation/inherited-render-gates.mjs`
- `validation/inherited-queue-continuity.test.mjs`
- `evidence/inherited/references/` in full

The reference bundle contains the unchanged original test package, exact pre-phone runtime, minimal frozen queue and R13 renderer modules, original runtime for raw source gates, and inherited validation scripts. `references/reference-manifest.json` records their SHA-256 hashes. No external workspace sibling is needed. No `node_modules` is bundled.

Requirements: Node.js 20 or newer and the existing `@napi-rs/canvas` package resolvable by Node. Recorded runs used Node.js 24.19.0. No browser or unsafe browser flags are used.

From the extracted `grain0411-phone-board` directory:

```
node validation/inherited-original-gates.mjs
node validation/inherited-render-gates.mjs
```

Each command creates a new evidence subdirectory and writes its canonical report:

- `evidence/inherited/report.json`: raw and fixture-adapted Node/slot/parity/pixel/queue results, source hashes, adaptation records and exact expected-failure classification
- `evidence/inherited/raster-report.json`: raw source-gate logs, exact renderer comparison counts and the retained alpha-180 failure

The first driver exits successfully only when the expected raw FAILs are present with the recorded counts, the adapted functional and queue checks pass, and candidate/source integrity checks hold. The second exits successfully only when exact raster/cache checks pass and exactly the inherited alpha124/180 diagnostic remains. A successful driver exit does **not** rewrite these constituent FAILs as PASS.

`inherited-finalize.mjs` records an optional explicit functional-filter rerun and manifest check after the first driver; it is not needed for normal reproduction. An early diagnostic attempt used a negative test-name filter that did not exclude Node's full test name; its FAIL log is retained. The canonical runner now uses an explicit skip-name selection. A separate early harness bookkeeping failure incorrectly compared extra copied original files to the smaller candidate file set; the corrected integrity check hashes every candidate file individually. Neither issue changed runtime or assertions.

## Limits

Node correctness and raster evidence only. No browser/GPU, interactive frame-time, deployment, or long-run high-pile performance claim. Full-redraw comparison independently checks incremental consistency but shares the contour algorithm; bounded center/thin/hole checks do not establish universal hole-free geometry. Taller-board behavior is not expected to reproduce the old absolute 420-high golden trajectory snapshots.
