This first attempt and resume preserve valid raw FAIL logs, but are superseded by the clean bundled-reference run. Resume reused original/baseline execution logs while recreating disposable copies; copied baseline evidence JSON was stale and has been removed. Do not use this directory as the final aggregate; use ../report.json and its referenced work directory. Candidate runtime and assertions were unchanged.

Removed stale generated result paths:
- baseline0410-pixel-equivalence-node.json
- baseline0410-slot-wake-parity.json
- baseline0410-slot-merge-tests.json
- baseline0410/evidence/slot-wake-parity.json
- baseline0410/evidence/slot-merge-tests.json
- baseline0410/evidence/pixel-equivalence-node.json
- baseline0410-canvasmock/evidence/slot-wake-parity.json
- baseline0410-canvasmock/evidence/slot-merge-tests.json
- baseline0410-canvasmock/evidence/pixel-equivalence-node.json
