# 0.4.11 gate results

Local candidate; no publication or browser sign-off.

- Focused geometry/bounds/capacity/collision/clear/ACK/storage/layout/fall checks: 10/10 PASS.
- All 7 tetromino empty-board falls: old 8.650s (I 9.200s), new 6.5167s (I 6.8667s), 24.66–25.36% shorter.
- Same-scale micro-grain screen pixels at 1/1.5/2/3: exact RGBA old/new equality, including new bottom band.
- HTTP immutable entry and 11-file closure: PASS.
- Original queue-continuity regression: 23/23 PASS.
- Original full Node suite on 0411, raw: 29 PASS / 7 FAIL (four obsolete Canvas mocks, one old version assertion, two old floor fixtures).
- Separately mock+geometry-adapted full suite: 35 PASS / 1 FAIL (old version assertion). Explicitly selected behavioral subset: 35/35 PASS. Original assertion remains intact in full suite.
- Slot/reuse invariants: PASS.
- Old six-batch golden parity: FAIL retained because reference grid is 232×420 and candidate is 232×500; not silently rewritten.
- Old pixel oracle and old source-identity gates: FAIL retained. See inherited classifications for baseline-reproduced failures.
- Geometry-adapted inherited renderer: 555 screen + 555 cache exact comparisons, 395,550,720 pixels, zero differences; bounded thin/hole and idle-no-repaint checks PASS.
- Inherited conservative corner diagnostic: FAIL retained (alpha124 < alpha180). Not a new 0411 regression; not called all-green.
- Initial added-band raster regression: FAIL retained, fixed by resizing padded contour field to shared HEIGHT+2; subsequent exact raster checks PASS.
- Browser interaction, touch/scroll, GPU/compositing, frame-time and memory pressure: NOT RUN / pending safe-browser QA.

A first 60-piece-capped natural run reached a test-only FAIL: the assumption that larger geometry must yield more played pieces is invalid when clearing occurs. Its FAIL is preserved in evidence/high-pile-initial-capacity-assumption-FAIL.log. The harness initially kept per-piece records only in memory and failed before writing them, so that run does not supply per-piece numeric evidence. It is not counted as PASS, nor used as a product performance regression. Actual extra capacity is directly proven by occupying, clearing and reusing all 18,560 added cells. A separately bounded 12-piece Node observation also retains a supplemental FAIL: exact cumulative physics-tick parity 2666 != 2660 after clearing. Progress counts are in evidence/high-pile.json/log. Cross-capacity exact tick equality is not a required invariant: public reused IDs encode board capacity and unchanged roughness hashes those IDs. No further run was made to chase this extra guarantee. The harness now writes complete observations before assertions for any future requested reproduction. A Node wall-clock number is not browser performance.

See evidence/inherited/README.md and reports for every original/adapted run and exact fixture substitutions. Runtime hashes match MANIFEST.json; old release baseline remained byte-identical.
