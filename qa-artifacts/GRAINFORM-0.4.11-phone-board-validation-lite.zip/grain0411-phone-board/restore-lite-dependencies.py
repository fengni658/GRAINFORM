#!/usr/bin/env python3
"""Restore exact replay dependencies; no network, runtime changes, or test execution."""
from pathlib import Path
import argparse,hashlib,zipfile,json
p=argparse.ArgumentParser();p.add_argument('--full-validation-zip',required=True,type=Path);a=p.parse_args();root=Path(__file__).resolve().parent
expected='b50f8f730b76a50183a0aa54abbff997beb81d82ed383fd5d02096f93278bb92'
assert hashlib.sha256(a.full_validation_zip.read_bytes()).hexdigest()==expected,'Full archive SHA256 mismatch'
prefix=root.name+'/'
allowed=('candidate/','dist/','evidence/baseline0410/','evidence/inherited/references/')
count=0
with zipfile.ZipFile(a.full_validation_zip) as z:
 for item in z.infolist():
  if not item.filename.startswith(prefix):continue
  rel=item.filename[len(prefix):]
  if not rel.startswith(allowed) or item.is_dir():continue
  target=(root/rel).resolve();assert root in target.parents
  data=z.read(item)
  if target.exists():assert target.read_bytes()==data,f'Refusing to overwrite different file: {rel}'
  else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  count+=1
m=json.loads((root/'MANIFEST.json').read_text())
for f in m['files']:assert hashlib.sha256((root/'candidate'/f['file']).read_bytes()).hexdigest()==f['sha256']
for f in json.loads((root/'evidence/inherited/references/reference-manifest.json').read_text()):
 target=root/'evidence/inherited/references'/f['bundled'];assert hashlib.sha256(target.read_bytes()).hexdigest()==f['sha256']
print(f'Restored/verified {count} dependency files; no tests executed.')
