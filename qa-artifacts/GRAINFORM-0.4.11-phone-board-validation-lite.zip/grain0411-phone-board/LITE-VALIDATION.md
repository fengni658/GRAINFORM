# GRAINFORM 0.4.11 compact independent validation evidence

This third archive does not replace or alter the frozen runtime or original full validation archive. Tests, assertions, recorded results and FAIL logs are copied unchanged. No tests or long high-pile runs were repeated to create it. This package intentionally contains no runtime source duplication, historical large golden array, images, or full historical source trees.

## Frozen artifacts

- Runtime ZIP: GRAINFORM-0.4.11-phone-board-runtime.zip; 49,971 bytes; SHA256 9353da895f3647b8d4bd250126415e74ecabcc3f39feae4cc640ea27c6808138
- Full validation ZIP: GRAINFORM-0.4.11-phone-board-validation.zip; 10,216,825 bytes; SHA256 b50f8f730b76a50183a0aa54abbff997beb81d82ed383fd5d02096f93278bb92
- Runtime build ID and individual file hashes: MANIFEST.json
- Full archive package hashes retained unchanged: PACKAGES.json

## Included

All current validation scripts, exact runtime patch, package manifest, QA/gate notes, complete textual logs and JSON result records, including raw/fixture-adapted failures and initial diagnostic failures. `LITE-INVENTORY.json` gives every included original file's hash and every omitted full-package member's hash/reason. Repeated result records are retained rather than silently deduplicated. The root README and inherited README are the original full-package instructions; this supplement explains their dependency restoration for the lite package.

## Exact, easiest reproduction route

Obtain the two frozen archives above from the owner. This lite package alone is evidence, not a fully populated source checkout.

Run `python restore-lite-dependencies.py --full-validation-zip /path/to/GRAINFORM-0.4.11-phone-board-validation.zip` from the extracted grain0411-phone-board directory. It verifies the entire full archive SHA, then restores only candidate/, dist/, evidence/baseline0410/, and evidence/inherited/references/. Existing differing files are rejected. It verifies all 11 candidate hashes and all reference-manifest hashes. It does not run tests or alter the frozen archives.

After restoration use the original scripts unchanged:

- `node --test validation/phone-board.test.mjs`
- `node validation/http-smoke.mjs`
- `npm install` then `node validation/raster-board.mjs` (official npm @napi-rs/canvas 0.1.100)
- `node validation/inherited-original-gates.mjs`
- `node validation/inherited-render-gates.mjs`

Do not casually rerun the optional long/high-pile diagnostic. Its retained extra-assumption FAILs are documented, and they are not required capacity or browser-performance gates.

## Fixed Git sources and exact script dependencies

Repository: https://github.com/fengni658/GRAINFORM

- Historical 0.4.9 source/tests/golden: commit 2a8fe3b67a75df2a74a124871d80acf5543cc271. The original tests runner expects `evidence/inherited/references/original049/`, including the old validation-reference/expected.json (intentionally omitted here), merge tests and original test files. The original runtime dependency is `references/original049-runtime/`. Restore/check file hashes using reference-manifest.json; historical retrieval metadata present in the full reference bundle is not assumed to live in Git.
- Current approved 0.4.10 main: commit ddc8a1aed5a525b2efa8bd5da384b6961b790db2. Runtime modules/CSS match the pre-phone baseline. Main's entry HTML packaging differs from the bare baseline index, so do not substitute that HTML while claiming exact baseline equality. The exact baseline is restored to both evidence/baseline0410/ (focused scripts) and references/baseline0410/ (inherited scripts), with MANIFEST.json/reference-manifest.json hashes as authority.
- Historical R13 rendering reference may be retrieved from commit fe2d30f3970b13226535c1e464e04e36c98404fa, but each needed ca-layer.mjs/ca-contour.mjs must match the bundled reference-manifest before use. Destination: references/r13-renderer/. Do not assume current main contains this older renderer.
- Frozen pre-continuity queue comparator: references/frozen-hybrid/{ca-layer.mjs,ca-contour.mjs}. Obtain the exact bytes from the full validation package or another source with matching reference-manifest hashes; neither current main nor an unspecified 049 label is assumed equivalent.
- Historical harness dependency: references/validation/{compat-original-mocks.mjs,queue-continuity.test.mjs,hybrid-motion.mjs,hybrid-render.mjs}, plus any files enumerated there in reference-manifest.json. Use the full validation archive or verify an exact fixed-source match. These are dependencies of the preserved inherited runners, not newly rewritten tests.
- Candidate/dist: restore the frozen runtime archive's exact build closure to candidate/ and dist/, or use the verified full-archive helper. The patch is for review/rebuilding against the exact baseline; a reconstruction must match all MANIFEST.json hashes before evidence is attributed to it.

The Git revisions identify known stable sources; the per-file SHA manifest, not a nearby release label or moving branch, decides byte identity. If a historical dependency cannot be found in a pinned checkout, use the hash-verified original full validation package rather than replacing an oracle or weakening an assertion.

## Review boundaries

The candidate remains frozen. Any future bug fix requires a new immutable build ID and new package hashes. Browser interaction/GPU/performance remains unverified. Historical label/golden/pixel/alpha FAILs and supplemental high-pile assumption FAILs remain FAILs; successful classification drivers are not an all-green claim.
