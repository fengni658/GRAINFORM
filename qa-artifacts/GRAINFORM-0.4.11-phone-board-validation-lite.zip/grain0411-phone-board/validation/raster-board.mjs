import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {CALayerRenderer as New} from '../candidate/ca-layer.mjs';
import {CALayerRenderer as Old} from '../evidence/baseline0410/ca-layer.mjs';
let canvasModule;try{canvasModule=createRequire(new URL('../package.json',import.meta.url))('@napi-rs/canvas');}catch{canvasModule=createRequire(new URL('../../grain0410-r13-external/unpacked/candidate/tests/ca-contour.test.mjs',import.meta.url))('@napi-rs/canvas');}const {createCanvas}=canvasModule;
const out=new URL('../evidence/',import.meta.url), results=[];
function render(C,h,scale,bodies){const c=createCanvas(288*scale,h*scale),ctx=c.getContext('2d'),r=new C({createCanvas:()=>createCanvas(1,1)});r.apply({reset:true,upsert:bodies,removed:[]});r.synchronize([],null);r.configure(c.width,c.height,'standard');ctx.setTransform(scale,0,0,scale,0,0);r.draw(ctx);return {c,ctx,r};}
const patch=Array.from({length:576},(_,i)=>({id:i,x:120.5+i%24,y:300.5+Math.floor(i/24),color:1,sleep:true}));
for(const scale of [1,1.5,2,3]){const a=render(Old,432,scale,patch),b=render(New,512,scale,patch);assert.deepEqual(b.ctx.getImageData(0,0,288*scale,432*scale).data,a.ctx.getImageData(0,0,288*scale,432*scale).data);const band=patch.map(p=>({...p,y:p.y+176})),n=render(New,512,scale,band),ref=render(Old,432,scale,band.map(p=>({...p,y:p.y-80})));assert.deepEqual(n.ctx.getImageData(0,476*scale,288*scale,24*scale).data,ref.ctx.getImageData(0,396*scale,288*scale,24*scale).data);const data=n.ctx.getImageData(0,476*scale,288*scale,24*scale).data;assert(data.some(v=>v));results.push({scale,sameParticlePixels:'exact RGBA match at same logical position',newBandPixels:'exact match translated by 80 logical cells',tileRows:n.r.tileRows});if(scale===2)fs.writeFileSync(new URL('new-bottom-band-raster.png',out),n.c.toBuffer('image/png'));}
fs.writeFileSync(new URL('raster-board.json',out),JSON.stringify({status:'PASS',backend:'@napi-rs/canvas, not browser screenshot',results},null,2)+'\n');console.log(JSON.stringify(results));
