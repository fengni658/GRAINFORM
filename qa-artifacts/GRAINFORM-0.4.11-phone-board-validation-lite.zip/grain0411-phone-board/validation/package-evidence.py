from pathlib import Path
import zipfile,json,hashlib
r=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(r/'GRAINFORM-0.4.11-phone-board-validation.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['candidate','dist','validation','evidence']:
  for p in sorted((r/folder).rglob('*')):
   if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and p.suffix not in ['.zip','.tgz']:
    z.write(p,Path(r.name)/p.relative_to(r))
 for name in ['MANIFEST.json','README.md','QA-SPEC.md','GATE-RESULTS.md','phone-board.patch','package.json']:
  p=r/name
  if p.exists():z.write(p,Path(r.name)/name)
rows=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(r.glob('*.zip'))]
(r/'PACKAGES.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
