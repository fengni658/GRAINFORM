// Read-only inherited tests, with separate, explicitly recorded fixture adaptation.
// Never modifies original sources, candidate runtime, frozen references, or golden JSON.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const base=path.resolve(fileURLToPath(new URL('..',import.meta.url))),workspace=path.dirname(base);
const refs=path.join(base,'evidence/inherited/references'),choose=(bundled,external)=>fs.existsSync(path.join(refs,bundled))?path.join(refs,bundled):path.join(workspace,external);
const source=process.env.ORIGINAL049_ROOT??choose('original049','grain049-original-tests'),baseline=process.env.BASELINE0410_ROOT??choose('baseline0410','grain0410-queue-continuity/release-candidate');
const inheritedValidation=choose('validation','grain0410-queue-continuity/validation'),frozenQueue=choose('frozen-hybrid','grain049-edge-hybrid/candidate');
const candidate=path.resolve(process.env.CANDIDATE_ROOT??path.join(base,'candidate'));
const out=path.join(base,'evidence/inherited'),work=path.join(out,`run-${Date.now()}`);
fs.mkdirSync(work,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
const files=root=>fs.readdirSync(root,{recursive:true}).filter(f=>fs.statSync(path.join(root,f)).isFile()).sort();
const manifest=root=>Object.fromEntries(files(root).map(f=>[f,sha(fs.readFileSync(path.join(root,f)))]));
const runtimeManifest=root=>Object.fromEntries(fs.readdirSync(root).filter(f=>/\.(mjs|html|css)$/.test(f)).sort().map(f=>[f,sha(fs.readFileSync(path.join(root,f)))]));
const assertRuntime=(root,expected)=>{for(const[f,h]of Object.entries(expected))assert.equal(sha(fs.readFileSync(path.join(root,f))),h,`runtime changed: ${f}`);};
const initial={source:manifest(source),baseline:runtimeManifest(baseline),candidate:runtimeManifest(candidate)},runs=[],adaptations=[];
const tests=['ca-game','ca-phase','ui-ca-presentation','ui-grid-clock','ui-grid-renderer','ui-grid-boot','ui-message-clock'].map(n=>`tests/${n}.test.mjs`);
const suites=[['node-suite',['--test','--test-reporter=tap',...tests]],['slots',['merge-test.mjs']],['parity',['merge-parity.mjs']],['pixels',['tests/pixel-equivalence-node.mjs']]];
function run(label,dir,args,env={}){
 const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8',maxBuffer:64*1024*1024,env:{...process.env,...env}});
 const output=(r.stdout??'')+(r.stderr??'');fs.writeFileSync(path.join(work,`${label}.log`),output);
 const count=k=>Number(output.match(new RegExp(`(?:#|ℹ) ${k} (\\d+)`))?.[1]??0);
 const row={label,command:['node',...args],exitCode:r.status,signal:r.signal,log:path.relative(base,path.join(work,`${label}.log`)),...(output.includes('# tests ')?{tests:count('tests'),pass:count('pass'),fail:count('fail'),failedNames:[...output.matchAll(/^not ok \d+ - (.+)$/gm)].map(m=>m[1])}:{} )};
 runs.push(row);console.log(JSON.stringify(row));return row;
}
function copy(kind,overlay){const dir=path.join(work,kind);fs.cpSync(source,dir,{recursive:true});fs.mkdirSync(path.join(dir,'evidence'),{recursive:true});if(overlay)for(const f of Object.keys(runtimeManifest(overlay)))fs.copyFileSync(path.join(overlay,f),path.join(dir,f));return dir;}
function collect(kind,dir){for(const f of ['slot-merge-tests.json','slot-wake-parity.json','pixel-equivalence-node.json'])if(fs.existsSync(path.join(dir,'evidence',f)))fs.copyFileSync(path.join(dir,'evidence',f),path.join(work,`${kind}-${f}`));}
function geometryFixtures(dir){
 for(const f of ['tests/ca-game.test.mjs','tests/ca-phase.test.mjs','tests/ui-ca-presentation.test.mjs','tests/ui-grid-boot.test.mjs','merge-test.mjs']){
  const file=path.join(dir,f),before=fs.readFileSync(file,'utf8');let after=before;
  // Absolute floor-relative fixture values, including ca-game's one bottom-row expectation.
  after=after.replace(/\b(416|417|418|419)(\.5)?\b/g,(_,n,half)=>String(Number(n)+80)+(half??''));
  // Rendering/DOM fixture dimensions only. Width 288 and geometry-independent assertions stay fixed.
  after=after.replace(/\b432\b/g,'512').replaceAll('576,864','576,1024').replaceAll('864,1296','864,1536').replaceAll('?128:864','?128:1024');
  if(after!==before){fs.writeFileSync(file,after);adaptations.push({file:f,beforeSHA256:sha(before),afterSHA256:sha(after),kind:'separate phone-geometry fixture copy; y416..419 +80 and output height ×512/432'});}
 }
}
for(const [kind,root] of [['original',null],['baseline0410',baseline],['candidate0411',candidate]]){
 const dir=copy(kind,root);
 for(const [name,args]of suites)run(`${kind}-raw-${name}`,dir,args);
 collect(kind,dir);
 if(root){
  const compat=path.join(work,`${kind}-canvasmock`);fs.cpSync(dir,compat,{recursive:true});
  run(`${kind}-adapt-canvas`,compat,[path.join(inheritedValidation,'compat-original-mocks.mjs'),compat]);
  run(`${kind}-canvasmock-node-suite`,compat,suites[0][1]);
  if(kind==='candidate0411'){
   const geometry=path.join(work,'candidate0411-phone-fixtures');fs.cpSync(compat,geometry,{recursive:true});geometryFixtures(geometry);
   run('candidate0411-phone-fixtures-node-suite',geometry,suites[0][1]);run('candidate0411-phone-fixtures-slots',geometry,suites[1][1]);
   // Separate functional gate leaves the inherited 0.4.9 label assertion in the full-suite FAIL.
   run('candidate0411-phone-fixtures-functional',geometry,['--test','--test-reporter=tap','--test-skip-pattern=old ack/fatal/visibility/ready are uniformly stale; UI keeps old visual and input system',...tests]);
   assertRuntime(geometry,initial.candidate);
   for(const f of ['validation-reference/expected.json','validation-reference/fixtures.json','tests/reference/ca-layer.mjs'])assert.equal(sha(fs.readFileSync(path.join(geometry,f))),initial.source[f],`golden changed: ${f}`);
  }
  assertRuntime(compat,initial[kind==='baseline0410'?'baseline':'candidate']);
 }
}
const queueOriginal=path.join(inheritedValidation,'queue-continuity.test.mjs'),queueCopy=path.join(base,'validation/inherited-queue-continuity.test.mjs');
fs.copyFileSync(queueOriginal,queueCopy);assert.equal(sha(fs.readFileSync(queueCopy)),sha(fs.readFileSync(queueOriginal)));
const queueRoot=path.join(work,'queue-standalone'),queueProject=path.join(queueRoot,'project');fs.mkdirSync(path.join(queueProject,'validation'),{recursive:true});fs.cpSync(candidate,path.join(queueProject,'candidate'),{recursive:true});fs.cpSync(frozenQueue,path.join(queueRoot,'grain049-edge-hybrid/candidate'),{recursive:true});fs.copyFileSync(queueCopy,path.join(queueProject,'validation/queue-continuity.test.mjs'));
run('candidate0411-unchanged-queue-continuity',queueProject,['--test','--test-reporter=tap','validation/queue-continuity.test.mjs']);
assert.deepEqual(manifest(source),initial.source,'original source changed');assert.deepEqual(runtimeManifest(baseline),initial.baseline,'baseline runtime changed');
const current=runtimeManifest(candidate),candidateStable=JSON.stringify(current)===JSON.stringify(initial.candidate);
const report={source,baseline,candidate,work,initial,runs,adaptations,originalSourceUnchanged:true,goldenFilesUnchanged:true,candidateStableDuringRun:candidateStable,currentCandidateSHA256:current,
 classifications:{label:'Hardcoded 0.4.9 label assertion remains an explicit inherited FAIL. The separately filtered functional run excludes exactly that named test; it does not change it.',rawCanvasMocks:'Original Canvas mocks lack path methods required by inherited contour rendering. Mock-only adaptation is separate.',geometry:'Bottom-row fixtures y416..419 and 432-high drawing are old geometry. Only the separate phone-fixture copy is adapted. One bottom-row absolute assertion maps419→499 as explicit geometry specification; all counts, timing, phases, scores and thresholds unchanged.',parity:'Raw parity compares arrays and frozen snapshots against a 232×420 reference. The raw FAIL and validation-reference/expected.json remain untouched; this is not claimed as phone-board parity.',pixels:'Old frozen un-contoured 432-height oracle remains unchanged and FAIL is retained. New geometry-aware exact raster test must be evaluated separately.'},limits:['Node only; no browser, GPU, frame-time or deployment validation.','No claim that old absolute-coordinate golden gameplay snapshots apply to the taller board.']};
fs.writeFileSync(path.join(work,'report.json'),JSON.stringify(report,null,2)+'\n');fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({report:path.join(out,'report.json'),candidateStableDuringRun:candidateStable,runs:runs.map(({label,exitCode,pass,fail})=>({label,exitCode,pass,fail}))}));
const expectedFailures=new Set(['baseline0410-raw-node-suite','baseline0410-raw-pixels','baseline0410-canvasmock-node-suite','candidate0411-raw-node-suite','candidate0411-raw-parity','candidate0411-raw-pixels','candidate0411-canvasmock-node-suite','candidate0411-phone-fixtures-node-suite']);
for(const r of runs)assert.equal(r.exitCode,expectedFailures.has(r.label)?1:0,`Unexpected inherited outcome: ${r.label}`);
const oldLabel='old ack/fatal/visibility/ready are uniformly stale; UI keeps old visual and input system';
for(const [label,pass,fail]of [['original-raw-node-suite',36,0],['baseline0410-raw-node-suite',31,5],['baseline0410-canvasmock-node-suite',35,1],['candidate0411-raw-node-suite',29,7],['candidate0411-canvasmock-node-suite',33,3],['candidate0411-phone-fixtures-node-suite',35,1],['candidate0411-phone-fixtures-functional',35,0],['candidate0411-unchanged-queue-continuity',23,0]]){const r=runs.find(x=>x.label===label);assert.equal(r.pass,pass,label);assert.equal(r.fail,fail,label);}
assert.deepEqual(runs.find(r=>r.label==='candidate0411-phone-fixtures-node-suite').failedNames,[oldLabel],'Geometry adaptation must leave only legacy-label FAIL');
assert(candidateStable,'Candidate changed during validation');
report.classifiedGate='PASS: expected inherited FAILs retained with exact counts; no additional functional regression';
fs.writeFileSync(path.join(work,'report.json'),JSON.stringify(report,null,2)+'\n');fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
