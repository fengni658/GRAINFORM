from pathlib import Path
import hashlib,json,shutil,difflib,re,zipfile
r=Path(__file__).resolve().parents[1];base=r.parent/'grain0410-queue-continuity/release-candidate';src=r/'candidate'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=sorted(src.iterdir(),key=lambda p:p.name)
identity=''.join(f'{p.name} {sha(p)}\n' for p in files);buildid='b-'+hashlib.sha256(identity.encode()).hexdigest();rel=Path('experimental/0.4.11/builds')/buildid;build=r/'dist'/rel
if build.exists():assert all((build/p.name).read_bytes()==p.read_bytes() for p in files),'Immutable build cannot be overwritten'
else:build.mkdir(parents=True);[shutil.copy2(p,build/p.name) for p in files]
edges=[]
for p in build.glob('*.mjs'):
 for ref in re.findall(r'(?:from\s*|new URL\()\s*[\'\"]([^\'\"]+)[\'\"]',p.read_text()):
  assert ref.startswith('./') and (p.parent/ref).is_file(),(p.name,ref)
  assert (p.parent/ref).resolve().parent==build.resolve()
  edges.append({'from':p.name,'to':ref})
html=(build/'index.html').read_text();assert 'src="./app.mjs"' in html and 'href="./style.css"' in html
manifest={'status':'LOCAL_QA_CANDIDATE_NOT_DEPLOYED','version':'0.4.11','buildId':buildid,'entry':str(rel/'index.html'),'identity':'sha256(sorted filename + space + file sha256 + newline), includes entry HTML','files':[{'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in files],'baseline':[{'file':p.name,'sha256':sha(p)} for p in sorted(base.iterdir())],'moduleEdges':edges,'old0410Unmodified':True,'mainUnmodified':True}
(r/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
patch=''
for p in files:
 old=base/p.name;before=old.read_text() if old.exists() else ''
 patch+=''.join(difflib.unified_diff(before.splitlines(True),p.read_text().splitlines(True),fromfile='a/'+p.name,tofile='b/'+p.name))
(r/'phone-board.patch').write_text(patch)
with zipfile.ZipFile(r/'GRAINFORM-0.4.11-phone-board-runtime.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in build.iterdir():z.write(p,p.relative_to(r/'dist'))
 z.write(r/'MANIFEST.json','MANIFEST.json')
print(json.dumps({'buildId':buildid,'entry':str(rel/'index.html'),'files':len(files),'edges':len(edges)}))
