# GRAINFORM 0.4.11 phone-board candidate

Not deployed. This is an additive isolated QA build; existing 0.4.10 and main remain untouched by this work.

- Runtime archive: GRAINFORM-0.4.11-phone-board-runtime.zip
- Exact immutable entry and SHA256 closure: MANIFEST.json
- Runtime change review: phone-board.patch against the exact 0.4.10 queue-continuity release candidate
- Browser acceptance steps and layout/storage caveats: QA-SPEC.md
- Functional/layout/area/fall timing evidence: evidence/phone-board.json
- Same-scale particle RGBA evidence: evidence/raster-board.json
- Original tests and transparent failure classification: evidence/inherited/

Serve dist using a normal static HTTP server; open MANIFEST.json's entry. The entry and complete relative import/Worker/CSS closure are inside one content-addressed build directory. Do not hot-replace that directory. There is intentionally no mutable 0.4.11 alias in this package.

## Reproduce focused checks

Run from this directory after extracting the validation archive (which includes its bundled exact baseline):

- npm test
- npm run http-smoke
- npm run high-pile (supplemental diagnostic; its strict cross-capacity tick-parity assertion is known to FAIL and is not a required gameplay gate)
- npm install, then npm run raster (official npm dependency @napi-rs/canvas 0.1.100)

The evidence archive includes original/inherited test copies, logs, exact adaptations and golden failures. The inherited runners prefer their bundled unchanged historical reference copies. The focused test commands above are a portable independent QA subset. Actual browser interaction/GPU/compositing/performance is still pending and must not be represented as passed.
