# GRAINFORM 0.4.11 phone-board QA

Local candidate only. No Site upload, deployment, main, or 0.4.10 edit was performed by this task.

## Scope
- Outer canvas: 288 × 512 (9:16). Real interior: 232 × 500, formerly 232 × 420.
- Adds 18,560 real material slots (+19.047619%). Tetromino blocks stay 24 × 24; grains stay one logical material cell with the original fixed-ID visual jitter/radius.
- One board-geometry module drives game, world, adapter, padded contour field, cache tiles, UI drawing and worker QA geometry. Frame buffers/slot identities allocate from the actual world capacity.
- Rigid automatic speed starts at 69.6 cells/s, formerly 43.2 (+61.11% speed, offsetting the added height and shortening empty-board fall by 24.66–25.36%). The additive level/piece ramp and maximum 261 cells/s are unchanged; cap is reached somewhat earlier. Soft drop stays 12 cells per command and hard drop traverses valid poses to contact. Sand gravity, speed, four-step frame rule, queues and clear/presentation barriers stay unchanged.
- Settings reuse grainform:0.4.8:grid:settings. Best score is independent at grainform:0.4.11:288x512:best. The prior best key is never overwritten or deleted by this version.

Typed-array simulation allocation grows from 48,818,655 to 58,117,440 bytes (+9,298,785); this is not total browser heap and is an explicit mobile memory risk to measure during safe-browser QA.

## Layout qualification
All horizontal rules remain byte-identical: desktop stage max 384 or 326 according to the existing height breakpoint; mobile 370 cap and existing (100dvh − 275) × .666667 cap remain. This preserves current width / grain horizontal CSS size at a fixed viewport, including the pre-existing dependence on mobile address-bar or keyboard viewport changes. Increasing canvas height is allowed to produce page scrolling. Controls remain in normal document flow in portrait; landscape keeps its pre-existing adjacent controls.

The old shell used a border-box 2:3 ratio, giving content height 1.5 × content-width + 1 CSS px. The new canvas owns its 288:512 aspect ratio and is square-scaled, eliminating that old tiny Y stretch. Y per cell changes by −1/432 = −0.002314815 CSS px; horizontal CSS grain size is exactly unchanged. This is explicitly not a claim of identical physical raster quantization at every viewport/DPR. Same-scale Node raster tests at 1/1.5/2/3 show exact old/new particle RGBA, including the newly added bottom band.

## Safe-browser acceptance, still pending
Serve dist as a static root, then open MANIFEST.json's exact entry, adding ?qa. Do not use --no-sandbox or overwrite an already served immutable build. The HTML and all module/worker/CSS references are within its content-addressed directory.

Test 390×844 DPR3, 412×915 DPR2/3, 1440×1000 DPR1/2, short mobile viewport, and landscape:
1. Verify displayed 0.4.11 and 288×512; worker version and snapshot board match. Start overlay is clickable.
2. Compare the same fixed viewport against 0.4.10: same board content width; measure grain CSS radius, not enlarged screenshot bounds. Check new bottom y499 really renders.
3. Scroll to controls when needed; all controls, pause/settings/help/restart remain reachable. Address bar expansion should follow the prior horizontal rule, not a new full-height fit.
4. Move/rotate near both walls and at the top, soft drop, hard drop, settle, bottom bridge, chain clear, high pile top-out, restart. Ensure all falling/settling frames remain visible and ACKs are ordered.
5. Seeded empty board: O/two-high pieces about 6.517s from start to contact vs 8.650s old; I about 6.867s vs 9.200s. No automatic sand speed change.
6. Storage: save a 0.4.10 record, play/reset record in 0.4.11, confirm old record retained; settings shared.
7. Capture diagnostics before/after a long high pile: actual body counts, capacity116000, pending material frames, debt, input ACK latency. Browser GPU/compositing/performance is not established by Node evidence.

## Evidence policy
Keep raw failures and old golden assertions. Geometry fixtures may be separately adapted only to the new specified floor/canvas dimensions; classify stale labels/mocks/source identity contracts separately from behavioral failures. Initial new-band raster FAIL (padded contour height) is retained even though fixed and reverified.
