# GRAINFORM 0.4.10 short empty-queue continuity experiment

LOCAL EXPERIMENT ONLY. No upload, deployment, browser launch or acceptance is claimed. Frozen `grain049-edge-hybrid/candidate` remains unchanged. Runtime manifests bind all ten files.

## Minimal runtime change

`queue-continuity.patch` changes three files against frozen hybrid:

- `ca-layer.mjs`: when one actually drawn alpha=1 frame receives its single receipt and drains the queue, save one candidate anchor containing that draw's rAF timestamp, epoch, token and explicit settling identity. Only the next accepted frame with consecutive token, same identity and arrival between anchor and anchor+1000/60ms may consume it once. Long gaps start at arrival, as before. No epsilon rounds 16.6ms up. No worker timestamp or expired startedAt is reused.
- `app.mjs`: pass the actual draw/rAF timestamp to didDraw; supply validated snapshot continuity context; invalidate on resync, full reset, restart/QA reset request, failure, pagehide, pending pause/hidden, and state/phase/piece/burst changes. Existing setPaused call and its nonempty-queue offset remain at their original location. No renderer call or worker ACK ordering is moved.
- `game.mjs`: read-only `settlingBurst` metadata resets to zero and increments only when existing setPhase actually enters settling. Snapshot includes it. This is necessary because multiple phase transitions may occur between publications; phase/pieceId alone cannot prove the same burst. Phase transition rules are byte-identical after removal of these three metadata additions.

A finite explicit didDraw(rAF) must match the last sample time and cannot issue a second receipt with the same timestamp. App uses this explicit contract. Legacy no-argument didDraw remains source-compatible for old consumers/tests; it never creates a continuity anchor. Neither mode drains multiple tokens in a single call. Nonempty timing/interpolation remains unchanged.

No renderer, motion, world/material rules, RNG, side flow, output frequency, lifespan, debt or scheduler code is changed. The full renderer/style and path sampler/validator are byte-identical. Seven full runtime files are identical before labels.

## Labels are separate

`candidate/` is the logic experiment with historical 0.4.9 labels, to keep the main patch isolated.
`release-candidate/` is the final locally assembled 0.4.10 experiment. Only the existing allowlisted label replacements were additionally applied: three files/eight occurrences (index.html five; app.mjs two; game.mjs one). `release-labels.patch` records them separately. Reversing exactly those replacements yields byte-identical experiment source. Existing 0.4.8 storage keys and historical comments are preserved. Do not copy prebuilt label-overlay files over the modified app/game: that would erase the experiment; use the supplied patch or assembled release.

## Exact timing evidence, not a speed claim

23 focused Node tests plus 63 exact recorded timing vectors cover short/long gap, boundary equality, same-rAF arrivals/ACKs, token discontinuity/duplicates, pause/resume, hidden/resync, epoch/reset, flash/checking/terminal and next burst/piece.

Candidate token1095 ended on rAF 30905.4ms; draw/ACK wall was 30911ms. Token1096 arrived 30915.59999999404ms; rAF30922.1 can reach alpha1 using the real rAF anchor. The captured original alpha was 0.3839999998210987 (the original accept ran slightly after the snapshot handler timestamp); rounded scalar recreation gives .39. These clocks are not interchangeable. Old1119→1120 has a 16.6ms rAF interval and remains alpha0.9959999999999126; it does not ACK early.

On the historical candidate piece20 capture: 25 within-piece empty gaps, 13 within the short arrival window, 9 recorded partial-alpha opportunities. Old capture: 38/32/15. Historical captures lack the new burst field; the replay uses explicitly bounded same-piece settling segments to test timing, not to replace runtime burst validation. Earlier ACK changes all subsequent execution timing. These static opportunities do not predict saved frames/ms, debt elimination or browser performance. Actual accept time may be slightly after handler-entry time and is conservative at the window boundary.

## Local reproduction

Node prerequisites match existing hybrid validation; raster gates need the already installed @napi-rs/canvas. No dependency installation is part of this task.

- node --test validation/queue-continuity.test.mjs
- node validation/replay-recorded-timing.mjs
- node validation/source-scope.mjs
- python3 validation/assemble-release.py

The fixture includes source SHA256. `extract-trace-fixture.py` requires the sibling previously materialized paired-trace inputs; replay itself is self-contained apart from runtime modules. The comparison test/source-scope needs the frozen sibling baseline.

See `GATE-RESULTS.md` for original versus adapted tests, retained FAIL classifications and exact commands. See `QA-SPEC.md` for outstanding independent browser verification. Candidate status remains pending that QA.
