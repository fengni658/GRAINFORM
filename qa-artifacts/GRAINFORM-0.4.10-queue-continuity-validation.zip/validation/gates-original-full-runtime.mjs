// Full original 0.4.9 package gates. All candidate runtime files are overlaid.
// Source packages and runtimes are read-only. Only disposable gate copies change.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const base=path.resolve(fileURLToPath(new URL('..',import.meta.url))), workspace=path.dirname(base);
const source=path.resolve(process.env.ORIGINAL049_ROOT??path.join(workspace,'grain049-original-tests'));
const candidate=path.resolve(process.env.CANDIDATE_ROOT??path.join(base,'candidate'));
const frozen=path.resolve(process.env.FROZEN_ROOT??path.join(workspace,'grain049-edge-hybrid/candidate'));
const work=path.resolve(process.env.GATES_WORK_ROOT??path.join(base,`gates-work-original-${Date.now()}`)),out=path.join(base,'evidence/gates-original');
assert(!fs.existsSync(work),'New disposable work directory required');
fs.mkdirSync(work,{recursive:true});fs.mkdirSync(out,{recursive:true});
const sha=x=>createHash('sha256').update(x).digest('hex');
const manifest=root=>Object.fromEntries(fs.readdirSync(root).sort().filter(f=>fs.statSync(path.join(root,f)).isFile()).map(f=>[f,sha(fs.readFileSync(path.join(root,f)))]));
const initial={original:manifest(source),frozen:manifest(frozen),experiment:manifest(candidate)},runs=[];
function run(label,dir,args){const r=spawnSync(process.execPath,args,{cwd:dir,encoding:'utf8',maxBuffer:32*1024*1024});const log=`${label}.log`,output=(r.stdout??'')+(r.stderr??'');fs.writeFileSync(path.join(out,log),output);const pass=output.match(/(?:#|ℹ) pass (\d+)/),fail=output.match(/(?:#|ℹ) fail (\d+)/);const result={label,command:['node',...args],exitCode:r.status,signal:r.signal,log,...pass?{pass:Number(pass[1]),fail:Number(fail[1])}:{}};runs.push(result);console.log(JSON.stringify(result));return r;}
const suites=[['npm-test',['--test','tests/ca-game.test.mjs','tests/ca-phase.test.mjs','tests/ui-ca-presentation.test.mjs','tests/ui-grid-clock.test.mjs','tests/ui-grid-renderer.test.mjs','tests/ui-grid-boot.test.mjs','tests/ui-message-clock.test.mjs']],['slots',['merge-test.mjs']],['parity',['merge-parity.mjs']],['pixels',['tests/pixel-equivalence-node.mjs']]];
for(const [kind,overlay]of [['original',null],['frozen',frozen],['experiment',candidate]]){
 const dir=path.join(work,kind);fs.cpSync(source,dir,{recursive:true});fs.mkdirSync(path.join(dir,'evidence'),{recursive:true});
 if(overlay)for(const file of Object.keys(initial[kind]))fs.copyFileSync(path.join(overlay,file),path.join(dir,file));
 for(const[name,args]of suites)run(`${kind}-${name}`,dir,args);
 for(const f of ['slot-merge-tests.json','slot-wake-parity.json','pixel-equivalence-node.json'])if(fs.existsSync(path.join(dir,'evidence',f)))fs.copyFileSync(path.join(dir,'evidence',f),path.join(out,`${kind}-${f}`));
 if(overlay){const compat=path.join(work,`${kind}-canvasmock`);fs.cpSync(dir,compat,{recursive:true});run(`${kind}-adapt-canvas-mocks`,base,[path.join(base,'validation/compat-original-mocks.mjs'),compat]);run(`${kind}-canvasmock-npm-test`,compat,suites[0][1]);for(const f of Object.keys(initial[kind]))assert.equal(sha(fs.readFileSync(path.join(compat,f))),initial[kind][f],`${kind} runtime changed by mock adaptation: ${f}`);}
}
assert.deepEqual(manifest(source),initial.original,'original source unchanged');assert.deepEqual(manifest(frozen),initial.frozen,'frozen source unchanged');assert.deepEqual(manifest(candidate),initial.experiment,'experiment changed during verification; rerun required');
const report={originalCommit:'2a8fe3b67a75df2a74a124871d80acf5543cc271',startedAt:new Date().toISOString(),source,candidate,frozen,work,allRuntimeFilesOverlaid:Object.keys(initial.experiment),runtimeSHA256:initial,sourceRuntimeUnchanged:true,runs,classification:{rawCanvasMocks:'FAIL remains FAIL when existing original mocks lack contour path methods; mock-only adapted suite is separate.',oldPixelOracle:'FAIL remains FAIL because old un-contoured screen oracle differs from the inherited contour. Compare experiment/frozen reports without rewriting old oracle.',notRun:['Browser/performance gates','Separate legacy/preview suites targeting older dist apps']}};
fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
process.exitCode=runs.some(r=>r.exitCode!==0&&!['frozen-npm-test','frozen-pixels','experiment-npm-test','experiment-pixels'].includes(r.label))?1:0;
