import fs from 'node:fs';
import assert from 'node:assert/strict';
import {MaterialFrameQueue,MATERIAL_FRAME_MS as D} from '../candidate/ca-layer.mjs';
const fixture=JSON.parse(fs.readFileSync(new URL('../evidence/recorded-timing-fixture.json',import.meta.url)));
const frame=token=>({token,ruleTick:token*4,paths:[{id:1,points:[1,1,0,2,1,68]}]});
let avoided=0;
for(const v of fixture.vectors){
 const q=new MaterialFrameQueue();q.reset(v.epoch);q.setContinuity(v.epoch,{state:'playing',phase:'settling',pieceId:20,settlingBurst:1});
 q.accept(v.epoch,[frame(v.token)],v.lastEndpointRaf-50);assert.equal(q.sample(v.lastEndpointRaf).alpha,1);assert.equal(q.didDraw(v.lastEndpointRaf).token,v.token);
 q.accept(v.epoch,[frame(v.token+1)],v.arrival);
 const expectedStart=v.withinWindow?v.lastEndpointRaf:v.arrival;assert.equal(q.startedAt,expectedStart);
 const sample=q.sample(v.nextRaf),expectedAlpha=Math.min(1,Math.max(0,(v.nextRaf-expectedStart)/D));assert.equal(sample.alpha,expectedAlpha);
 const receipt=q.didDraw(v.nextRaf);assert.equal(receipt?.token??null,expectedAlpha===1?v.token+1:null);
 if(v.source==='candidate'&&v.observedAlpha<1&&sample.alpha===1)avoided++;
 if(v.token===1095&&v.source==='candidate'){assert.equal(v.drawAckWall,30911);assert.notEqual(v.drawAckWall,v.lastEndpointRaf);assert.equal(sample.alpha,1);console.log(JSON.stringify({exact1095:v,newAlpha:sample.alpha}));}
 if(v.token===1119&&v.source==='old'){assert.ok(sample.alpha<1);console.log(JSON.stringify({exact1119:v,newAlpha:sample.alpha}));}
}
assert.equal(avoided,9);console.log(JSON.stringify({pass:true,vectors:fixture.vectors.length,candidateRecordedPartialOpportunities:avoided,summary:fixture.summary,note:fixture.note},null,2));
