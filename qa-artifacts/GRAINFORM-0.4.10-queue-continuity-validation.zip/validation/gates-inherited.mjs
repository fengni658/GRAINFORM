// Preserve inherited source-audit failures, then adapt only the validation scope.
// Runtime bytes are copied without edits; inherited files are never edited.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';import {spawnSync} from 'node:child_process';
import {auditScope,sha} from './gates-scope-audit.mjs';
const base=path.resolve(fileURLToPath(new URL('..',import.meta.url))),workspace=path.dirname(base),candidate=path.join(base,'candidate'),frozen=path.join(workspace,'grain049-edge-hybrid/candidate'),original=path.join(workspace,'grainform-sites-owner-0410/dist/experimental/0.4.9');
const work=path.resolve(process.env.GATES_WORK_ROOT??path.join(base,`gates-work-inherited-${Date.now()}`)),out=path.join(base,'evidence/gates-inherited');assert(!fs.existsSync(work),'New disposable directory required');fs.mkdirSync(work,{recursive:true});fs.mkdirSync(out,{recursive:true});
const scope=auditScope(frozen,candidate);fs.writeFileSync(path.join(out,'scope-audit.json'),JSON.stringify(scope,null,2)+'\n');
const snapshot=path.join(work,'candidate');fs.cpSync(candidate,snapshot,{recursive:true});
const runs=[];const inheritedScriptSHA256=Object.fromEntries(['hybrid-motion.mjs','hybrid-render.mjs'].map(f=>[f,sha(fs.readFileSync(path.join(base,'validation',f)))]));
function run(label,script,env={}){const r=spawnSync(process.execPath,[script],{encoding:'utf8',maxBuffer:64*1024*1024,env:{...process.env,CANDIDATE_ROOT:snapshot,...env}});const log=path.join(out,`${label}.log`);fs.writeFileSync(log,(r.stdout??'')+(r.stderr??''));const row={label,exitCode:r.status,signal:r.signal,log};runs.push(row);console.log(JSON.stringify(row));return r;}
function replaceOnce(s,from,to,label){assert.equal(s.split(from).length,2,`${label}: exact single source occurrence`);return s.replace(from,to);}
for(const name of ['hybrid-motion.mjs','hybrid-render.mjs']){
 const dir=path.join(work,'raw','validation');fs.mkdirSync(dir,{recursive:true});fs.copyFileSync(path.join(base,'validation',name),path.join(dir,name));
 run(`raw-${name.replace('.mjs','')}`,path.join(dir,name),{OLD049_ROOT:original,MOTION_EVIDENCE_ROOT:path.join(out,'raw-motion')});
}
let motion=fs.readFileSync(path.join(base,'validation/hybrid-motion.mjs'),'utf8').replace(/^#![^\n]*\n/, '');
const auditStart=motion.indexOf('async function checkFiles() {'),auditEnd=motion.indexOf('\nlet O,N;',auditStart);assert(auditStart>=0&&auditEnd>auditStart);
motion=motion.slice(0,auditStart)+`async function checkFiles(){report.byteIdentity=auditScope(oldRoot,candidateRoot);say('Exact frozen-hybrid scope audit passed: queue integration and read-only burst metadata only.');}`+motion.slice(auditEnd);
motion=`// Adapted isolated inherited motion gate; see gates-inherited.mjs for exact substitutions.\nimport {auditScope,withoutSettlingBurst,packetsWithoutSettlingBurst} from ${JSON.stringify(pathToFileURL(path.join(base,'validation/gates-scope-audit.mjs')).href)};\n`+motion;
motion=replaceOnce(motion,'equal(p.ga.snapshot(),p.gb.snapshot(),','equal(p.ga.snapshot(),withoutSettlingBurst(p.gb.snapshot()),','Game snapshot metadata');
motion=replaceOnce(motion,'equal(a,b,`${label} real Game.frame including bodyPatch/materialFrame`)','equal(a,withoutSettlingBurst(b),`${label} real Game.frame including bodyPatch/materialFrame`)','Game frame metadata');
motion=replaceOnce(motion,'equal(a.runtime.game.snapshot(),b.runtime.game.snapshot(),','equal(a.runtime.game.snapshot(),withoutSettlingBurst(b.runtime.game.snapshot()),','worker snapshot metadata');
motion=replaceOnce(motion,'equal(a.packets,b.packets,','equal(a.packets,packetsWithoutSettlingBurst(b.packets),','wire snapshot metadata');
motion=motion.replace("test: 'real-0.4.9-renderer-only-hybrid-motion'","test: 'frozen-hybrid-vs-queue-continuity-motion'");
const md=path.join(work,'adapted-motion','validation');fs.mkdirSync(md,{recursive:true});fs.writeFileSync(path.join(md,'hybrid-motion.mjs'),motion);
run('adapted-hybrid-motion',path.join(md,'hybrid-motion.mjs'),{OLD049_ROOT:frozen,MOTION_EVIDENCE_ROOT:path.join(out,'adapted-motion')});
let render=fs.readFileSync(path.join(base,'validation/hybrid-render.mjs'),'utf8');
render=`// Adapted isolated inherited render gate; all raster and alpha assertions retained.\nimport {auditScope} from ${JSON.stringify(pathToFileURL(path.join(base,'validation/gates-scope-audit.mjs')).href)};\n`+render;
render=replaceOnce(render,"for(const key of ['positionOnPath','validateMaterialFrame','MaterialFrameQueue'])assert.equal(hybrid[key].toString(),old[key].toString(),`${key} changed from 0.4.9`);","report.scopeAudit=auditScope(oldRoot,candidate);for(const key of ['positionOnPath','validateMaterialFrame'])assert.equal(hybrid[key].toString(),old[key].toString(),`${key} changed from frozen hybrid`);",'queue source identity replaced with exact pinned scope');
render=replaceOnce(render,"load(oldRoot,'game.mjs')","load(candidate,'game.mjs')",'real candidate Game renderer fixtures');
render=render.replaceAll('new old.MaterialFrameQueue','new hybrid.MaterialFrameQueue');
render=render.replace("physicsAndTimingSource:'unchanged 0.4.9 Game / MaterialFrameQueue / positionOnPath'","physicsAndTimingSource:'candidate Game and MaterialFrameQueue legacy invocation; frozen-identical physics and positionOnPath; queue continuity timing is tested separately'");
const rd=path.join(work,'adapted-render','validation');fs.mkdirSync(rd,{recursive:true});fs.writeFileSync(path.join(rd,'hybrid-render.mjs'),render);
run('adapted-hybrid-render',path.join(rd,'hybrid-render.mjs'),{OLD049_ROOT:frozen});
const renderReport=path.join(work,'adapted-render/evidence/render.json');if(fs.existsSync(renderReport))fs.copyFileSync(renderReport,path.join(out,'adapted-render.json'));
const finalScope=auditScope(frozen,candidate);assert.deepEqual(finalScope,scope,'runtime changed during verification');for(const e of scope.files)assert.equal(sha(fs.readFileSync(path.join(snapshot,e.file))),e.candidateSHA256,'runtime snapshot unchanged');
for(const [f,h]of Object.entries(inheritedScriptSHA256))assert.equal(sha(fs.readFileSync(path.join(base,'validation',f))),h,'inherited source script unchanged');
const report={inheritedScriptSHA256,work,allRuntimeFilesOverlaid:scope.files.map(x=>x.file),scope,runs,originalScriptsUnchanged:true,runtimeUnchanged:true,adaptations:['Frozen hybrid baseline replaces old renderer-only baseline for behavior comparisons.','Inherited motion source audit replaced by exact pinned queue/app changes and exact three read-only Game metadata insertions. Seven other runtime files and all ca-layer bytes outside queue remain byte-identical.','Only settlingBurst is removed from explicit candidate Game snapshot/frame and worker packet.snapshot equality; motion/world/path/ACK values remain strict.','Render queue source-identity check replaced by same exact scope audit; positionOnPath and validateMaterialFrame source remain strict-identical.','Raster fixture Game and MaterialFrameQueue use actual experiment modules; all reference drawing, path, RGBA, cache, geometry, alpha thresholds and assertions retained.','Queue continuity timing needs the separate focused rAF timing gate; inherited queue calls deliberately preserve their legacy no-timestamp protocol.'],classifications:{rawMotion:'FAIL: inherited renderer-only byte audit does not allow new app/queue/Game metadata scope; raw evidence retained.',rawRender:'FAIL: inherited queue function-source equality does not allow queue experiment; raw evidence retained.',adaptedRender:'Conservative outer-corner alpha-180 FAIL must remain FAIL; independent exact raster/cache checks separately reported.'}};
fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
const rr=fs.existsSync(renderReport)?JSON.parse(fs.readFileSync(renderReport,'utf8')):null;
const renderClassified=rr?.rgbaPass===true&&rr?.thinAndHolePass===true&&rr?.legacyContourSamePosePass===true&&rr?.gates?.legacyUnitHolds===true&&rr?.gates?.static20NoRepaint===true&&rr?.failures.length===1&&rr.failures[0].name==='known-one-cell-void'&&rr.failures[0].minCenterAlpha===124;
assert(renderClassified,'Render must have zero raster/cache differences and exactly the retained alpha-180 diagnostic failure');
assert.equal(runs.find(r=>r.label==='raw-hybrid-motion')?.exitCode,1,'raw inherited motion scope FAIL retained');
assert.equal(runs.find(r=>r.label==='raw-hybrid-render')?.exitCode,1,'raw inherited render scope FAIL retained');
assert.equal(runs.find(r=>r.label==='adapted-hybrid-render')?.exitCode,1,'adapted render diagnostic FAIL retained');
process.exitCode=runs.find(r=>r.label==='adapted-hybrid-motion')?.exitCode===0?0:1;
