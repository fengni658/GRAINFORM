import pathlib,json,hashlib,shutil,difflib,subprocess
root=pathlib.Path(__file__).resolve().parents[1];baseline=root.parent/'grain049-edge-hybrid/candidate';source=root/'candidate';out=root/'release-candidate'
manifest=json.loads((root.parent/'grain0410-hybrid-release-labels/manifest.json').read_text())
if out.exists():shutil.rmtree(out)
shutil.copytree(source,out)
for name,replacements in manifest['changedFiles'].items():
 p=out/name;s=p.read_text()
 for r in replacements:
  assert s.count(r['old'])==r['count'];s=s.replace(r['old'],r['new'])
 p.write_text(s)
rows=[];main=[];labels=[]
for p in sorted(source.iterdir()):
 assert p.is_file()
 a=(baseline/p.name).read_bytes();b=p.read_bytes();c=(out/p.name).read_bytes()
 normalized=c.decode()
 for r in manifest['changedFiles'].get(p.name,[]):normalized=normalized.replace(r['new'],r['old'])
 assert normalized.encode()==b
 rows.append({'file':p.name,'frozenSHA256':hashlib.sha256(a).hexdigest(),'experimentSHA256':hashlib.sha256(b).hexdigest(),'releaseSHA256':hashlib.sha256(c).hexdigest(),'mainChanged':a!=b,'labelChanged':b!=c})
 main.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p.name,tofile='b/'+p.name))
 labels.extend(difflib.unified_diff(b.decode().splitlines(True),c.decode().splitlines(True),fromfile='a/'+p.name,tofile='b/'+p.name))
 if p.suffix=='.mjs':subprocess.run(['node','--check',str(out/p.name)],check=True)
(root/'queue-continuity.patch').write_text(''.join(main));(root/'release-labels.patch').write_text(''.join(labels))
assert {r['file'] for r in rows if r['mainChanged']}=={'ca-layer.mjs','app.mjs','game.mjs'}
assert sum(r['labelChanged'] for r in rows)==3
(root/'RUNTIME-MANIFEST.json').write_text(json.dumps({'status':'LOCAL_EXPERIMENT_ONLY_NOT_BROWSER_ACCEPTED_NOT_DEPLOYED','version':'0.4.10','labelFiles':3,'labelReplacements':8,'files':rows},indent=2)+'\n')
print('PASS: main 3 files; label 3 files / 8 replacements; reverse-label byte identity; 8 JavaScript modules parse')
