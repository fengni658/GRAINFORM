// Exact local queue experiment scope audit against the frozen hybrid.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export const sha=value=>createHash('sha256').update(value).digest('hex');
const pins={
 'app.mjs':'4f6eaa22921777d625ca2d61e537e9af49eef7fcc579db1fc1df6e03bc499e39',
 'ca-layer.mjs':'66a6c125436d09740c0b9fbae1c04b902ffbfdc19f4fbc8ddce7ec3681e73994',
 'game.mjs':'8c6d8b14177b8f47940b86ea45aeff09e476f75f1d2bfec2f8122c6742db61f3'
};
function replaceOnce(s,from,to,label){assert.equal(s.split(from).length,2,`${label} exact single source edit`);return s.replace(from,to);}
export function auditScope(oldRoot,candidateRoot){
 const names=fs.readdirSync(oldRoot).sort();assert.deepEqual(fs.readdirSync(candidateRoot).sort(),names,'same full runtime inventory');
 const entries=names.map(file=>{const a=fs.readFileSync(path.join(oldRoot,file)),b=fs.readFileSync(path.join(candidateRoot,file));if(pins[file])assert.equal(sha(b),pins[file],`${file} exact audited experiment bytes`);else assert(a.equals(b),`${file} frozen byte identity`);return{file,baselineSHA256:sha(a),candidateSHA256:sha(b),identical:a.equals(b)};});
 const read=(root,file)=>fs.readFileSync(path.join(root,file),'utf8');
 const oldLayer=read(oldRoot,'ca-layer.mjs'),newLayer=read(candidateRoot,'ca-layer.mjs');
 const outsideQueue=s=>{const from=s.indexOf('export class MaterialFrameQueue {'),to=s.indexOf('\nfunction hashUnit(',from);assert(from>=0&&to>from);return s.slice(0,from)+'<exact-pinned-MaterialFrameQueue>\n'+s.slice(to);};
 assert.equal(outsideQueue(newLayer),outsideQueue(oldLayer),'all ca-layer bytes outside exact pinned MaterialFrameQueue unchanged: includes path/style/renderer');
 let game=read(candidateRoot,'game.mjs');
 game=replaceOnce(game,"this.phase='ready';this.settlingBurst=0;","this.phase='ready';",'game reset metadata');
 game=replaceOnce(game,"this.phase=phase;if(phase==='settling')this.settlingBurst++;","this.phase=phase;",'game phase metadata counter');
 game=replaceOnce(game,'phase:this.phase,settlingBurst:this.settlingBurst,','phase:this.phase,','game snapshot metadata');
 assert.equal(game,read(oldRoot,'game.mjs'),'Game differs only by three read-only burst metadata insertions');
 let app=read(candidateRoot,'app.mjs');
 const changes=[
 ["const bodyStore = new GridBodyStore({ onResync: request => { presentation.invalidateContinuity(); worker?.postMessage({type:'resync', ...request}); } });","const bodyStore = new GridBodyStore({ onResync: request => worker?.postMessage({type:'resync', ...request}) });"],
 ['const completion = presentation.didDraw(timestamp);','const completion = presentation.didDraw();'],
 ["if (name === 'restart' || name === 'qa-bridge') { presentation.invalidateContinuity(); releaseAll(); }","if (name === 'restart' || name === 'qa-bridge') releaseAll();"],
 ['function fail(message) {\n  presentation.invalidateContinuity();','function fail(message) {'],
 ['          presentation.setContinuity(data.epoch, snapshot, accepted.full);\n          if (pauseRequested || document.hidden) presentation.invalidateContinuity();\n',''],
 ["window.addEventListener('pagehide', () => { presentation.invalidateContinuity(); releaseAll();","window.addEventListener('pagehide', () => { releaseAll();"]
 ];
 changes.forEach(([from,to],i)=>{app=replaceOnce(app,from,to,`app continuity integration ${i+1}`);});
 assert.equal(app,read(oldRoot,'app.mjs'),'all remaining app bytes unchanged, including original pause offsets/order');
 return{passed:true,allowedFiles:Object.keys(pins),files:entries,pinnedCandidateSHA256:pins,unchangedOutsideQueue:true,gameMetadataOnly:true,exactAppIntegrationEdits:changes.length,normalization:'Only the new settlingBurst property is removed from explicit Game snapshot/frame and worker packet.snapshot equality comparisons. No motion/path/ACK fields are normalized.'};
}
export function withoutSettlingBurst(snapshot){
 if(!Object.hasOwn(snapshot,'settlingBurst'))return snapshot;
 assert.equal(snapshot.modelKind,'multi-cell-path-ca','Only real Game snapshots/frames may be normalized');
 assert(Number.isSafeInteger(snapshot.settlingBurst)&&snapshot.settlingBurst>=0,'burst metadata is a nonnegative safe integer');
 const {settlingBurst,...rest}=snapshot;return rest;
}
export function packetsWithoutSettlingBurst(packets){return packets.map(p=>p.snapshot?{...p,snapshot:withoutSettlingBurst(p.snapshot)}:p);}
