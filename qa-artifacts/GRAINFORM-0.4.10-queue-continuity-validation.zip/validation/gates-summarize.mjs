// Verify stored evidence and produce a scoped gate report without relabeling FAILs.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';import {spawnSync} from 'node:child_process';
import {sha,auditScope} from './gates-scope-audit.mjs';
const base=path.resolve(fileURLToPath(new URL('..',import.meta.url))),workspace=path.dirname(base),ev=path.join(base,'evidence'),read=p=>JSON.parse(fs.readFileSync(path.join(ev,p),'utf8'));
const o=read('gates-original/report.json'),i=read('gates-inherited/report.json'),m=read('gates-inherited/adapted-motion/motion.json'),r=read('gates-inherited/adapted-render.json'),rel=read('gates-release/report.json'),func=read('gates-release/functional-label-report.json');
assert.equal(m.status,'passed');assert.equal(i.runs.find(x=>x.label==='adapted-hybrid-motion').exitCode,0);assert.equal(r.pass,false);assert.equal(r.failures.length,1);assert.equal(r.failures[0].name,'known-one-cell-void');assert.equal(r.rgbaPass,true);assert.equal(r.gates.conservativeCornerAlpha180,false);assert.equal(func.status,'passed');
const counts=file=>{const s=fs.readFileSync(path.join(ev,file),'utf8'),match=k=>Number(s.match(new RegExp('(?:#|ℹ) '+k+' (\\d+)'))?.[1]);return {tests:match('tests'),pass:match('pass'),fail:match('fail')};};
const tests={original:counts('gates-original/original-npm-test.log'),frozenRaw:counts('gates-original/frozen-npm-test.log'),experimentRaw:counts('gates-original/experiment-npm-test.log'),frozenMocks:counts('gates-original/frozen-canvasmock-npm-test.log'),experimentMocks:counts('gates-original/experiment-canvasmock-npm-test.log'),releaseMocks:counts('gates-release/release-canvasmock-npm-test.log'),releaseBoot:counts('gates-release/release-functional-boot.log')};
assert.deepEqual(tests.original,{tests:36,pass:36,fail:0});assert.deepEqual(tests.experimentMocks,tests.original);assert.deepEqual(tests.frozenMocks,tests.original);assert.deepEqual(tests.experimentRaw,{tests:36,pass:32,fail:4});assert.deepEqual(tests.frozenRaw,tests.experimentRaw);assert.deepEqual(tests.releaseMocks,{tests:36,pass:35,fail:1});
const pixels=Object.fromEntries(['original','frozen','experiment'].map(k=>[k,read(`gates-original/${k}-pixel-equivalence-node.json`)]));assert.deepEqual(pixels.experiment,pixels.frozen,'complete legacy pixel reports remain byte-for-byte-data equal');assert.equal(pixels.experiment.failures.length,70);assert.equal(pixels.original.failures.length,0);
const parity=Object.fromEntries(['original','frozen','experiment'].map(k=>[k,read(`gates-original/${k}-slot-wake-parity.json`)]));assert.deepEqual(parity.original,parity.experiment);assert.deepEqual(parity.frozen,parity.experiment);
const slots=read('gates-original/experiment-slot-merge-tests.json');assert.equal(slots.passed,true);assert.equal(slots.results.length,7);
const scope=auditScope(path.join(workspace,'grain049-edge-hybrid/candidate'),path.join(base,'candidate'));assert.deepEqual(scope,i.scope);for(const[f,h]of Object.entries(rel.releaseSHA256))assert.equal(sha(fs.readFileSync(path.join(base,'release-candidate',f))),h,'release hash still matches tests');
const inventory=root=>{const out={};function walk(dir,prefix=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const rel=path.join(prefix,e.name),p=path.join(dir,e.name);if(e.isDirectory())walk(p,rel);else out[rel]=sha(fs.readFileSync(p));}}walk(root);return out;};
const originalTests=inventory(path.join(o.source,'tests')),testSources={originalTestsSHA256:originalTests,rawCopiesIdentical:{},mockCopiesChangedFiles:{}};
for(const label of ['original','frozen','experiment']){assert.deepEqual(inventory(path.join(o.work,label,'tests')),originalTests);testSources.rawCopiesIdentical[label]=true;}
for(const label of ['frozen-canvasmock','experiment-canvasmock']){const copy=inventory(path.join(o.work,label,'tests'));const changed=Object.keys(originalTests).filter(k=>originalTests[k]!==copy[k]);assert.deepEqual(changed.sort(),['ui-ca-presentation.test.mjs','ui-grid-boot.test.mjs']);testSources.mockCopiesChangedFiles[label]=changed;}
assert.deepEqual(inventory(path.join(rel.work,'tests')),inventory(path.join(o.work,'experiment-canvasmock/tests')),'release uses exactly same mock-only test adaptation');
fs.writeFileSync(path.join(ev,'gates-test-source-audit.json'),JSON.stringify(testSources,null,2)+'\n');
for(const name of ['hybrid-motion','hybrid-render']){const raw=path.join(base,'validation',`${name}.mjs`),adapted=path.join(i.work,name==='hybrid-motion'?'adapted-motion':'adapted-render','validation',`${name}.mjs`);const d=spawnSync('diff',['-u',raw,adapted],{encoding:'utf8'});assert([0,1].includes(d.status));fs.writeFileSync(path.join(ev,'gates-inherited',`${name}-adaptation.diff`),d.stdout);}
for(const name of ['ui-ca-presentation','ui-grid-boot']){const d=spawnSync('diff',['-u',path.join(o.source,'tests',`${name}.test.mjs`),path.join(o.work,'experiment-canvasmock/tests',`${name}.test.mjs`)],{encoding:'utf8'});assert.equal(d.status,1);fs.writeFileSync(path.join(ev,'gates-original',`${name}-mock-only.diff`),d.stdout);}
const summary={status:'Scoped behavioral equivalence PASS; retained inherited FAILs are not a blanket all-green result',tests,slots:slots.results.length,parity:{comparedFrames:parity.experiment.comparedFrames,comparedRuleTicks:parity.experiment.comparedRuleTicks,trajectoryHash:parity.experiment.trajectoryHash},pixels:{comparisons:pixels.experiment.drawComparisons,originalFailures:0,frozenFailures:70,experimentFailures:70,experimentEqualsFrozenReport:true,rawCellComparisons:pixels.experiment.results.filter(x=>x.rawCells).length,rawCellAllEqual:pixels.experiment.results.filter(x=>x.rawCells).every(x=>x.equal),cacheComparisons:pixels.experiment.results.filter(x=>x.cache).length,allCachesEqual:pixels.experiment.results.filter(x=>x.cache).every(x=>x.cache.equal)},motion:m.totals,render:r.summary,retainedCornerFailure:r.failures[0],scope,releaseSHA256:rel.releaseSHA256,testSourceAudit:'gates-test-source-audit.json',finishedAt:new Date().toISOString()};fs.writeFileSync(path.join(ev,'gates-summary.json'),JSON.stringify(summary,null,2)+'\n');
const text=`# Queue-continuity local gate results

## Conclusion

The experiment passes the scoped motion, path, mass/identity, ordered-ACK, worker-clock and exact raster/cache comparisons against the frozen hybrid. This is not an all-green claim: original Canvas-mock FAILs, the old pixel-oracle FAIL, inherited renderer-only scope-check FAILs, the conservative outer-corner alpha FAIL, and the release label-expectation FAIL are all preserved.

All 10 runtime files were overlaid into disposable original-test copies, including app.mjs and game.mjs. Frozen sources, experiment runtime, release runtime and original test sources were not edited by this gate work. Hashes bind each run to the actual bytes. Final release (0.4.10) receives its own full-runtime entry test.

## Results

| Gate | Original 0.4.9 | Frozen hybrid | Queue experiment |
|---|---:|---:|---:|
| Original package npm test, untouched mocks/assertions | 36 PASS / 0 FAIL | 32 PASS / 4 FAIL | 32 PASS / 4 FAIL |
| Same npm test, only Canvas mock capabilities adapted | n/a | 36 PASS / 0 FAIL | 36 PASS / 0 FAIL |
| Slot tests | 7/7 PASS | 7/7 PASS | 7/7 PASS |
| Exact six-batch/clear/support-cut parity | PASS | PASS | PASS |
| Unchanged legacy pixel oracle | 144 comparisons, 0 FAIL | 144 comparisons, 70 FAIL | 144 comparisons, 70 FAIL |

Parity is identical over 551 compared frames and 330 rule ticks. Trajectory SHA-256: ${parity.experiment.trajectoryHash}. Complete experiment and frozen legacy pixel reports are equal, including all 70 failure records. All ${summary.pixels.rawCellComparisons} raw-cell comparisons and all ${summary.pixels.cacheComparisons} non-fallback cache comparisons are equal to the legacy reference; inherited contoured-screen differences remain FAILs.

## Real imported motion/path/ACK evidence

Adapted inherited motion gate: PASS, ${m.totals.comparisons.toLocaleString('en-US')} strict comparisons, ${m.totals.worldComparisons} world comparisons, ${m.totals.snapshots} snapshots, ${m.totals.patches} frame/patch comparisons.

- 659,928 real audited unit actions and 659,928 verified material path legs
- 2,206,375 analytic and baseline path-sample comparisons, retaining all 68-stage holds and the dist2 two-horizontal-legs-then-down turn
- 382 original single-object ACKs; reversed queue, future, duplicate and out-of-order receipts rejected
- 140 terminal frames held without clear/spawn or undisturbed motion; actual spanning clear starts only after final single ACK
- Six pieces, first natural fall; exact occupancy, identity/generation and per-color mass conservation; support-removal locality and free-slot reuse
- 240 worker control ticks at 60 Hz; active-wall/control conservation and the inherited up-to-four material-rule steps unchanged

The inherited motion fixtures invoke the queue's legacy no-rAF-argument protocol. They prove preserved baseline behavior, not activated short-gap continuity; the separate focused timing gate owns that claim.

## Raster and geometry evidence

- 185 draw poses at DPR 1 / 1.5 / 2
- 555 exact screen RGBA comparisons and 555 cache comparisons; 333,745,920 total pixels compared; zero differing pixels
- 18 selected actual material-path frames; 15 geometry fixtures; 20 static draws retain zero extra repaint/rebuild
- Conservative outer-corner alpha-180 diagnostic: FAIL retained. Fixture known-one-cell-void, ID 698, logical center alpha 124 at 8×; known hole alpha is 0
- The same corner matches original r13 pixels/contour. At 8× and 64×, the jittered glyph center clips to alpha 0, with approximately 39.1% and 41.0% glyph alpha still visible. This is partial inherited clipping; no claim of universal no-hole behavior is made

The render report's top-level pass remains false and process exit remains 1. Exact RGBA/cache and bounded thin/hole checks are reported separately as PASS.

## Exact adaptations

1. The original package's npm test list is run as published. Only the disposable mock-capability copy changes two mock classes: ui-ca-presentation gains ordinary path/clip/stroke methods and counts arc paint on fill instead of path construction; ui-grid-boot gains quadraticCurveTo/stroke. Assertions and runtime remain untouched. Raw failing copies are separate.
2. Raw inherited hybrid-motion and hybrid-render are run unchanged first. Motion fails at unauthorized app.mjs under its renderer-only allowlist; render fails at MaterialFrameQueue function-source equality. Both failures are retained as scope incompatibilities.
3. Adapted motion uses frozen hybrid as baseline and audits exact pinned queue/app bytes. All seven other files and all ca-layer code outside MaterialFrameQueue remain identical. Game source differs only at the three exact settlingBurst metadata insertions. App's six exact integration edit sites are checked; original pause-offset order remains unchanged.
4. Equality removes ONLY settlingBurst from explicit candidate Game snapshots/frames and worker packet.snapshot objects. World state, physical timing, position, path, material frame, patch, receipt and ACK fields are never normalized.
5. Adapted render replaces only the queue function-source restriction with that exact scope audit. positionOnPath and validateMaterialFrame remain source-identical. Actual candidate Game and MaterialFrameQueue feed the raster fixtures; all RGBA/cache/reference drawing, geometry and alpha assertions stay in force.
6. One validation-generator shebang placement error was fixed before a clean full rerun; the first failed generator log/report remain under attempt-* evidence. No runtime was altered for it.

## Final 0.4.10 release entry

All 10 release-candidate files were overlaid into a new isolated original-test copy, bound to releaseSHA256 in evidence/gates-release/report.json.

- Original 36-test suite after the same mock-only adaptation: 35 PASS / 1 FAIL. The remaining original source audit hardcodes /0\\.4\\.9 测试版/ and therefore rejects the correct 0.4.10 HTML label. The assertion and failure log remain unchanged; this is not reported as 36/36 PASS
- Separate unchanged functional UI boot test: 1/1 PASS (real worker runtime; start/drop/fullsync/highlight/restart/stale messages)
- Separate 0.4.10 label checks: 7/7 PASS (export, snapshot, HTML title, app VERSION, worker name, and absence of old 0.4.9 app/HTML labels)
- Existing 0.4.8 grid storage namespaces remain unchanged. An initial custom label check incorrectly assumed storage migration; that test-author assumption was corrected to the approved label scope, with the attempt source preserved. No product failure or runtime change resulted

## Evidence and reproduction

- evidence/gates-summary.json: compact verified aggregate with exact runtime hashes
- evidence/gates-original/report.json and *.log / *-pixel-equivalence-node.json / *-slot-*.json
- evidence/gates-inherited/report.json, raw-hybrid-*.log, adapted-motion/motion.json, adapted-render.json
- evidence/gates-inherited/*-adaptation.diff: exact inherited validation edits
- evidence/gates-original/*-mock-only.diff and evidence/gates-test-source-audit.json: test source integrity
- evidence/gates-release/report.json, release-canvasmock-npm-test.log, release-functional-boot.log, functional-label-report.json

Run node validation/gates-original-full-runtime.mjs, node validation/gates-inherited.mjs, node validation/gates-release-entry.mjs, node validation/gates-release-functional.mjs, then node validation/gates-summarize.mjs from this package. Runners create new disposable work directories. gates-release-entry intentionally exits 1 on the retained hardcoded-label FAIL; the inherited render subprocess also intentionally exits 1 on its retained corner diagnostic. Never interpret aggregate orchestration success as erasure of these failures.

No browser/GPU, real display cadence, interactive latency or deployment validation was performed. No upload, deploy or source labeling was done by this gate work.
`;
fs.writeFileSync(path.join(base,'GATE-RESULTS.md'),text);console.log(JSON.stringify({report:path.join(base,'GATE-RESULTS.md'),summary:path.join(ev,'gates-summary.json'),tests,motion:m.totals,render:r.summary}));
