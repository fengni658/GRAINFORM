import pathlib,zipfile,hashlib,json
r=pathlib.Path(__file__).resolve().parents[1]
required=['GATE-RESULTS.md','evidence/independent-source-review.md','RUNTIME-MANIFEST.json']
for name in required:assert (r/name).is_file(),f'Missing {name}'
def make(name,files):
 p=r/name
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for src,arc in sorted(files,key=lambda x:x[1]):
   info=zipfile.ZipInfo(arc,date_time=(2026,10,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,src.read_bytes())
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 return {'name':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'entries':len(files)}
runtime=make('GRAINFORM-0.4.10-queue-continuity-runtime.zip',[(p,p.name) for p in (r/'release-candidate').iterdir()])
files=[]
for folder in ['candidate','release-candidate','evidence','validation']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files.append((p,str(p.relative_to(r))))
for name in ['README.md','GATE-RESULTS.md','QA-SPEC.md','RUNTIME-MANIFEST.json','queue-continuity.patch','release-labels.patch']:files.append((r/name,name))
evidence=make('GRAINFORM-0.4.10-queue-continuity-validation.zip',files)
(r/'PACKAGES.json').write_text(json.dumps({'status':'LOCAL_ONLY_NO_UPLOAD_NO_DEPLOYMENT_BROWSER_QA_PENDING','packages':[runtime,evidence]},indent=2)+'\n');print((r/'PACKAGES.json').read_text())
