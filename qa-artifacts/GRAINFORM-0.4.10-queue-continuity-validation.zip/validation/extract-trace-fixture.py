import json,pathlib,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
source=root.parent/'grain0410-hybrid-external/paired-trace/extracted/evidence'
out={'note':'Static recorded timing opportunities only. Historical snapshots lack settlingBurst; within-piece settling is checked from recorded phases, not a runtime identity substitute. ACK changes future execution timing; no performance claim.', 'sources':{},'vectors':[]}
for v in ['candidate','old']:
 p=source/f'perf-{v}-dpr2-high.json';d=json.loads(p.read_text());a=d['audit'];out['sources'][v]={'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 for r in a['receipts']:
  if r['pendingAfter']!=0:continue
  f=next((f for f in a['frames'] if f['start']<=r['wall']<=f['wall']),None)
  if not f or f['pieces']!=20:continue
  sn=next((s for s in a['snapshots'] if s['presentationToken']==r['token']+1 and s['wall']>r['wall']),None)
  if not sn or sn['pieces']!=20 or sn['phase']!='settling':continue
  following=next((ff for ff in a['frames'] if ff['stamp']>f['stamp'] and ff['start']>=sn['wall']),None)
  sample=next((s for s in a['samples'] if following['start']<=s['wall']<=following['wall'] and s['token']==r['token']+1),None)
  if not sample:raise Exception('missing next sample')
  within=0<=sn['wall']-f['stamp']<=1000/60
  out['vectors'].append({'source':v,'token':r['token'],'epoch':r['epoch'],'lastEndpointRaf':f['stamp'],'drawAckWall':r['wall'],'arrival':sn['wall'],'nextRaf':following['stamp'],'observedAlpha':sample['alpha'],'withinWindow':within,'avoidsPartialInRecordedTimeline':within and following['stamp']-f['stamp']>=1000/60 and sample['alpha']<1})
out['summary']={v:{'withinPieceEmpty':sum(x['source']==v for x in out['vectors']),'withinWindow':sum(x['source']==v and x['withinWindow'] for x in out['vectors']),'avoidsPartial':sum(x['source']==v and x['avoidsPartialInRecordedTimeline'] for x in out['vectors'])} for v in ['candidate','old']}
(root/'evidence/recorded-timing-fixture.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary'],indent=2))
