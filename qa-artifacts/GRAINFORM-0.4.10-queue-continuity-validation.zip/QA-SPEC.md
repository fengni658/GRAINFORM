# Independent browser QA handoff (NOT RUN)

Use only an isolated local server rooted at `release-candidate/`; no live site, upload, deployment or frozen-source write. Verify all served runtime bytes against releaseSHA256 in RUNTIME-MANIFEST.json, including normal and warm reload. Version label alone does not prove asset freshness.

1. Entry smoke: `/`, `/index.html`, `/?qa&seed=123`, and `/?qa&seed=123&display=original`. Verify 0.4.10 app/snapshot/Worker labels, worker initialization, mobile layout, existing settings/best-score persistence.
2. Instrument actual rAF timestamp separately from performance.now before/after draw, arrival time, epoch/pieceId/settlingBurst/token, alpha and ACK. One final endpoint draw must precede exactly one receipt; no duplicate, skip or multiple receipts per rAF. Instrumentation must not alter draw scheduling.
3. Within a continuous settling burst, find a naturally short empty queue. The next token may reuse ONLY the last actual endpoint-rAF anchor when arrival-anchor <=1000/60ms. No rounding tolerance. No stale startedAt/worker-generated-time anchor. Nonempty queue traces retain original timeline.
4. Verify longer computation/delivery gaps start at arrival and never catch up from an old anchor; no output-frequency changes, debt clipping, skipped endpoints or lifespan changes. Show debt honestly; zero is not an acceptance criterion.
5. Interrupt both empty and nonempty queues: pause/resume, focus loss, hidden/visible, pagehide/pageshow, restart, full resync, error recovery/new epoch. Empty anchor must be invalidated; nonempty pose and pause offset remain frozen/resumed as before.
6. Cross terminal settlement, next rigid piece, checking/flash/clear/cascade and same-piece fresh settling burst. Last alpha1 ACK must still gate clearing/spawn. Missing burst metadata must fall back safely. Confirm Game counter changes only on actual entering-settling transitions, including transitions not individually published.
7. Normal-speed visual comparison of frozen hybrid and this release with same seed/input: motion/world/material path/endpoints/colors/identity/side-flow, no extra smoothing/shortcuts, no contour/render changes. Keep the existing partial outer-corner diagnostic as an inherited limitation, not a new PASS.
8. Report PASS/FAIL/not-run separately. Scope is one local timing correction, not a new broad trace campaign. Historical 9 opportunities are not a promised runtime gain; describe only observed outcomes.

No independent browser QA was executed for this deliverable. Node DOM mocks are not a substitute for native scheduling, compositing or perceived-motion acceptance.
