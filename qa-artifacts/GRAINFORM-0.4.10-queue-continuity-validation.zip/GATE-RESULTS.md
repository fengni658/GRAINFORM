# Queue-continuity local gate results

## Conclusion

The experiment passes the scoped motion, path, mass/identity, ordered-ACK, worker-clock and exact raster/cache comparisons against the frozen hybrid. This is not an all-green claim: original Canvas-mock FAILs, the old pixel-oracle FAIL, inherited renderer-only scope-check FAILs, the conservative outer-corner alpha FAIL, and the release label-expectation FAIL are all preserved.

All 10 runtime files were overlaid into disposable original-test copies, including app.mjs and game.mjs. Frozen sources, experiment runtime, release runtime and original test sources were not edited by this gate work. Hashes bind each run to the actual bytes. Final release (0.4.10) receives its own full-runtime entry test.

## Results

| Gate | Original 0.4.9 | Frozen hybrid | Queue experiment |
|---|---:|---:|---:|
| Original package npm test, untouched mocks/assertions | 36 PASS / 0 FAIL | 32 PASS / 4 FAIL | 32 PASS / 4 FAIL |
| Same npm test, only Canvas mock capabilities adapted | n/a | 36 PASS / 0 FAIL | 36 PASS / 0 FAIL |
| Slot tests | 7/7 PASS | 7/7 PASS | 7/7 PASS |
| Exact six-batch/clear/support-cut parity | PASS | PASS | PASS |
| Unchanged legacy pixel oracle | 144 comparisons, 0 FAIL | 144 comparisons, 70 FAIL | 144 comparisons, 70 FAIL |

Parity is identical over 551 compared frames and 330 rule ticks. Trajectory SHA-256: 31205449eb19668c2e2b8a9a9e1b7fa9dff7bd608772814f195b0ec5038ac5bb. Complete experiment and frozen legacy pixel reports are equal, including all 70 failure records. All 72 raw-cell comparisons and all 72 non-fallback cache comparisons are equal to the legacy reference; inherited contoured-screen differences remain FAILs.

## Real imported motion/path/ACK evidence

Adapted inherited motion gate: PASS, 18,389,759 strict comparisons, 1514 world comparisons, 1463 snapshots, 1067 frame/patch comparisons.

- 659,928 real audited unit actions and 659,928 verified material path legs
- 2,206,375 analytic and baseline path-sample comparisons, retaining all 68-stage holds and the dist2 two-horizontal-legs-then-down turn
- 382 original single-object ACKs; reversed queue, future, duplicate and out-of-order receipts rejected
- 140 terminal frames held without clear/spawn or undisturbed motion; actual spanning clear starts only after final single ACK
- Six pieces, first natural fall; exact occupancy, identity/generation and per-color mass conservation; support-removal locality and free-slot reuse
- 240 worker control ticks at 60 Hz; active-wall/control conservation and the inherited up-to-four material-rule steps unchanged

The inherited motion fixtures invoke the queue's legacy no-rAF-argument protocol. They prove preserved baseline behavior, not activated short-gap continuity; the separate focused timing gate owns that claim.

## Raster and geometry evidence

- 185 draw poses at DPR 1 / 1.5 / 2
- 555 exact screen RGBA comparisons and 555 cache comparisons; 333,745,920 total pixels compared; zero differing pixels
- 18 selected actual material-path frames; 15 geometry fixtures; 20 static draws retain zero extra repaint/rebuild
- Conservative outer-corner alpha-180 diagnostic: FAIL retained. Fixture known-one-cell-void, ID 698, logical center alpha 124 at 8×; known hole alpha is 0
- The same corner matches original r13 pixels/contour. At 8× and 64×, the jittered glyph center clips to alpha 0, with approximately 39.1% and 41.0% glyph alpha still visible. This is partial inherited clipping; no claim of universal no-hole behavior is made

The render report's top-level pass remains false and process exit remains 1. Exact RGBA/cache and bounded thin/hole checks are reported separately as PASS.

## Exact adaptations

1. The original package's npm test list is run as published. Only the disposable mock-capability copy changes two mock classes: ui-ca-presentation gains ordinary path/clip/stroke methods and counts arc paint on fill instead of path construction; ui-grid-boot gains quadraticCurveTo/stroke. Assertions and runtime remain untouched. Raw failing copies are separate.
2. Raw inherited hybrid-motion and hybrid-render are run unchanged first. Motion fails at unauthorized app.mjs under its renderer-only allowlist; render fails at MaterialFrameQueue function-source equality. Both failures are retained as scope incompatibilities.
3. Adapted motion uses frozen hybrid as baseline and audits exact pinned queue/app bytes. All seven other files and all ca-layer code outside MaterialFrameQueue remain identical. Game source differs only at the three exact settlingBurst metadata insertions. App's six exact integration edit sites are checked; original pause-offset order remains unchanged.
4. Equality removes ONLY settlingBurst from explicit candidate Game snapshots/frames and worker packet.snapshot objects. World state, physical timing, position, path, material frame, patch, receipt and ACK fields are never normalized.
5. Adapted render replaces only the queue function-source restriction with that exact scope audit. positionOnPath and validateMaterialFrame remain source-identical. Actual candidate Game and MaterialFrameQueue feed the raster fixtures; all RGBA/cache/reference drawing, geometry and alpha assertions stay in force.
6. One validation-generator shebang placement error was fixed before a clean full rerun; the first failed generator log/report remain under attempt-* evidence. No runtime was altered for it.

## Final 0.4.10 release entry

All 10 release-candidate files were overlaid into a new isolated original-test copy, bound to releaseSHA256 in evidence/gates-release/report.json.

- Original 36-test suite after the same mock-only adaptation: 35 PASS / 1 FAIL. The remaining original source audit hardcodes /0\.4\.9 测试版/ and therefore rejects the correct 0.4.10 HTML label. The assertion and failure log remain unchanged; this is not reported as 36/36 PASS
- Separate unchanged functional UI boot test: 1/1 PASS (real worker runtime; start/drop/fullsync/highlight/restart/stale messages)
- Separate 0.4.10 label checks: 7/7 PASS (export, snapshot, HTML title, app VERSION, worker name, and absence of old 0.4.9 app/HTML labels)
- Existing 0.4.8 grid storage namespaces remain unchanged. An initial custom label check incorrectly assumed storage migration; that test-author assumption was corrected to the approved label scope, with the attempt source preserved. No product failure or runtime change resulted

## Evidence and reproduction

- evidence/gates-summary.json: compact verified aggregate with exact runtime hashes
- evidence/gates-original/report.json and *.log / *-pixel-equivalence-node.json / *-slot-*.json
- evidence/gates-inherited/report.json, raw-hybrid-*.log, adapted-motion/motion.json, adapted-render.json
- evidence/gates-inherited/*-adaptation.diff: exact inherited validation edits
- evidence/gates-original/*-mock-only.diff and evidence/gates-test-source-audit.json: test source integrity
- evidence/gates-release/report.json, release-canvasmock-npm-test.log, release-functional-boot.log, functional-label-report.json

Run node validation/gates-original-full-runtime.mjs, node validation/gates-inherited.mjs, node validation/gates-release-entry.mjs, node validation/gates-release-functional.mjs, then node validation/gates-summarize.mjs from this package. Runners create new disposable work directories. gates-release-entry intentionally exits 1 on the retained hardcoded-label FAIL; the inherited render subprocess also intentionally exits 1 on its retained corner diagnostic. Never interpret aggregate orchestration success as erasure of these failures.

No browser/GPU, real display cadence, interactive latency or deployment validation was performed. No upload, deploy or source labeling was done by this gate work.
