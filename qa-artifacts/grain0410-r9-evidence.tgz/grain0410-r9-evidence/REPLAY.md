# Self-contained offline reproduction
The authoritative regressions are in the delta, to run on a complete r8 overlay:
npm test; npm run verify:slots; npm run verify:pixels; npm run verify:motion; npm run verify:local; npm run verify:sync.
These include the full new-physics references. Historical old551 exact trajectories are intentionally not used.

Standalone replay here carries all source imports:
node replay/compare.mjs
node replay/six-check.mjs
node replay/dense-check.mjs wakefront
node replay/tail-probe.mjs
node replay/scan.mjs
node replay/visual-full.mjs
compare generates replay/evidence/runs.json before scan/visual-full. PNG endpoints can be encoded using ffmpeg -framerate60. @napi-rs/canvas is needed only for raster scripts; the dot dependency locator is retained, use CANVAS_REQUIRE_FROM where supported or an equivalent installed package resolution. Node core suffices for count/quiet/tail checks. Generated replay outputs are separate from delivered evidence.
The visual baseline is the explicitly failed unified-dt model. no-sync is identical new physics before the independently exact B optimization. Do not treat offline replay timing as browser fps. Original evidence logs preserve the tested local source paths; all minimal imports needed to rerun are included in the repository delta or replay.
