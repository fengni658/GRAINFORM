# R9 B-only sync equivalence

Baseline: `../grain0410-wakefront-micro/model/` (new R9 physics, original sync).

Candidate: `../grain0410-edge-r9/` (the identical new physics plus B's direct-slot sync).

This validation makes no timing or performance claim. In particular, the earlier B-only R8 Node performance percentages are not measurements of R9.

## Result

Both verification processes exited 0. No failed, skipped or incomplete stage remains in this B-only verification.

- 1,984 complete Game states and 2,316 world states match exactly.
- 2,105 ordered body-patch comparisons pass, including revisions and material paths.
- 225 actual-path RGBA comparisons match byte-for-byte.
- 320 generation-reuse cycles pass.
- 8,492,126 published body-reference freeze checks were applied (this is not a count of unique objects); 20 retained historical patch snapshots remain unchanged.
- Dense drop 20 takes 159 control ticks and ends at 46,080 live grains; all 23 dense drops complete, ending at 52,992 live grains. Baseline and candidate agree at every checked state.
- The separate actual-clear fixture passes 61 states, removes all 2,488 grains and returns to falling; four retained patch snapshots remain unchanged.
- Final runtime hashes match the hashes taken before the run for both inputs. Only the intended sync implementation differs between baseline and candidate.

Machine-readable results: `sync-parity.json`, `sync-clear-parity.json`, and `sync-runtime-hashes.json`. Full progress/output: `sync-parity.log`, `sync-clear-parity.log`.

## Scope

`verify-sync.mjs` adapts the earlier B verification without changing runtime code or weakening state assertions. It checks complete Game snapshots and exported bodies, world snapshots, ordered caches/upsert/removal collections, revisions and consumed revisions, wake-chunk insertion order, complete material paths, full/reset and accumulated delta behavior, generation reuse and retained historical body objects. New bodies retain all fields; the original x/y/color/sleep changed predicate is preserved.

The original command streams remain: seed 1 dense 23 drops with `i=j+50` shift/rotation inputs, seed 91571 six drops, and one shifted pre-existing-bed fixture. The dense stream is not the separate centered first/shifted-second fixture; different inputs can produce different settling tick counts. The existing 1,000-step safety cap is retained and no exact timing expectation is substituted. All 320 direct reuse cycles are retained.

Published body objects are frozen and historical patch references are retained across later motion, sleep/wake, removal, generation reuse, pause and reset. Additional actual-path RGBA comparisons use the same backend and widths 324/486/648, checking beginning, intermediate and endpoint samples.

`verify-sync-clear.mjs` separately retains the actual 2,488-grain clear assertion, complete ordered frame equality and historical body immutability through the final presentation gate and 12 flash ticks.

The run's relevant runtime hashes are recorded in `sync-runtime-hashes.json`; only ca-adapter.mjs differs between the two inputs. The baseline/candidate ca-world, ca-frame-world, game, ca-layer and ca-contour files were confirmed byte-identical. Final verification checks that these files were not changed during the run.

## Reproduction

From the workspace root:

```sh
node grain0410-r9-evidence/verify-sync.mjs
node grain0410-r9-evidence/verify-sync-clear.mjs
```

The first script uses the pre-existing @napi-rs/canvas installation; `CANVAS_MODULE` can point to an equivalent installed module elsewhere. Logs/results are written beside these scripts. The main thread owns the independent 76 Node / 340 renderer / 320 storage gates and new-physics budget oracle; this task does not change those tests.

Frozen R8, both R9 runtime inputs, package manifests and release artifacts are untouched by this verification task. No package or publication is produced.
