import pathlib,subprocess,json,os
r=pathlib.Path(__file__).resolve().parent;c=r/'candidate';e=r/'actual-gates';e.mkdir(exist_ok=True);env={**os.environ,'NODE_PATH':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules'}
commands=[['node','tests/run-test-gates.mjs',str(e/'base')],['node','--test','tests/ui-dedup.test.mjs'],['node','diagnostic/contour-targeted.mjs'],['node','diagnostic/fixture340.mjs'],['node','tests/contour-enum-commands.mjs'],['node','diagnostic/real20-node.mjs']];rows=[]
for i,cmd in enumerate(commands):
 with (e/f'gate{i}.log').open('w') as f:q=subprocess.run(cmd,cwd=c,env=env,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'command':cmd,'cwd':str(c),'exitCode':q.returncode,'log':f'actual-gates/gate{i}.log'});(e/'exit-status.json').write_text(json.dumps(rows,indent=2));print(i,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
