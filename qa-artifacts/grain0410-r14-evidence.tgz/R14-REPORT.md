# GRAINFORM 0.4.10 r14 — bounded color preparation cache

Frozen local candidate. All listed final Node checks pass. Native Chromium pixels and actual timing are pending independent QA. No browser, privilege escalation, GitHub upload or deployment. Frozen r13 was preserved.

## Scope and reason

Only runtime changes: `ca-layer.mjs` and a one-option app opt-in in `app.mjs`. Physics, contour including the accepted r13 coverage guard, grain count/radius/noise/brightness, tile layout, draw order, queue and endpoint ACK barriers are unchanged. No fill batching or transparent-cache path.

The single r13 diagnosis observed scratch paint 10.7 ms with no overlapping GC; sampled leaf weights included fill≈5.87, color≈1.44 and tint≈1.03 ms. These are not precise function timers and do not predict this candidate's gain. This bounded candidate addresses actual repeated color preparation; it does not claim to eliminate the remaining cold peak or guarantee every frame below 16.67 ms.

Read-only first-contact analysis found one base material color but 158 exact tinted fill colors across 2,304 particles and 2,282 contiguous fill-color runs. Only 22 adjacent pairs share the final fill color; 20 of those have overlapping expanded device-pixel bounds. Reducing fill calls without changing compositing would therefore need much more complex reordering/overlap work; this revision does not attempt it.

## Explicit equivalence domain

### Resolver caching is opt-in, default callback contract preserved

`CALayerRenderer` accepts `cacheColorRuns`, default false. Without opt-in, resolveColor is still called for every painted grain in exactly the original order with the original receiver. Side-effecting callbacks, callbacks that throw and callbacks observing reentrant context-state changes retain their original behavior.

Only the app opts in with `cacheColorRuns:true`. Its existing color(value) is a synchronous pure lookup of the primitive material color through the current standard/contrast palette, or passes a CSS string through. No event-loop settings change occurs inside this native synchronous paint. For each contiguous run of equal input colors, the resolver output is reused. These cache variables exist only inside that one paint invocation; the first grain of every later paint resolves again. Theme toggles and color changes immediately affect the next paint. No ID/color/position is re-sorted, queued, retained globally or skipped.

Opt-in is a contract: a custom resolver that deliberately changes its return per call, mutates global state during paint, or depends on call count must leave it disabled. The revision does not silently infer callback purity or enable it for generic clients. The app's only change is the explicit opt-in, asserted by the targeted test against frozen r13 app source.

### Hex decode cache is capacity one

`tint` stores one successfully parsed primitive `#RRGGBB` string and its exact integer value. The key is at most seven characters, so this cache cannot grow with colors, frames or particle IDs. Exact string equality is used; theme/hex changes cause replacement. Invalid or non-primitive inputs run the original regex/parse/coercion path, including original errors. Boxed/custom string-like objects are not cached.

This shares only a pure decoded integer. The original per-particle brightness multiplication, channel extraction, Math.round, upper clamping and `rgb(r,g,b)` string formation remain byte-for-byte the same expression. Existing per-style baseColor/fillColor state remains authoritative and unchanged.

### Rendering/lifetimes

Every original fillStyle assignment, beginPath, arc, fill/fillRect, tile clear/copy and final composite is retained with the same order and arguments. Each of the first 2,304 grains still has its own fill. Position interpolation, stable/moving membership and overlap/AA semantics do not change. There are no new per-particle allocations or pooled records/nodes/weights; the resolver cache is a few call-local scalars and the hex cache is one immutable key/value pair.

## Measured work counts, not time

A fresh module instance, real Game seed1 default-center natural first contact and actual old/new paint methods were compared. The resolver and Number.parseInt invocations were counted with temporary diagnostic instrumentation, restored immediately; no timers were used for this claim.

- Frozen r13: 2,304 resolver calls; 2,304 hex parses; 2,304 fills
- r14: 1 resolver call; 1 hex parse; 2,304 fills
- The complete assigned color-string/Canvas command sequence and every style object value were equal

Capacity-one sequence A,A,B,A performs 4 parses in r13 and 3 in r14, demonstrating replacement rather than an unbounded color Map. These operation counts are not milliseconds, GC reductions or V8 allocation counts.

## Final local verification

Environment Node v24.19.0, existing @napi-rs/canvas 0.1.100. `actual-gates/exit-status.json`, nested base status and `supplemental-status.json` record commands/status. All final commands exit 0.

- Original slots wrapper: 7 checks, including 320 reuse/admission cycles
- Original npm test: 76 passed, 0 failed, including real native-worker regression
- UI dedup: 7 passed separately
- Contour targeted comparison: 105 comparisons, comprising 95 normal plus 10 matching expected artificial out-of-domain errors; 6,004 independent record-array checks. The contour file itself is unchanged.
- Frozen r13 versus r14 renderer fixtures: 340 exact backing-cache and final RGBA comparisons
- Full command/RGBA fixture gate: 364 comparisons, 2,724,962 exact Canvas calls/setters with arguments and order; 2,680,712 frozen body checks
- Actual Game first/second/twentieth selected contacts and motion phases: 555 complete contour data comparisons plus 555 RGBA comparisons at backing scales 1/1.5/2; final twentieth live 46,080
- New color-cache targeted gate: 72 comparisons, including 36 Node-Canvas RGBA comparisons, 21,426 exact command entries; theme switching, reversed dynamic IDs and missing IDs, cross-color runs, reset/reuse, valid mixed-case hex, invalid/named/rgb/rgba/short/alpha CSS, brightness boundaries, rawCells, original boxed-string coercions, default side-effecting/reentrant/throwing callback behavior, cold counts and cache capacity. The omitted constructor option is explicitly asserted false.

All new renderer fixture/command/Game comparisons explicitly pass `cacheColorRuns:true`, including to frozen r13 where the unknown option is harmlessly ignored. Therefore these gates exercise the opt-in path rather than accidentally testing only the default path. Some inherited test filenames/status prose still mention earlier contour work; baseline imports are rebound to `tests/r14-baseline`, and current scope is defined by this report and the manifest.

An initial targeted-test assertion incorrectly demanded identical function object identities between two separately constructed boxed-input fixtures. It was corrected to verify that each renderer retains its own exact input object, all other style fields/commands match, and the coercion event sequences/counts match. The initial failure log is preserved. A first repair command used a duplicated cwd-relative path and made no edit; it reran that same known assertion. Only the diagnostic harness was corrected; no runtime change was made to obtain the pass. Final corrected harness was rerun successfully after the final assertions were added.

Node normalized Canvas color state is not native Chromium color state. No native browser or timing success is claimed here.

## Integrity and independent handoff

Baseline: r13 independent frozen commit `fe2d30f3970b13226535c1e464e04e36c98404fa`.

Final SHA256:
- app.mjs: `d1ebc41ec17bf9f69995f258932d77da3f3b820f962479bf91fce70b7b13fbfa`
- ca-layer.mjs: `103f0a0131f39e20f7279b76884148edc189fa592c9ad8b5087b92c80c480aef`
- unchanged ca-contour.mjs: `9d6b0ff94abfa51fb5e44caa08c38d573027173f3d78ad2f78205d692cb6bfb2`

All 21 top-level source/scripts are compared in runtime-integrity.json; the other 19 are unchanged. R14-MANIFEST is current; inherited manifests and README describe history. Delta contains exactly app.mjs and ca-layer.mjs. Evidence has current scripts, logs, results, frozen r13 comparison modules, complete bytes/SHA manifest and the explicit test overlay; old inherited result files are not included as new evidence.

Important for native offscreen/browser fixtures: explicitly construct the candidate with `cacheColorRuns:true`; otherwise generic default false is intentional. The actual app already enables it. Compare full command/color strings and both backing cache and final pixels through standard↔contrast changes, dynamic paths, cross-color/reinsert/reset and invalid CSS, alongside the existing actual-game boundary/AA suite. Preserve the default callback tests separately.

One bounded independent A/B may assess cold paint/full draw and the next real local repaint, plus necessary warm/input/clear/idle regressions. No new fine-grained trace is needed just to claim a favorable number. If the gain is not stable or warm cost regresses, prefer the accepted r13 rather than growing this into fill batching or endless micro-tuning. Neither result should be presented as a universal zero-spike guarantee.
