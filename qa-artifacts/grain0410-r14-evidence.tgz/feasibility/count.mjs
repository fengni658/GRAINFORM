import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Game} from '../grain0410-r13-external/unpacked/candidate/game.mjs';
import {materialStyle} from '../grain0410-r13-external/unpacked/candidate/ca-layer.mjs';
const palette=['','#eac370','#4fc0b3','#d378a3','#789fef'];
const tint=(hex,brightness)=>{if(!/^#[0-9a-f]{6}$/i.test(hex))return hex;const n=Number.parseInt(hex.slice(1),16),channel=shift=>Math.min(255,Math.round(((n>>>shift)&255)*brightness));return `rgb(${channel(16)},${channel(8)},${channel(0)})`};
const g=new Game({seed:1});g.start();let steps=0;while(!g.world.count){g.step();assert(++steps<1000)}const bodies=g.frame({full:true}).bodyPatch.upsert;
const boxes=[],styles=[],baseColors=[];let materialRuns=0,fillRuns=0,sameFillAdjacentPairs=0,overlappingExpandedBounds=0;
const sx=648/288,sy=972/432;
for(const b of bodies){const s=materialStyle(b.id),base=palette[b.color],fill=tint(base,s.brightness),x=b.x+s.dx,y=b.y+s.dy,r=s.radius;const box=[Math.floor((x-r)*sx)-1,Math.floor((y-r)*sy)-1,Math.ceil((x+r)*sx)+1,Math.ceil((y+r)*sy)+1];
 if(!baseColors.length||base!==baseColors.at(-1))materialRuns++;if(!styles.length||fill!==styles.at(-1))fillRuns++;else{sameFillAdjacentPairs++;const old=boxes.at(-1);if(box[0]<old[2]&&box[2]>old[0]&&box[1]<old[3]&&box[3]>old[1])overlappingExpandedBounds++;}
 boxes.push(box);styles.push(fill);baseColors.push(base);
}
const report={scope:'Read-only source-derived operation/paint-color analysis on actual seed1 default-center natural first contact, frozen r13. No runtime or browser changes; not a timing claim.',steps,bodies:bodies.length,materialColors:[...new Set(bodies.map(b=>b.color))],baseColors:[...new Set(baseColors)],uniqueExactFillColors:new Set(styles).size,baseColorContiguousRuns:materialRuns,originalResolveCalls:bodies.length,pureResolverRunCacheCalls:materialRuns,originalHexRegexAndParseCalls:bodies.length,oneEntryValidHexDecodeCacheCalls:new Set(baseColors).size,fillColorContiguousRuns:fillRuns,sameFillAdjacentPairs,adjacentSameFillWithOverlappingExpandedPixelBounds:overlappingExpandedBounds,adjacentSameFillWithDisjointExpandedPixelBounds:sameFillAdjacentPairs-overlappingExpandedBounds,canvasFillCallsUnchanged:bodies.length};fs.writeFileSync(new URL('first-contact-color-work.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
