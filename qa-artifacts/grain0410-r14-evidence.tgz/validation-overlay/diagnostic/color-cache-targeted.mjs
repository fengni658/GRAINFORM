import assert from 'node:assert/strict';import fs from 'node:fs';import {createRequire} from 'node:module';
import {CALayerRenderer as Old,materialStyle} from '../tests/r14-baseline/ca-layer.mjs';import {CALayerRenderer as New} from '../ca-layer.mjs';import {Game} from '../game.mjs';
const {createCanvas}=createRequire('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/x.js')('@napi-rs/canvas');
assert.equal(new New().cacheColorRuns,false,'omitted option preserves generic callback contract');
const oldApp=fs.readFileSync(new URL('../tests/r14-baseline/app.mjs',import.meta.url),'utf8'),newApp=fs.readFileSync(new URL('../app.mjs',import.meta.url),'utf8');
assert.equal(newApp,oldApp.replace('resolveColor:color,rawCells:', 'resolveColor:color,cacheColorRuns:true,rawCells:'),'only explicit app opt-in differs');
const standard=['','#eac370','#4fc0b3','#d378a3','#789fef'],contrast=['','#ffe07a','#4df0b0','#fc87b5','#71a7ff'];
const P=(upsert=[],removed=[],reset=false)=>({upsert,removed,reset}),b=(id,x=20.5+id%8,y=20.5+Math.floor(id/8),color=1)=>({id,x,y,color});
let comparisons=0,pixelComparisons=0,commands=0;const cases=[];
function spy(log,onSet){let fill;return {set fillStyle(v){log.push(['fillStyle',v]);fill=v;onSet?.(v)},get fillStyle(){return fill},beginPath(){log.push(['beginPath'])},arc(...a){log.push(['arc',...a])},fill(){log.push(['fill'])},fillRect(...a){log.push(['fillRect',...a])}}}
function pair(name,{initial=Array.from({length:12},(_,i)=>b(i)),cache=true,rawCells=false,resolveFactory,onSetFactory}={}){
 const targets=[Old,New].map((T,side)=>{const log=[],state={theme:'standard',calls:[],receiverOK:true,counter:0},r=new T({cacheColorRuns:cache,rawCells,resolveColor:resolveFactory?resolveFactory(state):function(v){state.calls.push(v);state.receiverOK&&=this===r;return typeof v==='string'?v:(state.theme==='contrast'?contrast:standard)[v]||standard[1]}});r.apply(P(initial,[],true));return {r,state,log,context:spy(log,onSetFactory?.(state))}});
 function paint(label,{ids=false,entries,positions=null,patch,theme,brightness}={}){
  for(const t of targets){if(theme)t.state.theme=theme;if(patch)t.r.apply(patch);if(brightness!==undefined)for(const s of t.r.styles.values())s.brightness=brightness;t.state.calls=[];t.log.length=0;t.error=null;try{t.count=t.r.paint(t.context,entries??(ids?t.r.bodies.keys():t.r.bodies.values()),positions,ids)}catch(e){t.error={name:e.name,message:e.message}}}
  const[a,z]=targets;assert.deepEqual(z.error,a.error,name+'/'+label+'/error');assert.equal(z.count,a.count,name+'/'+label+'/count');assert.deepEqual(z.log,a.log,name+'/'+label+'/commands');if(a.state.expectedBase){for(const t of targets)for(const style of t.r.styles.values())assert.equal(style.baseColor,t.state.expectedBase,'boxed input identity preserved');const values=t=>[...t.r.styles].map(([id,style])=>[id,{...style,baseColor:'paired boxed input'}]);assert.deepEqual(values(z),values(a),name+'/'+label+'/boxed-styles')}else assert.deepEqual([...z.r.styles],[...a.r.styles],name+'/'+label+'/styles');assert.deepEqual([...z.r.bodies],[...a.r.bodies],name+'/'+label+'/bodies');assert(a.state.receiverOK&&z.state.receiverOK);if(!cache)assert.deepEqual(z.state.calls,a.state.calls,name+'/'+label+'/default-callback-order');commands+=a.log.length;comparisons++;return targets;
 }
 cases.push({name});return{targets,paint};
}
const actualApp=pair('pure-app-contract');actualApp.paint('initial');assert.equal(actualApp.targets[0].state.calls.length,12);assert.equal(actualApp.targets[1].state.calls.length,1);
actualApp.paint('contrast-immediately',{theme:'contrast'});actualApp.paint('standard-immediately',{theme:'standard'});
actualApp.paint('dynamic-reverse-ids-and-missing',{ids:true,entries:[11,10,999,9,8,7,6,5,4,3,2,1,0],positions:new Map([[11,[10.25,11.75]],[0,[30.875,31.125]]])});
actualApp.paint('cross-color-runs',{patch:P([b(1,21.5,20.5,2),b(2,22.5,20.5,2),b(5,25.5,20.5,4),b(11,23.5,21.5,3)])});
actualApp.paint('remove-and-id-reuse',{patch:P([b(97440,20.5,20.5,4)],[0])});actualApp.paint('reset-reversed',{patch:P(Array.from({length:12},(_,i)=>b(200000+i,20.5+i%8,20.5+Math.floor(i/8),1+(i%4))).reverse(),[],true)});
const colors=['#000000','#ffffff','#FFFFFF','#aBcDeF','#ABCDEF','#000001','#f00','#aabbccdd','rgb(12, 34, 56)','rgba(255, 0, 0, .5)','transparent','currentColor','not-a-color','#GGGGGG','',null,undefined,123,NaN];
for(const rawCells of[false,true]){
 const t=pair('primitive-colors-'+rawCells,{initial:colors.map((_,i)=>b(i,20.5+i,20.5,i)),cache:true,rawCells,resolveFactory:state=>function(v){state.calls.push(v);return colors[v]}});
 t.paint('all-colors');for(const brightness of[0,.8,.800001,.95,1,1.1,2,-.1,NaN,Infinity])t.paint('brightness-'+brightness,{brightness,patch:P(colors.map((_,i)=>b(i,20.5+i,20.5,i)),[],true)});
}
const impure=pair('default-impure-resolver-preserved',{cache:false,resolveFactory:state=>function(v){state.calls.push(v);return ++state.counter%2?'#102030':'#abcdef'}});impure.paint('one');impure.paint('two');
const reentrant=pair('default-reentrant-theme-mutation-preserved',{cache:false,onSetFactory:state=>()=>{state.theme=state.theme==='standard'?'contrast':'standard'}});reentrant.paint('one');reentrant.paint('two');
const throwing=pair('default-throw-preserved',{cache:false,resolveFactory:state=>function(v){state.calls.push(v);if(++state.counter===4)throw Error('intentional resolver stop');return '#aabbee'}});throwing.paint('stops-at-four');
const boxedEvents=[[],[]];let side=0;const boxed=pair('boxed-string-coercion-still-occurs',{cache:false,resolveFactory:state=>{const log=boxedEvents[side++],v={toString(){log.push('toString');return '#eac370'},slice(...args){log.push(['slice',...args]);return 'eac370'}};state.expectedBase=v;return function(key){state.calls.push(key);return v}}});boxed.paint('all-boxed');assert.deepEqual(boxedEvents[1],boxedEvents[0]);assert.equal(boxedEvents[0].filter(x=>x==='toString').length,12);

// Capacity-one parse check: instrumentation counts work only; it is not timing.
const FreshOld=(await import('../tests/r14-baseline/ca-layer.mjs?parse-proof')).CALayerRenderer,FreshNew=(await import('../ca-layer.mjs?parse-proof')).CALayerRenderer;
function counted(T,hexes){const r=new T({cacheColorRuns:true,resolveColor:x=>x}),log=[],context=spy(log),native=Number.parseInt;let calls=0;Number.parseInt=function(...a){calls++;return native.apply(this,a)};try{for(let i=0;i<hexes.length;i++){const body=b(i,20.5+i,20.5,hexes[i]);r.apply(P([body]));r.paint(context,[body])}}finally{Number.parseInt=native}return{calls,log};}
const hexes=['#13579b','#13579b','#2468ac','#13579b'];const pa=counted(FreshOld,hexes),pb=counted(FreshNew,hexes);assert.deepEqual(pb.log,pa.log);assert.equal(pa.calls,4);assert.equal(pb.calls,3);

// Real first natural contact and cold module instance, exact string/command order.
const g=new Game({seed:1});g.start();let ticks=0;while(!g.world.count){g.step();assert(++ticks<1000)}const first=g.frame({full:true}).bodyPatch.upsert;
const ColdOld=(await import('../tests/r14-baseline/ca-layer.mjs?cold-proof')).CALayerRenderer,ColdNew=(await import('../ca-layer.mjs?cold-proof')).CALayerRenderer;
function cold(T){let resolves=0,parses=0;const native=Number.parseInt,log=[],r=new T({cacheColorRuns:true,resolveColor(v){resolves++;return standard[v]}});r.apply(P(first,[],true));Number.parseInt=function(...a){parses++;return native.apply(this,a)};let paints;try{paints=r.paint(spy(log),r.bodies.values())}finally{Number.parseInt=native}return{resolves,parses,paints,log,styles:[...r.styles]};}
const ca=cold(ColdOld),cz=cold(ColdNew);assert.deepEqual(cz.log,ca.log);assert.deepEqual(cz.styles,ca.styles);assert.equal(ca.resolves,2304);assert.equal(cz.resolves,1);assert.equal(ca.parses,2304);assert.equal(cz.parses,1);assert.equal(cz.paints,2304);comparisons++;commands+=ca.log.length;

// Real Node Canvas string setter normalization, calls, and pixels across palette/invalid-color cases.
for(const scale of[1,1.5,2])for(const rawCells of[false,true]){
 let palette=standard;const targets=[Old,New].map(T=>{const c=createCanvas(144*scale,96*scale),ctx=c.getContext('2d'),log=[],proxy=new Proxy(ctx,{get(t,k){const v=Reflect.get(t,k,t);return typeof v==='function'?(...args)=>{log.push(['call',k,...args]);return v.apply(t,args)}:v},set(t,k,v){log.push(['set',k,v]);return Reflect.set(t,k,v,t)}}),r=new T({cacheColorRuns:true,rawCells,resolveColor:v=>typeof v==='string'?v:palette[v]||standard[1]});return {c,ctx,proxy,r,log}});
 const points=Array.from({length:96},(_,i)=>b(i,20.5+i%16,20.5+Math.floor(i/16),1+Math.floor(i/12)%4));
 for(const t of targets)t.r.apply(P(points,[],true));
 for(let step=0;step<6;step++){
  palette=step%2?contrast:standard;
  for(const t of targets){const{ctx,proxy,r}=t;t.log.length=0;ctx.setTransform(scale,0,0,scale,0,0);ctx.fillStyle='#0d1315';ctx.fillRect(0,0,144,96);if(step===3)r.apply(P([b(0,20.5,20.5,'not-a-color'),b(1,21.5,20.5,'rgba(255,0,0,.4)'),b(2,22.5,20.5,'#aBcDeF')]));if(step===4)r.apply(P([b(0,20.5,20.5,'#000001'),b(1,21.5,20.5,'transparent'),b(2,22.5,20.5,'#fff')]));const pos=new Map(points.filter(p=>p.id%5===0).map(p=>[p.id,[p.x+step*.125,p.y+step*.0625]]));r.paint(proxy,[...r.bodies.keys()].reverse(),pos,true)}
  assert.deepEqual(targets[1].log,targets[0].log);assert.equal(targets[1].ctx.fillStyle,targets[0].ctx.fillStyle);assert.deepEqual(targets[1].ctx.getImageData(0,0,targets[1].c.width,targets[1].c.height).data,targets[0].ctx.getImageData(0,0,targets[0].c.width,targets[0].c.height).data);comparisons++;pixelComparisons++;commands+=targets[0].log.length;
 }
}
const report={pass:true,comparisons,pixelComparisons,canvasCommands:commands,cases,defaultImpureCallbackContract:'Exact per-grain calls/order/output/throw and reentrant theme effects preserved with default cacheColorRuns=false.',pureOptInContract:'Within each synchronous paint only, identical consecutive inputs resolve once; theme changes between paints are observed. No Canvas call eliminated/reordered.',validHexCache:{capacity:1,oldParses:pa.calls,newParses:pb.calls,sequence:hexes,boxedCoercionsUnchanged:boxedEvents[0].filter(x=>x==='toString').length},actualNaturalColdFirstContact:{particles:2304,old:{resolveCalls:ca.resolves,hexParses:ca.parses,canvasFills:ca.paints},candidate:{resolveCalls:cz.resolves,hexParses:cz.parses,canvasFills:cz.paints},canvasCommandAndStyleEquality:true},scope:'Actual frozen r13 and candidate modules; raw color strings and Canvas calls exact, Node @napi-rs/canvas normalized color state and RGBA exact. Not Chromium/native browser or timing evidence.'};fs.writeFileSync(new URL('color-cache-targeted.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
