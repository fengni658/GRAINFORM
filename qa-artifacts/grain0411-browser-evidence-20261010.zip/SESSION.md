# Actual dot cloud browser observations

2026-10-10 UTC. Official CUA cdp browser, not user computer. Frozen 0.4.11 build b-c09a9ea6b2fe85a5f439a6e9424da32ffa62a1a53c10f4f4008ae2e274f45b82. Source Site commit 380ca64eaea248c403148a21c2c4d7a27f96d0e8. Deployment appgdep_6ac9e7dcccb88191a6bbe7ea4cdcc907 succeeded 07:23:15.196 previous files preserved and only 11 files added.

Actual viewport document client 1165x757. Old board rectangle 324x487 CSS px, new 324x576. New ratio exactly 9:16 and horizontal scale unchanged. This is not a mobile/DPR matrix result.

Actual UI startup succeeded. Tested left, rotate, soft drop, hard drop through visible controls. Settling disabled controls then returned to falling. Capture controls-0411.jpg shows solid airborne piece and two colored sand piles at extended floor. Diagnostics at seed1, two landed pieces: 4608 particles, renderer live/stable4608, dynamic0, no resync, no rejected presentation ACK, queue0, input ACK count5 p95/max30.1ms. This is one QA-mode sample, not a latency benchmark.

Settings and help dialogs opened and closed; return remained paused. Restart cancel preserved four-piece game; subsequent confirmed restart reset current score and pieces to0 while best26 remained. UI also tested right move and another hard drop after restart.

Performance limits: unseeded initial run produced slowdown true with4.604s debt at four pieces; old0410 seeded baseline also produced severe slowdown at first piece, maxDraw2978.8ms/debt5.562s. These are unmatched samples and cannot prove a new regression or acceptable performance. Later0411 two-piece sample recovered rate0.99995 and debt16.567ms. Keep all these results. QA mode adds JSON serialization overhead. No commercial-performance claim.

Known diagnostics limitation: DOM #qaOutput may remain at a preceding snapshot after pause. Actual pause overlay appeared; stale state playing in QA text is not proof simulation continued. No hidden application object accessed.

Only console errors observed were chrome-extension metadata errors; no game-source error in captured logs. Actual OS background, touch device, mobile memory, native DPR matrix, artificial clear fixtures not tested. Browser fixture injection is not an exposed UI/URL route and was not used. Existing independent Node tests cover geometry and clear barriers but are not browser evidence.

At 07:27 UTC, normal seeded play reached seven pieces; UI cleared counter4608 and score718, remaining11520 particles matches7*2304-4608. This establishes a natural clear occurred, not frame-by-frame proof of every clear barrier. Seed1 restarted epoch2, rejectedACK0, maxqueue2, countsConserved true. A later QA sample again slowdown true debt3.9038s, drawmax411.8ms; performance acceptance remains unresolved.

Attempted standard Chrome UI device emulation shortcut; organization policy explicitly denied DevTools. Stopped; did not bypass policy. Native phone/DPR emulation matrix remains untested.

Normal mode (no qa): fresh navigation ?seed=1, start07:28:56. At07:29:20, third-piece settling showed visible slowdown notice. Thus QA serialization cannot be the sole explanation. Screenshot normal-0411.jpg preserves this finding. No hidden diagnostics were accessed in normal mode.
