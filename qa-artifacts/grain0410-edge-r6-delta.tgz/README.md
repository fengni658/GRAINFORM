# GRAINFORM 0.4.10 r6 — integrated complete-slip material paths

Unpublished controlled integration based on frozen r4. The preceding isolated microexperiment passed bounded real Chromium visual review at DPR1/1.5/2, but this full worker/game candidate still requires its own end-to-end acceptance. r5 and all failed experiments remain preserved, not a baseline.

## Single physical/presentation change

Within each of the three slip rounds a fixed bottom-up ID list reads the current grid. A legal one/two-column corridor and free downhill destination allow an immediate complete move to(x±dist,y+1). The next grain reads the updated grid; no common visible horizontal-leg intermediate state is created. Original eight vertical rounds, ID-based1/2 reach, speed/credit, active chunks, colors, IDs and logical cell size remain.

Each recorded particle polyline is parameterized by actual Euclidean length within each of four fixed material substep presentation intervals. Every substep boundary/hold remains; there is no whole-output first-to-last shortcut. Wire paths explicitly carry mode:'substep-arc', finite fractional times in0..68 and valid full moves. Legacy unit-leg QA input is still separately supported, never silently interpreted as new compound movement. Decoder rejects malformed modes/legs or moving edges crossing a substep boundary.

Sand/sand transient subpixel overlap is an intentional2D material approximation, not hard-circle or exact rigid-body physics. Logical occupancy/IDs/each color/count remain strict. Convex outer container endpoints and full lines stay in bounds. The current game has no internal rigid-obstacle feature; no such feature or unvalidated diagonal-through-wall support is added.

The r4 queue, app and worker source remain unchanged: max2, fixed time/debt, consumption versus actual endpoint ACK, pause/hidden/restart/resync, final barrier before clear. The r3 dirty cache batching and contour/texture are unchanged. Only the path sampler/validator changes in ca-layer; no blur, new glyph protection or altered UI.

## Known costs and boundaries

First/second same-seed shifted/rotated drops:35/83→36/84 ticks, widths121/164→122/165, second height63 unchanged. Six-drop alternating offset scene: final127→131ticks, clear2304/live11520 unchanged. Dense23-drop scene reaches52992live, no top-out/count errors, high last-five302→303ticks. These bounded scenes do not prove identical motion or all-game style/performance.

Fractional framePhase storage isFloat64 instead ofUint8, adding47063520bytes (about44.9MiB) per allocated maximum-capacity World. Storage remains fixed capacity; reset/GC/browser heap/native behavior must be checked, not declared stable. No performance rewrite was mixed into this integration.

Local micro CPU ratios included a1.235 round. Real micro replay had DPR1 and1.5 rounds1.291/1.237, despite favorable pooled DPR2. None establish stable≤110% or60FPS. Full app QA must measure active-only draw intervals, CPU p95/p99, max2 queue and peak/lastSETTLING debt; never hide debt using later falling samples.

The microplayer startup TypeError has a reproducible negative-progress→frames[-1] failure path; the external failing callback's timestamp cause remains unproven. Product code does not import that player/indexing logic. Its queue clamps a sample before startedAt toalpha0, and new tests explicitly cover this plus negative/nonfinite direct sampling. Real pause/restart/late-frame tests remain required.

## Verification entry points

npm test: original68 tests plus substep decoder/sampler regressions and real worker-thread integration.
npm run verify:slots: original320 slot/reuse cycles.
npm run verify:motion: short independent input-Map complete-motion/conservation oracle, following/gaps/walls and final clear.
npm run verify:parity: compatibility alias to the above NEW oracle, not old551 trajectory equality.
npm run verify:pixels / verify:pixels:browser:340 exact same-pose incremental versus full-reference comparisons including complete-slip fractional tile/color cases.
npm run verify:browser: existing actual Chromium flow smoke; run outside dot environment.

Original old551 reference/goldens and merge-parity.mjs are retained unchanged for historical inspection. They are intentionally not a pass criterion for the changed dynamics. tests/legacy-r4 contains exact old physical modules only for bounded throughput comparison. No old expected trajectory was rewritten to get green.

Real browser acceptance: first and actual acknowledged shifted/rotated second drops, sixth and high-density activity at DPR1/1.5/2, natural mixed-color clears, pause/hidden/restart/resync, final endpoint actually drawn before flash. Distinguish natural grain/AA from recurring attached2–3CSSpx tooth rows. Check no new whole-color covering/uncovering, stable texture, or tile trails. This candidate is not released.
