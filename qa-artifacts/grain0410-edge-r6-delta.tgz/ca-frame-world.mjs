import {World,CFG} from './ca-world.mjs';
export {CFG};
// Four material rule steps per 60 Hz output. Each receives one fixed quarter interval.
export class FrameWorld extends World {
 constructor(){super();const C=this.live.length;this.frame=0;this.framePending=false;this.frameIds=[];this.frameStamp=new Uint32Array(C);this.frameN=new Uint8Array(C);this.frameX=new Int16Array(C*69);this.frameY=new Int16Array(C*69);this.framePhase=new Float64Array(C*69);this.frameDirty=null;this.frameLast=null;}
 _resetSlot(i){super._resetSlot(i);this.frameStamp[i]=(this.frame-1)>>>0;this.frameN[i]=0;const p=i*69;this.frameX.fill(0,p,p+69);this.frameY.fill(0,p,p+69);this.framePhase.fill(0,p,p+69)}
 remove(ids){super.remove(ids);this.frameIds=this.frameIds.filter(id=>this.has(id))}
 stepFrame(){this.frame++;this.framePending=true;this.frameIds.length=0;this.frameDirty=null;const totals={steps:0,moves:0,particles:0,cellVisits:0};const cv=this.metrics.cellVisits;
 for(let s=0;s<4;s++){if(!this.chunks.size)break;super.step();totals.steps++;totals.moves+=this.last.moves;totals.particles+=this.last.particles;
 // Cache each actual full move and substep hold before base buffers overwrite.
 for(let i=0;i<this.n;i++){if(!this.live[i]||this.pathStamp[i]!==this.tick)continue;const dst=i*69,src=i*18;
 if(this.frameStamp[i]!==this.frame){this.frameStamp[i]=this.frame;this.frameIds.push(this.identity[i]);this.frameN[i]=1;this.frameX[dst]=this.pathX[src];this.frameY[dst]=this.pathY[src];this.framePhase[dst]=0;}
 // Allocate each particle's actual polyline by arc length inside this fixed rule-step interval.
 const n=this.pathN[i];let length=0;for(let j=1;j<n;j++)length+=Math.hypot(this.pathX[src+j]-this.pathX[src+j-1],this.pathY[src+j]-this.pathY[src+j-1]);
 const put=(x,y,time)=>{const last=dst+this.frameN[i]-1;if(this.framePhase[last]===time)return;const k=dst+this.frameN[i]++;if(this.frameN[i]>69)throw Error('frame-path-capacity');this.frameX[k]=x;this.frameY[k]=y;this.framePhase[k]=time};
 put(this.pathX[src],this.pathY[src],s*17);
 let distance=0;for(let j=1;j<n;j++){distance+=Math.hypot(this.pathX[src+j]-this.pathX[src+j-1],this.pathY[src+j]-this.pathY[src+j-1]);put(this.pathX[src+j],this.pathY[src+j],s*17+17*distance/length)}
 if(!length)put(this.pathX[src],this.pathY[src],(s+1)*17);}

 if(this.dirty){const d=this.dirty;if(!this.frameDirty)this.frameDirty={...d};else{const a=this.frameDirty;a.x0=Math.min(a.x0,d.x0);a.y0=Math.min(a.y0,d.y0);a.x1=Math.max(a.x1,d.x1);a.y1=Math.max(a.y1,d.y1)}}}
 totals.cellVisits=this.metrics.cellVisits-cv;this.frameLast=totals;return totals;}
 completePresentation(){super.completePresentation();this.framePending=false;}
 ready(){return !this.framePending&&super.ready();}
 positionAt(id,alpha){const i=this.slotOf(id);if(!this.frameN[i]||this.frameStamp[i]!==this.frame)return[this.x[i]+.5,this.y[i]+.5];const t=Math.max(0,Math.min(1,alpha))*68,n=this.frameN[i],base=i*69;for(let j=1;j<n;j++){const k=base+j,a=this.framePhase[k-1],b=this.framePhase[k];if(t<=b){const u=b>a?Math.max(0,(t-a)/(b-a)):1;return[this.frameX[k-1]+u*(this.frameX[k]-this.frameX[k-1])+.5,this.frameY[k-1]+u*(this.frameY[k]-this.frameY[k-1])+.5]}}return[this.frameX[base+n-1]+.5,this.frameY[base+n-1]+.5]}
}
