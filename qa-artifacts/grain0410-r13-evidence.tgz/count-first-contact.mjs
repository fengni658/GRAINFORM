import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Game} from './candidate/game.mjs';
import {MaterialContour} from './candidate/tests/r13-baseline/ca-contour.mjs';
const g=new Game({seed:1});g.start();let steps=0;while(!g.world.count){g.step();assert(++steps<1000)}
const f=g.frame({full:true}),bodies=new Map(f.bodyPatch.upsert.map(b=>[b.id,b])),c=new MaterialContour();c.invalidate(f.bodyPatch);const result=c.update(bodies,new Map());
const initialInspect=new Set(c.records.keys()),dirtyRounded=new Set([...c.records.values()].map(r=>r.rounded));
let haloCellLookups=0,occupiedLookups=0,haloBodyVisits=0,newIds=0;const inspect=new Set(initialInspect),uniqueHaloCells=new Set();
for(const q of dirtyRounded)for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const p=q+dx+dy*290;haloCellLookups++;uniqueHaloCells.add(p);if(c.roundedBodies[p]?.size)occupiedLookups++;for(const id of c.roundedBodies[p]??[]){haloBodyVisits++;if(!inspect.has(id))newIds++;inspect.add(id)}}
assert.equal(newIds,0);assert.deepEqual([...inspect],[...initialInspect]);
const report={pass:true,scope:'Read-only workload count on frozen r12 source, actual Game seed 1 natural first touchdown; no browser, timing, prewarming or candidate runtime changes.',gameStepsBeforeContact:steps,phase:g.phase,pieces:g.pieces,bodyCount:bodies.size,records:c.records.size,initialInspect:initialInspect.size,dirtyRounded:dirtyRounded.size,haloCellLookups,occupiedLookups,haloBodyVisits,newIds,uniqueHaloCells:uniqueHaloCells.size,metrics:c.metrics,loops:result.loops.length,preserve:result.preserve.length};
fs.writeFileSync(new URL('first-contact-workload.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
