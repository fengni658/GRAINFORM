# GRAINFORM 0.4.10 r13: skip provably redundant contour halo expansion

Status: frozen Node-validated candidate, not browser-validated or published. Only `ca-contour.mjs` runtime changes, as one coverage guard plus one explanatory comment. Work stayed in the dot cloud filesystem; no browser, privilege escalation, GitHub upload or deployment.

## Baseline and proposed effect

Baseline is the intact r12 candidate from `grain0410-r12-external/unpacked/candidate`, whose independent report cites commit `bbe0056176fa161e73887741617d28444851760a`. Frozen r12 contour SHA256 `ab7bdafd6f9c1b3adc70d74993949c77b9a125e4299cba8c6c03be7da94a8784`. Candidate SHA256 `9d6b0ff94abfa51fb5e44caa08c38d573027173f3d78ad2f78205d692cb6bfb2`.

r12 cold results were not a stable improvement: two native first-contact draws 37.4/43.3 ms and contours 23.2/23.2 ms, against r11 draws 45.0/42.7 and contours 30.5/22.6. This candidate does not reclassify those results. It removes actual redundant traversal rather than another temporary-array construction.

After committing scalar fields and rounded ownership, `inspect` is seeded from all new or rounded-cell-moved records. The previous implementation always traversed every changed rounded cell's 5×5 neighborhood to add affected IDs. When the seed already equals the complete record domain, this traversal can add no new ID. The candidate runs that unchanged traversal only when `inspect.size !== this.records.size`. Support decisions, `isCore`, colors, marching squares, loops, smoothing, preserve, metrics, draw commands and all persistent containers are otherwise unchanged.

## Coverage and order proof

1. `candidates` is a Set, so `updates` contains each ID at most once.
2. The second commit pass has already installed every non-null `next` in `records`; there is no later same-ID update within this pass. The initial `inspect` adds only IDs from such `next` records. Therefore initial `inspect` is a subset of current `records`, including after removals, same-patch removal/refill and generation replacement.
3. The rounded ownership invariant is maintained by both commit passes. Old records are removed from their old cell iff deleted or moved to a different rounded cell. Every new or rounded-cell-moved record is inserted in its new cell. Same-cell position changes or recoloring retain the same membership. Reset clears both structures. Thus each ID enumerated from `roundedBodies` belongs to current `records`; each record belongs to its declared rounded cell. Multiple IDs in a rounded cell and cross-color membership do not change this invariant.
4. Given the subset invariant, equal sizes imply equal ID sets. The skipped halo adds only IDs already in `inspect`. Native Set.add on an existing ID neither changes insertion order nor the set. The later support iteration sees exactly the same ordered IDs. When sizes differ, the original halo loops run byte-for-byte unchanged.
5. No guard is based on scene seed, particle count, a special first-frame flag or timing. Empty records also satisfy the proof, including deletion of all material. There is no material prewarming, deferred contour work, particle loss, changed presentation barriers or hidden frame dropping.

The proof assumes the existing class's normal owned data structures rather than externally replaced Maps/Sets/getters. That is the application contract. Existing artificial out-of-domain errors are preserved by the comparison gate; the change does not claim to fix undefined/out-of-domain geometry.

## Actual operation counts

A read-only count uses the unchanged Game seed1 natural landing, after 519 control steps, before any material motion. Initial records = seed inspect = dirtyRounded = 2,304; vertices 240; updated squares 2,425; one loop; no preserved grains.

- Baseline halo rounded-cell visits: 57,600
- Baseline halo particle-ID visits / inspect.add calls: 54,054
- Baseline newly added IDs: 0
- Candidate halo rounded-cell visits: 0
- Candidate halo particle-ID visits / inspect.add calls: 0
- Ordered inspect, every persistent state field, result and metrics: equal

The counted diagnostic copies instrument only the halo for operation counts. They are never app modules. Both actual, unmodified modules are tested beside the two counted copies, with equal output and complete ordered state at every test step. Counts are not milliseconds, heap allocations, GC savings or a 60 FPS claim. They cannot establish how much of the prior Chrome cold span this change removes.

## Cross-frame lifetimes

- `records`, each record object and its private `nodes`/`weights`: persist until a later update subtracts old contributions. They remain independent and are not mutated or pooled by this change.
- `roundedBodies[q]` Sets: persistent ownership; unchanged lifetime and membership operations.
- `links`, `points`, `shades`, `squares`: incremental persistent contour state; no shared scratch replacement.
- `preserved` entries and `result.preserve` can share array references; loops/result may be returned again on no-change updates. These are not cleared or pooled.
- `pending` ownership transfer and `previousMoving`: unchanged across calls.
- `inspect`: local Set for this synchronous update only. The optimization skips repeated adds whose values and order are provably already present. No new cross-frame scratch or lifetime is introduced.

## Executed verification

Environment: Node v24.19.0; existing @napi-rs/canvas 0.1.100. Canvas here is the Node backend, not native Chromium. All final commands exited 0. Original tests were not weakened. `actual-gates/exit-status.json`, the base wrapper's exit-status JSON and the supplemental status file record exact invocations.

- Original slots wrapper: 7 checks, including 320 reuse/admission cycles
- Original npm test: 76 passed, 0 failed, including actual native-worker 3 tests
- UI dedup: 7 passed separately, not counted inside 76
- Existing contour-targeted gate: 105 old/new comparisons = 95 normal plus 10 matching expected artificial out-of-domain errors; 6,004 record-array independence checks
- New coverage guard gate: 89 steps, comparing actual r12/r13 and counted copies, including exact ordered Map/Set state, typed scalar/rounded arrays, rounded cell Sets, records, result/loop metadata and metrics; 13 complete-coverage updates, 73 partial-coverage updates, 3 unchanged calls. Deletion, migration, generation replacement, recolor, duplicate occupancy, reversed insertion, whole-set replacement and bounded deterministic mutation coverage. 19,204 retained-old-record immutability checks and 58,840 independent-array / membership checks each
- Full-reference renderer fixtures: 340 exact old/new RGBA comparisons
- Command + renderer fixture gate: 364 exact old/new command sequences and RGBA comparisons; 2,724,962 commands and 2,680,712 frozen body checks
- Actual Game seed1 first, second and twentieth selected contacts/frames/subphases: 555 full contour data comparisons plus 555 RGBA comparisons at backing scales 1/1.5/2; twentieth final live count 46,080. This is offline equivalence, not live animation timing.

One diagnostic file-launch attempt failed before the file existed because a workspace-relative output path was used with candidate already as cwd. The path was corrected; no product test failed and no runtime was changed by the failed launch. The attempt is recorded in `harness-launch-note.json`.

## Integrity and handoff

`runtime-integrity.json` hashes all 21 top-level .mjs/.css/.html files against the frozen source. Only `ca-contour.mjs` differs. `candidate/R13-MANIFEST.json` is the current revision manifest; inherited README/R10/R11/R12 manifests describe earlier revisions and are retained as history. The original r12 source was not edited.

The delta archive contains exactly `delta/ca-contour.mjs`. The evidence archive contains current scripts/reports/logs, manifests and `validation-overlay` with the frozen r12 renderer/contour baseline plus the tests rebound to that baseline. Old inherited result files are excluded from the evidence archive. `EVIDENCE-MANIFEST.json` enumerates each evidence payload's bytes and SHA256. `bundle-integrity.json` records archive checksums separately.

Independent browser QA is pending: first-contact CPU/draw comparison, native Canvas pixel parity, actual no-jagged/no-horizontal-seam review, warm second/high20 and necessary pause/reset/clear presentation regression. Node equivalence does not replace this. No speed target or user trial should be claimed until that verification is complete. If cold timing fails to improve reliably, reject its performance claim rather than expand into parameter tuning or a rendering rewrite.
