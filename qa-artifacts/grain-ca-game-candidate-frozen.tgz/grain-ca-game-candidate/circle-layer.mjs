import {SAND_CONTRACT as DISPLAY_CONTRACT} from './local-sand.mjs';
const CACHE_WIDTH = 288, CACHE_HEIGHT = 432, CACHE_RADIUS = DISPLAY_CONTRACT.radius;
export function grainShade(id){const h=Math.imul((id>>>0)^0x9e3779b9,0x85ebca6b)>>>0;return h%5;}
export function shadeColor(base,shade){if(!/^#[0-9a-f]{6}$/i.test(base))return base;const factor=[.97,.985,1,1.015,1.03][shade];return '#'+[1,3,5].map(at=>Math.min(255,Math.round(parseInt(base.slice(at,at+2),16)*factor)).toString(16).padStart(2,'0')).join('');}
function traceGrain(context,b){context.moveTo(b.x+CACHE_RADIUS,b.y);context.arc(b.x,b.y,CACHE_RADIUS,0,2*Math.PI);context.closePath();}
/** Transparent stable-grain layer. Dirty rectangles are pixel-snapped and
 * re-render every intersecting stable grain, including tile-border halos. */
export class GridLayerRenderer {
 constructor({createCanvas=()=>document.createElement('canvas'),resolveColor=c=>['','#eac370','#4fc0b3','#d378a3','#789fef'][c],tileSize=16}={}){this.createCanvas=createCanvas;this.resolveColor=resolveColor;this.tileSize=tileSize;this.columns=Math.ceil(CACHE_WIDTH/tileSize);this.rows=Math.ceil(CACHE_HEIGHT/tileSize);this.bodies=new Map();this.stable=new Map();this.dynamic=[null,new Map(),new Map(),new Map(),new Map()];this.tiles=new Map();this.dirty=new Set();this.canvas=null;this.context=null;this.width=0;this.height=0;this.needsFull=true;this.paletteKey=null;this.mode='circle-layer-AA-halo-tiles';this.fallbackReason=null;this.metrics={frames:0,fullCacheRebuilds:0,stablePolygonPaints:0,dynamicPolygonPaints:0,dirtyTilesRepainted:0,lastStablePaints:0,lastDynamicPaints:0,lastDirtyTiles:0};}
 keys(b){const r=CACHE_RADIUS+1,t=this.tileSize,x0=Math.max(0,Math.floor((b.x-r)/t)),x1=Math.min(this.columns-1,Math.floor((b.x+r)/t)),y0=Math.max(0,Math.floor((b.y-r)/t)),y1=Math.min(this.rows-1,Math.floor((b.y+r)/t)),result=[];for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)result.push(y*this.columns+x);return result;}
 remove(id){const b=this.bodies.get(id);if(!b)return;if(b.sleep){for(const k of this.keys(b)){const ids=this.tiles.get(k);ids?.delete(id);if(ids?.size===0)this.tiles.delete(k);this.dirty.add(k);}this.stable.delete(id);}else this.dynamic[b.color].delete(id);this.bodies.delete(id);}
 apply(patch){if(patch.reset){this.bodies.clear();this.stable.clear();for(let c=1;c<=4;c++)this.dynamic[c].clear();this.tiles.clear();this.dirty.clear();this.needsFull=true;}for(const id of patch.removed)this.remove(id);for(const data of patch.upsert){const old=this.bodies.get(data.id);if(old&&old.x===data.x&&old.y===data.y&&old.color===data.color&&old.sleep===data.sleep){this.bodies.set(data.id,{...data});if(data.sleep)this.stable.set(data.id,this.bodies.get(data.id));else this.dynamic[data.color].set(data.id,this.bodies.get(data.id));continue;}this.remove(data.id);const b={...data};this.bodies.set(b.id,b);if(b.sleep){this.stable.set(b.id,b);for(const k of this.keys(b)){if(!this.tiles.has(k))this.tiles.set(k,new Set());this.tiles.get(k).add(b.id);this.dirty.add(k);}}else this.dynamic[b.color].set(b.id,b);}}
 fallback(reason){this.mode='full-vector-fallback';this.fallbackReason=String(reason);this.canvas=null;this.context=null;this.needsFull=true;}
 configure(width,height,paletteKey){if(this.mode!=='full-vector-fallback'&&!this.canvas){try{this.canvas=this.createCanvas();this.context=this.canvas?.getContext('2d',{alpha:true});if(!this.context)throw Error('Stable layer 2D canvas unavailable');}catch(error){this.fallback(error.message);}}if(width!==this.width||height!==this.height){this.width=width;this.height=height;this.needsFull=true;if(this.canvas){this.canvas.width=width;this.canvas.height=height;}}if(paletteKey!==this.paletteKey){this.paletteKey=paletteKey;this.needsFull=true;}}
 paint(context,iterable){const groups=Array.from({length:20},()=>[]);for(const b of iterable)groups[(b.color-1)*5+grainShade(b.id)].push(b);let n=0;for(let k=0;k<20;k++){if(!groups[k].length)continue;context.fillStyle=shadeColor(this.resolveColor(1+Math.floor(k/5)),k%5);context.beginPath();for(const b of groups[k]){traceGrain(context,b);n++;}context.fill();}return n;}
 *dynamicBodies(){for(let c=1;c<=4;c++)yield* this.dynamic[c].values();}
 repaintStable(){
 const c=this.context,sx=this.width/CACHE_WIDTH,sy=this.height/CACHE_HEIGHT;
 const full=this.needsFull,keys=full?Array.from({length:this.columns*this.rows},(_,k)=>k):[...this.dirty];
 let paints=0,tiles=0;
 if(full){c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,this.width,this.height);this.metrics.fullCacheRebuilds++;}
 if(keys.length&&!this.scratch){this.scratch=this.createCanvas();this.scratchContext=this.scratch.getContext('2d',{alpha:true});if(!this.scratchContext)throw Error('Scratch canvas unavailable');}
 // Pixel floors partition tiles without overlapping columns at fractional DPR.
 // Full and local updates use the same tile raster path. Each temporary tile
 // includes an AA halo; only interior pixels are copied. Circle paths never
 // meet the interior tile clip, and integer translation preserves pixel phase.
 for(const k of keys){const x=(k%this.columns)*this.tileSize,y=Math.floor(k/this.columns)*this.tileSize;
 const x0=Math.floor(x*sx),y0=Math.floor(y*sy),x1=Math.min(this.width,Math.floor((x+this.tileSize)*sx)),y1=Math.min(this.height,Math.floor((y+this.tileSize)*sy));
 const halo=Math.ceil((CACHE_RADIUS+2)*Math.max(sx,sy))+2,hx0=x0-halo,hy0=y0-halo,sw=x1-x0+2*halo,sh=y1-y0+2*halo;
 this.scratch.width=sw;this.scratch.height=sh;const sc=this.scratchContext;
 sc.setTransform(sx,0,0,sy,-hx0,-hy0);
 const candidates=[...(this.tiles.get(k)||[])].sort((a,b)=>a-b).map(id=>this.stable.get(id)).filter(Boolean);
 paints+=this.paint(sc,candidates);
 c.setTransform(1,0,0,1,0,0);c.clearRect(x0,y0,x1-x0,y1-y0);
 c.drawImage(this.scratch,halo,halo,x1-x0,y1-y0,x0,y0,x1-x0,y1-y0);tiles++;
 }
 this.needsFull=false;this.dirty.clear();this.metrics.lastStablePaints=paints;this.metrics.lastDirtyTiles=full?0:tiles;this.metrics.stablePolygonPaints+=paints;this.metrics.dirtyTilesRepainted+=full?0:tiles;
 }
 draw(context){this.metrics.frames++;this.metrics.lastStablePaints=0;this.metrics.lastDynamicPaints=0;this.metrics.lastDirtyTiles=0;if(this.mode!=='full-vector-fallback'){try{this.repaintStable();}catch(error){this.fallback(error.message);}}if(this.mode==='full-vector-fallback'){const n=this.paint(context,this.bodies.values());this.metrics.lastDynamicPaints=n;this.metrics.dynamicPolygonPaints+=n;return;}
  context.drawImage(this.canvas,0,0,this.width,this.height,0,0,CACHE_WIDTH,CACHE_HEIGHT);const n=this.paint(context,this.dynamicBodies());this.metrics.lastDynamicPaints=n;this.metrics.dynamicPolygonPaints+=n;
 }
 read(){const dynamicCount=this.dynamic.slice(1).reduce((n,m)=>n+m.size,0);return{mode:this.mode,fallbackReason:this.fallbackReason,liveCount:this.bodies.size,stableCount:this.stable.size,dynamicCount,countsConserved:this.bodies.size===this.stable.size+dynamicCount,dirtyTileCount:this.dirty.size,...this.metrics};}
}

