# GRAINFORM internal CA Game candidate

Internal candidate only. No Site checkout changed and no release/publication performed. The gameplay CA, fixed ID roughness, four material rules per60Hz output, and whole-block-to-cell conversion are deliberate game approximations. They replace the previous676 hard-circle/triangular-slot model with2304 tracked1px material cells per four-tile piece, preserving occupied area and normalized scoring mass.

## Run and verify

- `npm test`: current CA Game/phase and retained UI/worker contract tests
- `npm run verify:slots`: bounded reuse/atomic identity tests
- `npm run verify:parity`: self-contained551-frame comparison against the frozen roughness reference, including full paths, clear and support recovery
- `npm start`: local-only server, default127.0.0.1:4181
- `npm run verify:browser`: real Chromium smoke with existing Playwright. Set GRAINFORM_PLAYWRIGHT_MODULE only if its installed location needs explicit resolution. No installation or security changes are part of the script.

The dot environment could not start Chromium because ProcessSingleton socket creation was denied. This happened before loading Game; browser/UI wall-clock performance is NOT verified. The frozen package is intended for independent Codex environment verification. Do not give this candidate to the user as a working playtest until that completes.

## Preserved Game behavior

- Falling shape remains one solid four-cell silhouette. Each swept integer pose is tested; only actual contact atomically admits the entire2304-cell shape.
- `falling → settling → checking → flash → settling → spawn`; stable means exact no legal material move, two complete no-move active sweeps, and last physical frame actually presented by rAF.
-12 control flash ticks at60Hz preserve the old0.2second duration; score/level mass normalization changes169→576cells per tile to preserve the old score per block.
- Seven shapes, rotations, seeded next-piece selection, input phase locking, epoch and pieceId barriers, pause/blur/hidden/restart semantics are retained.
- UI rAF follows each recorded horizontal/vertical unit leg. It sends exact epoch/token acknowledgment only after painting the completed frame. Worker allows at most2unacknowledged material frames and retains owed wall-clock time under backpressure. No queue truncation or playback-rate tricks.
- Public stable handles use generation×capacity+slot. Grid and typed arrays use bounded slots; stale IDs cannot delete reused births.320-cycle reuse and ghost-path tests pass.

## What changed and what is still unverified

Raw CA cells no longer claim hard-circle contact mechanics. Fixed per-ID roughness permits either1or2horizontal cells before at least1downward cell, with complete clear paths and deterministic geometric sleep. The approved wake optimization visits each affected chunk once in the same insertion order; merged trajectories remain exact against the original reference.

The old node tests for676circle spacing and triangular row/column geometry are retained as historical source files but are not applicable to this explicitly approved model replacement. The current npm test list names the applicable CA and UI/worker tests. The old runtime itself remains separately preserved in grain048-dynamic-review; no old pass count is claimed as new proof.

Core headless timings do not include UI rendering, message cloning or event latency. The roughness candidate's original late-batch p95≈6–7ms and the wake patch's≈5ms remain above the internal4ms comparison gate. This alone does not establish60Hz failure or success. The browser smoke must measure actual wall time, presentation queue, renderer cost and worker messages. A slow machine must display retained debt rather than silently slow simulation or discard frames.

QA bridge/cascade/early-clear setups are explicitly artificial fixtures. Ordinary Game clears after each stable batch; the six-block density experiment deliberately delayed clear and is not its spawn schedule.

## Verification artifacts

- evidence/node-tests.log: current Node suite
- evidence/slot-merge-tests.json: bounded identity atomic tests
- evidence/slot-wake-parity.json:551exact frames,330rigid idle rule comparisons,4608clear,680support cut
- evidence/dot-browser-blocked.json: confirmed environment startup blocker
- browser-smoke.mjs: portable real-browser test sequence, not yet passed here
- validation-reference/: frozen original CA and minimal fixture/checkpoint data

No source was copied from an external falling-sand repository. Implementation borrows general game mechanisms independently, with source review kept in the broader task evidence.
