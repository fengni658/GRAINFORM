# 720-speed independent audit

## Result

The original one-parameter candidate had a genuine long-age quota defect: `v0=480`, age 9,999,800 produced four moves instead of the independent exact three. The parent-authorized saturation-branch fix passed the bounded checks below. Frozen r9 and all old oracle files remain unchanged.

Final audited candidate SHA-256: `b9e93450368b1f9c53b79c663b68958fa9456c1e11fb4ae018b3057bdd5b30a0`.
Pre-fix candidate SHA-256: `e17407b47975d6f9b8b3738078b9c95600139e38cf976f17216305fb16770783`.

## Explicit parameters and independent formula

- cap 720 is the authorized experiment parameter; cap 480 is the frozen comparison.
- dt=1/240 and gravity=900 are frozen inputs, explicitly asserted unchanged.
- `game.mjs:51` uses `180*min(1.45,.24+(level-1)*.065+min(.4,pieces*.002))`. For nonnegative integer pieces and levels starting at one, nominal birth speeds range 43.2 through 261. The finite enumeration covers all nominal values through saturation. Adapter default 480 and World default 0 are also included, totaling 1,181 values.
- Independent integral: `Q(t)=v0*t+450*t²` until `t=(cap-v0)/900`, then `Q(t)=cap*t-(cap-v0)²/1800`.
- Independently exact integer-age floors use BigInt, with `s=100*v0`: acceleration numerator `(4*s*n+750*n²)/96000`; saturated numerator `(75000*cap*n-(100*cap-s)²)/18000000`.
- Expected quotas do not call implementation Q or quota functions.

## Preserved failure

`original-long-age-failure.mjs` and `.log`: actual child exit **1**. At v0=480, age 9,999,800 (~11.574 material hours), cumulative Q values were 29,999,368 and 29,999,364.999999996. The old `floor(Q+1e-9)` difference was 4. The independent exact quota is 3. The fixed audit also instantiates the preserved pre-fix World and verifies its real material step moves the particle four cells.

`check-q.mjs` is pinned to the preserved pre-fix input. It retains the initial broader negative check of late-age cumulative floor precision. Large-Q representation error itself is not claimed fixed or used to reject the new saturated quota branch.

## Fix checks, actual exit 0

Run `node grain0410-speed720-audit/check-quota-fix.mjs`.

- 909,370 Q/formula/floor checks across separate caps 480 and 720 at ages 0..384.
- 454,685 exact quota checks; all integer and in [0,3].
- The same 454,685 short-age quotas equal the preserved pre-fix expression, so the fix does not perturb normal short-age results.
- 2,362 cap-threshold continuity checks.
- 7,086 long-age quota checks, including the failing age and ages 2^32 and 2^40. These latter two check quota arithmetic, not whole-simulation timestamp longevity.
- Five real-step probes at the failing age, v0=0/43.2/180/261/480: exactly one transportQuota invocation, return value 3, exactly three legal moves, ending y=103 from y=100.
- Nine other runtime files hash-identical to frozen r9.

Evidence: `quota-fix-results.json`, `quota-fix-run.log` (ACTUAL_EXIT=0).

## Independent full-awake reference, actual exit 0

Run `node grain0410-speed720-audit/all-awake.mjs`.

The reference is a separate sparse Map occupancy engine. It does not import either implementation's step, move, direction, Q, or quota. It uses the exact BigInt formula above and always visits all live particles in the fixed same-rule order. The old 480 oracle was not rewritten into a 720 self-reference.

Four bounded fixtures, rerun after the fix:
- Genuinely sleeping cross-chunk cone, removed floor supports, forward scan, birth speed 43.2.
- Same kind of old pile, reverse scan, birth speed 261.
- Forward lateral-boundary passed/pending fixture, birth speed 480, passed=32.
- Reverse lateral-boundary passed/pending fixture, birth speed 0, passed=16.

All 1,232 movement events and 310,688 interpolated position samples agree exactly, together with snapshots and RNG state. Evidence: `all-awake-results.json`, `all-awake-run.log` (ACTUAL_EXIT=0).

No model source was edited by this auditor. No publication, large performance replay, or additional parameter experiment was performed. Audit Node processes were confirmed finished before the parent's sequential timing comparison.
