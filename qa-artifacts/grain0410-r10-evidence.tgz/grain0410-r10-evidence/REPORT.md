# 0.4.10 r10 experimental candidate

## Result and limitations
Same fixed Node model replay: first/second 46/88 →43/69 output ticks; sixth128→100; twentieth159→112 (~1.867s at60 output Hz). First20 sum1345→1106 (-17.8%). These are material/game control ticks, not measured browser input-to-settle timing. Actual target under2s requires independent real app QA.

Node sequential CPU relative gate DID NOT PASS: total process CPU41.044→50.375s (+22.7%). No favorable rerun was selected. High19–20 output wall p95 was138.47→55.82ms, but baseline had941–1049ms tails; these absolute dot-node timings cannot be substituted for real Chromium. Total work decreased (particle visits9684966→8380344, direction checks35935079→30809382). Output peak slips1030→1499 (+45.5%) is a genuine concentration risk; peak total moves6751 unchanged, peak particle visits17441→17808 (+2.1%), direction checks70306→70931 (+.9%). Browser worker and main-frame budgets remain acceptance gates.

## Runtime changes relative to r9
Only ca-world.mjs changes:
1. maxSpeed480→720 logical units/s; gravity900, dt1/240, natural birth speeds, ordered wake-front,3-slip rule, Q, clocks/quiet/gates/cache remain.
2. Numerically stable saturated quota: when previous endpoint is already saturated, direct maxSpeed*dt yields integer3. Before/crossing threshold uses original small-magnitude floorQ difference. No clipping a computed4, no epsilon increase. This relies on the existing fixed cap/dt integer relation (480/240=2,720/240=3); no generic tunable-rate support is added.

This is a game material transport rate, not physical contact momentum. Newborn early ramp remains unchanged until its old480 threshold; previously aged/woken particles can immediately receive3. No claim that all old-pile first frames are identical.

## Long-age defect and exact compatibility
Pre-fix v0=480, age9999800 returned4 from catastrophic floor-boundary rounding; retained negative test exits1. Independent BigInt oracle checks explicit720/240/900 rather than importing implementation Q. Patched real step at that age/v0=0,43.2,180,261,480 returns3 and moves3. Full audit:454685 short-age quotas/compatibility,7086 long-age quotas,2362 cap continuity checks pass. Four independent sparse fully-awake fixtures:1232 ordered moves and310688 sampled paths exact, including old cross-chunk support removal and cursor-passed cases.

Pre/post numeric-fix dense20 exact comparison:1106 outputs,1351410 ordered moves, every output material frame/path and phase, every drop's final ID/color grid equal. No short-age material change hidden in the numeric correction.

## Geometry and mass
First/second final width-height107x41 and136x67 unchanged. First final occupied/color field identical; second2 occupied cells symmetric difference,0 color differences on shared cells. Sixth13824 admitted,2304 cleared,11520 retained. Dense20:46080 retained,0clear,232x237 final; per-color13824/13824/4608/13824; all20 terminal full-grid legal-move counts0.

Candidate first/second sampled762/996 phases (all endpoints,9 phases per ordinary frame,137 for frames0/1/25); max contour reversal.9375/1.39645logical cells unchanged fromr9. Actual324CSS early/worst/endpoint contacts and twentieth-tail contact show no renewed long horizontal bars/caps in inspected samples. Offline first/second132-frame comparison and high20 tail videos are supplied, earlier-finished side explicitly held settled. No mathematical all-input/all-phase or actual-browser smoothness guarantee.

Observed maximum per-rule path4points, per-output serialized39numbers=13points, below18/69storage capacity. At720 one rule has at most3actual moves, versus2 at480.

## Test-only history
r9 original slots report was overstated: first320bounded reuse subgroup passed, then obsolete vy15/credit.25 assertion failed. Separately preserved original FAIL, first corrected round's obsolete one-frame-movement FAIL, and complete7-group PASS. Final testfix expects actual dt gravity, cleared current quota and birth metadata; checks zero-birth first2frames do not move, thirdframe audits fresh generation. No runtime change from testfix.

Self-contained npm scripts include verify:720-quota and verify:720-awake (Node built-ins only), verify:motion's explicitly720 independent expected integral and full-awake same-rule reference, plus normal76/slots/340 suites. Frozen r9 history remains unchanged. See per-command exit records; completion is based on terminal exit codes, never earlier PASS lines.

Not published. Real QA should first record natural touch-down and second slope without screenshot/log load, then inspect endpoint/near-endpoint video frames; measure twentieth input-to-last-settling <2s, real worker/main-frame p95/p99/max and debt, cold peaks, cross-chunk old wake, pause/restart/final draw ACK/clear, reset retained-world count.
