# GRAINFORM 0.4.10 edge-contour-r4 (timeline selector)

Unpublished single-mechanism presentation protocol experiment over frozen r3. The r3 dirty-tile batching optimization, contour geometry, original grain texture and all cell/path simulation rules are retained unchanged. No smoothing parameter, color, resolution or particle count changed. Independent real-motion acceptance is required; this revision is not a claim that moving-edge teeth are eliminated.

## Evidence and bounded mechanism

Actual r3 browser samples showed alpha1 on95.35% of the second-drop draws and87.35% of high-density draws. Usually the successor was already received before the head frame's endpoint ACK. The old selector clamped to the head endpoint and only advanced the queue after drawing, causing repeated endpoint locking at approximately60Hz.

At the same time, an exact replay of recorded token59 shows that horizontal unit stages themselves create temporary attached short teeth; later vertical stages reduce them. Removing all glyph-protection circles does not remove the main residual. Therefore intermediate sampling is a testable response to excessive endpoint exposure, not a guarantee that every physical phase looks smooth.

The new selector chooses the actual current fixed time interval before drawing, provided its successor is already known. It never fabricates a path or samples an unreceived frame. A draw plan is immutable and does not mutate the queue. Renderer synchronization uses only the selected frame and subsequent known paths, so old-frame starting poses cannot pollute a successor sample. All particles retain the original68-stage axis-aligned positionOnPath function.

Only after a successful complete draw does the app commit receipts in token order. Crossed intermediate frames receive endpointDrawn=false, meaning temporal consumption only. The selected frame receives endpointDrawn=true only if its actual alpha1 was drawn. The worker uses consumedToken for released capacity, while presentedToken/world.presentedTick remain actual endpoint evidence. A quiet final frame explicitly requiresEndpointDraw; consumption-only ACK is rejected and cannot release its ready/clear barrier. The existing admission, two-quiet-sweep, no-movement and final-presented constraints remain in force.

Queue capacity remains two. Empty intermediate queues retain the fixed time anchor; only a successfully drawn final barrier ends the episode and resets the presentation origin. Pause/hidden time is excluded as before. Failed/stale draw plans, epoch changes or preview-only samples cannot ACK. Worker fixed60Hz accounting and retained debt are unchanged. This conservative design can still accumulate debt when actual rendering is too slow (in particular sustained below30Hz); it does not promise zero lag or60 displayed frames/s.

## Local correctness and required external review

Run npm test, verify:pixels, verify:pixels:browser, verify:slots, verify:parity and verify:browser. The existing252 pixel fixture draws compare the same explicit poses and remain exact; changed real-time pose selection is intentionally outside old frame-by-frame screen equivalence. New timeline tests exercise successor sampling, commit-only-on-draw, barrier rejection, pause/restart, missing frames, future-body isolation, all68 unit-path phases around an obstacle, actualGame spawn/clear gates and realWorker receipts. Original cell/path hashes and551-frame physics parity are preserved.

Independent browser review must record both consumed and endpoint receipts, sample alpha, selected token, pending queue, rejected ACKs and final-barrier release. A terminal clear must still have activeCount0 and an actually drawn final endpoint. Test pause/resume, hidden/restart, full resync and natural clears. Confirm actual continuous first/second-drop edges at DPR1/1.5/2; do not select only attractive phases or settled screenshots. Compare complete independent module roots.

Timing must separate actual settling activity from keyboard/ACK and falling gaps; report actual activity draw rate, draw-start intervals, CPU percentiles, debt peak, last-active-draw debt and later recovery separately. Previous r3 activity-only rate was57.73draw/s in one run, and remaining activity-ending debt must not be hidden by a later falling-window endpoint. Memory reset and bounded maps should be rechecked; earlier short tests did not prove long-term native leak freedom.

Frozen049/r1/r2/r3 and their partial-improvement/failure evidence remain. No deployment included. The older monolithic Node edge-sequence is not required because of separately reproduced native Canvas retention; Node raster checks are not browser timing or memory proof.
