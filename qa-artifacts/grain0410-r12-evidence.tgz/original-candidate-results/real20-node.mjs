import fs from'node:fs';import{createRequire}from'node:module';const{createCanvas}=createRequire('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/x.js')('@napi-rs/canvas');
const result=await(async()=>{
  const {CALayerRenderer:Old}=await import('../../grain0410-r11-external/unpacked/candidate/ca-layer.mjs'),{CALayerRenderer:New,positionOnPath}=await import('../ca-layer.mjs'),{Game}=await import('../game.mjs');
  const checks=[],targets=[1,1.5,2].map(dpr=>({dpr,pair:[Old,New].map(T=>{const c=createCanvas(1,1);c.width=324*dpr;c.height=486*dpr;return{c,ctx:c.getContext('2d',{alpha:false}),r:new T({createCanvas:()=>createCanvas(1,1)})}})}));
  const same=(a,b,label)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Data mismatch '+label)};
  const dump=c=>({records:[...c.records],pending:[...c.pending],previousMoving:[...c.previousMoving],links:[...c.links],points:[...c.points],shades:[...c.shades],squares:[...c.squares],preserved:[...c.preserved],result:c.result,metrics:c.metrics,linear:c.result.loops.map(l=>!!l.linear)});
  function verify(cases,label){for(const {dpr,pair}of cases){const[a,b]=pair;same(dump(a.r.contour),dump(b.r.contour),label+'/contour');for(const key of['field','rounded']){const x=a.r.contour[key],y=b.r.contour[key];for(let i=0;i<x.length;i++)if(!Object.is(x[i],y[i]))throw Error('Field mismatch '+label+'/'+key+'/'+i)}same(a.r.contour.roundedBodies.map(s=>s?[...s]:null),b.r.contour.roundedBodies.map(s=>s?[...s]:null),label+'/roundedBodies');const x=a.ctx.getImageData(0,0,a.c.width,a.c.height).data,y=b.ctx.getImageData(0,0,b.c.width,b.c.height).data;for(let i=0;i<x.length;i++)if(x[i]!==y[i])throw Error('RGBA mismatch '+label+'/DPR'+dpr+'/'+i)}}
  const g=new Game({seed:1});g.start();for(const t of targets)for(const x of t.pair)x.r.apply(g.frame({full:true}).bodyPatch);
  let totalPixels=0,totalData=0;
  for(let j=0;j<20;j++){
   const i=j+50,dx=[-4,3,-1,4,-4,1][i%6];for(let k=0;k<Math.abs(dx);k++)g.move(dx<0?-24:24);if(i&1)g.rotate();g.drop();let n=0;
   // Include first contact before any physics step, unlike the older selected-frame harness.
   let f=g.frame();for(const t of targets)for(const x of t.pair)x.r.apply(f.bodyPatch);
   const contact=[0,1,19].includes(j);if(contact){for(const t of targets)for(const x of t.pair){x.r.synchronize([],null);x.r.configure(x.c.width,x.c.height,'standard');x.ctx.setTransform(x.c.width/288,0,0,x.c.height/432,0,0);x.ctx.fillStyle='#0d1315';x.ctx.fillRect(0,0,288,432);x.r.draw(x.ctx)}verify(targets,'contact'+(j+1));totalPixels+=3;totalData+=3;checks.push({piece:j+1,contact:true,live:g.world.count});}
   while(g.phase!=='falling'&&g.state!=='over'){
    if(n++>220)throw Error('sim timeout');g.step();f=g.frame();const m=f.materialFrame;if(!m)continue;for(const t of targets)for(const x of t.pair){x.r.synchronize([m],{positions:m.paths.map(q=>({id:q.id,xy:positionOnPath(q,1)}))});x.r.apply(f.bodyPatch)}
    if([0,1,19].includes(j)&&([0,1,5,10,20,40,65,90].includes(n-1)||m.requiresEndpointDraw)){
     for(const alpha of[0,.125,.25,.5,.75,.875,1]){
      for(const t of targets)for(const x of t.pair){x.r.synchronize([m],{positions:m.paths.map(q=>({id:q.id,xy:positionOnPath(q,alpha)}))});x.r.configure(x.c.width,x.c.height,'standard');x.ctx.setTransform(x.c.width/288,0,0,x.c.height/432,0,0);x.ctx.fillStyle='#0d1315';x.ctx.fillRect(0,0,288,432);x.r.draw(x.ctx)}
      verify(targets,'piece'+(j+1)+'/frame'+n+'/alpha'+alpha);totalPixels+=3;totalData+=3;checks.push({piece:j+1,frame:n,alpha,token:m.token,paths:m.paths.length,endpoint:m.requiresEndpointDraw});
     }
    }
    g.completePresentation(m.token,{endpointDrawn:true});
   }
   if(g.state==='over')throw Error('over');
  }
  return{pass:true,totalPixels,totalData,checks,live:g.world.count,scope:'Actual Game seed1 first, second, twentieth representative phases plus contact; exact old/new contour outputs, all internal state including fields/records/nodes/weights/links, and Node @napi-rs/canvas RGBA at backing scales1/1.5/2. This is offline equivalence, not a performance trace.'};
})();fs.writeFileSync('diagnostic/real20-node.json',JSON.stringify(result,null,2));console.log(JSON.stringify({pass:result.pass,totalPixels:result.totalPixels,totalData:result.totalData,live:result.live}));
