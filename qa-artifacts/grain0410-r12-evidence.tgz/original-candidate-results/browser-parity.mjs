import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {chromium} from '/opt/codex/cua_node/lib/node_modules/playwright/index.mjs';
const root=process.cwd(),old=path.resolve(root,'../grain0410-r11-external/unpacked/candidate'),out=path.join(root,'diagnostic');
const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const p=await b.newPage(),errors=[];p.on('pageerror',e=>errors.push(String(e)));
try{
 await p.route('http://grain.local/**',async route=>{const u=new URL(route.request().url()),name=u.pathname.slice(1);if(!name)return route.fulfill({contentType:'text/html',body:'<!doctype html><pre id="result"></pre>'});let file;if(name==='new/tests/reference/paint/ca-layer.mjs')file=path.join(old,'ca-layer.mjs');else if(name==='new/tests/reference/paint/ca-contour.mjs')file=path.join(old,'ca-contour.mjs');else file=path.join(name.startsWith('old/')?old:root,name.replace(/^(old|new)\//,''));await route.fulfill({contentType:name.endsWith('.mjs')?'text/javascript':'text/plain',body:fs.readFileSync(file)});});
 await p.goto('http://grain.local/');
 const fixture=await p.evaluate(async()=>{const {runPixelEquivalence}=await import('/new/tests/paint-old-new-pixels.mjs');return runPixelEquivalence({backend:'Chromium Canvas2D; frozen r11 versus contour enumeration micro candidate'})});
 fixture.baseline='Frozen r11 source, independently routed ca-layer and ca-contour';fixture.candidateStatus='Only four-neighbor temporary array enumeration replaced with ordered scalar locals';
 assert.equal(fixture.passed,true);assert.equal(fixture.drawComparisons,340);fs.writeFileSync(path.join(out,'browser-fixture340.json'),JSON.stringify({browser:await b.version(),errors,...fixture},null,2));console.log('Native Chromium fixture340 PASS');
 const real=await p.evaluate(async()=>{
  const {CALayerRenderer:Old}=await import('/old/ca-layer.mjs'),{CALayerRenderer:New,positionOnPath}=await import('/new/ca-layer.mjs'),{Game}=await import('/new/game.mjs');
  const checks=[],targets=[1,1.5,2].map(dpr=>({dpr,pair:[Old,New].map(T=>{const c=document.createElement('canvas');c.width=324*dpr;c.height=486*dpr;return{c,ctx:c.getContext('2d',{alpha:false}),r:new T({createCanvas:()=>document.createElement('canvas')})}})}));
  const same=(a,b,label)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error('Data mismatch '+label)};
  const dump=c=>({records:[...c.records],pending:[...c.pending],previousMoving:[...c.previousMoving],links:[...c.links],points:[...c.points],shades:[...c.shades],squares:[...c.squares],preserved:[...c.preserved],result:c.result,metrics:c.metrics,linear:c.result.loops.map(l=>!!l.linear)});
  function verify(cases,label){for(const {dpr,pair}of cases){const[a,b]=pair;same(dump(a.r.contour),dump(b.r.contour),label+'/contour');for(const key of['field','rounded']){const x=a.r.contour[key],y=b.r.contour[key];for(let i=0;i<x.length;i++)if(!Object.is(x[i],y[i]))throw Error('Field mismatch '+label+'/'+key+'/'+i)}same(a.r.contour.roundedBodies.map(s=>s?[...s]:null),b.r.contour.roundedBodies.map(s=>s?[...s]:null),label+'/roundedBodies');const x=a.ctx.getImageData(0,0,a.c.width,a.c.height).data,y=b.ctx.getImageData(0,0,b.c.width,b.c.height).data;for(let i=0;i<x.length;i++)if(x[i]!==y[i])throw Error('RGBA mismatch '+label+'/DPR'+dpr+'/'+i)}}
  const g=new Game({seed:1});g.start();for(const t of targets)for(const x of t.pair)x.r.apply(g.frame({full:true}).bodyPatch);
  let totalPixels=0,totalData=0;
  for(let j=0;j<20;j++){
   const i=j+50,dx=[-4,3,-1,4,-4,1][i%6];for(let k=0;k<Math.abs(dx);k++)g.move(dx<0?-24:24);if(i&1)g.rotate();g.drop();let n=0;
   // Include first contact before any physics step, unlike the older selected-frame harness.
   let f=g.frame();for(const t of targets)for(const x of t.pair)x.r.apply(f.bodyPatch);
   const contact=[0,1,19].includes(j);if(contact){for(const t of targets)for(const x of t.pair){x.r.synchronize([],null);x.r.configure(x.c.width,x.c.height,'standard');x.ctx.setTransform(x.c.width/288,0,0,x.c.height/432,0,0);x.ctx.fillStyle='#0d1315';x.ctx.fillRect(0,0,288,432);x.r.draw(x.ctx)}verify(targets,'contact'+(j+1));totalPixels+=3;totalData+=3;checks.push({piece:j+1,contact:true,live:g.world.count});}
   while(g.phase!=='falling'&&g.state!=='over'){
    if(n++>220)throw Error('sim timeout');g.step();f=g.frame();const m=f.materialFrame;if(!m)continue;for(const t of targets)for(const x of t.pair){x.r.synchronize([m],{positions:m.paths.map(q=>({id:q.id,xy:positionOnPath(q,1)}))});x.r.apply(f.bodyPatch)}
    if([0,1,19].includes(j)&&([0,1,5,10,20,40,65,90].includes(n-1)||m.requiresEndpointDraw)){
     for(const alpha of[0,.125,.25,.5,.75,.875,1]){
      for(const t of targets)for(const x of t.pair){x.r.synchronize([m],{positions:m.paths.map(q=>({id:q.id,xy:positionOnPath(q,alpha)}))});x.r.configure(x.c.width,x.c.height,'standard');x.ctx.setTransform(x.c.width/288,0,0,x.c.height/432,0,0);x.ctx.fillStyle='#0d1315';x.ctx.fillRect(0,0,288,432);x.r.draw(x.ctx)}
      verify(targets,'piece'+(j+1)+'/frame'+n+'/alpha'+alpha);totalPixels+=3;totalData+=3;checks.push({piece:j+1,frame:n,alpha,token:m.token,paths:m.paths.length,endpoint:m.requiresEndpointDraw});
     }
    }
    g.completePresentation(m.token,{endpointDrawn:true});
   }
   if(g.state==='over')throw Error('over');
  }
  return{pass:true,totalPixels,totalData,checks,live:g.world.count,scope:'Actual Game seed1 first, second, twentieth representative phases plus contact; exact old/new contour outputs, all internal state including fields/records/nodes/weights/links, and native Chromium RGBA at backing scales1/1.5/2. This is offline equivalence, not a performance trace.'};
 });
 assert.equal(errors.length,0);fs.writeFileSync(path.join(out,'browser-real20.json'),JSON.stringify({browser:await b.version(),errors,...real},null,2));console.log(JSON.stringify({pass:true,realPixels:real.totalPixels,realData:real.totalData,live:real.live}));
}finally{await b.close()}
