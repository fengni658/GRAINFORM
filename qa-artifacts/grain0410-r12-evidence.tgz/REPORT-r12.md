# GRAINFORM 0.4.10 r12：contour enum 实验候选

冻结范围：基于完整r11 c5b7fde7af94d0af106feb5b3f4eb593db66da61，仅ca-contour.mjs第13行四邻点临时数组枚举改成顺序标量。另9运行文件逐哈希相同。r11原目录未改，未上传、push或发布。

## 结论

纯等价改动已通过此次Node数据/路径/命令/像素复核。首帧2304个next record对应少11,520次源码级临时数组构建；实际V8堆分配、GC及冷峰收益尚未验证。不得宣称Chrome冷首帧46–54ms已改善或无卡顿。

只展开原q/a四项枚举，保持表达式和求值顺序、if(a)、插入顺序，每个record和nodes/weights仍独立。无池化、无预热、无轮廓阈值/物理/粒数/时钟/视觉改动。

原contour SHA256：48bee8737347950efe4faab20a25de7b40ec5cd99168a6a479108fdefb8471fa
r12 contour SHA256：ab7bdafd6f9c1b3adc70d74993949c77b9a125e4299cba8c6c03be7da94a8784

## 已完成且有exitcode的检查

原候选源码：npm test 76/76、专项105、Node @napi-rs/canvas既有340逐RGBA、364组精确Canvas命令及RGBA（2,724,962命令）、真实Game首二/高20代表帧555次完整contour数据和555次RGBA。全部exit0。

真实Game检查包含首次触地、早/中/晚/终态，alpha 0/.125/.25/.5/.75/.875/1，backing scale 1/1.5/2，最终live46080。是离线数据与Node栅格，不是实时Chrome或真实设备DPR性能。

专项105次包括95个成功结果以及10个超实际棋盘域旧新同样异常。实际棋盘四边、小数/取整边界、删除/重填/重置、双色/对角/孔洞和孤岛单独覆盖；6004次跨record数组独立及旧record不变检查。超域异常未扩修。

独立验证：从完整原r11另建目录，安全解压本delta及自包含validation-overlay后，核对10运行文件，实际import ca-contour/ca-layer/Game及包内r11参考模块、像素fixture模块；import exit0。再实际运行原tests/run-test-gates.mjs，wrapper exit0、slots全部7组exit0、npm76/76 exit0；76包含worker3。最后105专项再次exit0。此次不是只看旧报告或PASS子项。

340/364/555像素及真实Game矩阵是在同哈希的初始micro候选执行，独立解压阶段明确引用这批结果，没有再重复该矩阵。独立阶段实际重跑的是imports、wrapper(slots7+76)和105专项。r11的其他浏览器/UI/长期运动矩阵未在本轮重跑，不能将其记录改称r12新验证。

## 浏览器与性能边界

本地Chromium两次启动在建页前socket() EPERM：第二次同命令提权请求是在父停止指令到达前发出；收到停止后没有再重试、换file/data URL或绕行。两次exit1及原始日志保留。本轮无Chrome像素结果、无新trace、无CPU/GC收益对照。详细旧r9 trace分因见REPORT-existing-r9-cold-trace.md；主体为实际首块轮廓与真实GC，不能把峰归为单一Canvas冷初始化。

首次专项因超域旧实现异常exit1、首次shell日志路径启动错误（npm未运行）也记录在original-candidate-results/exit-status.json。未把修订后的通过倒写为初版通过。

## 包内容与复核

- delta：ca-contour.mjs与R12-MANIFEST.json。后者列完整10运行文件old/new SHA、唯一payload字节数/SHA。
- evidence：original-candidate-results/保留原执行日志/JSON/测试源；independent-verification/是独立解压后的实际门；validation-overlay/包含可移植测试和仅两份r11参考renderer/contour。
- FILE-MANIFEST.json列证据中除清单本身以外全部文件的字节数/SHA，并重复10运行文件清单。所有最终归档都再次独立解压、校验证据与runtime哈希及tar路径安全。

在完整r11根目录覆盖delta，然后覆盖证据validation-overlay即可重跑。用本环境现有@napi-rs/canvas依赖：NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules node tests/run-test-gates.mjs diagnostic/replay-wrapper。其余命令为node diagnostic/contour-targeted.mjs、node diagnostic/fixture340.mjs、node tests/contour-enum-commands.mjs、node diagnostic/real20-node.mjs。不要使用original-candidate-results/中留作原始记录的旧路径脚本重放；使用validation-overlay提供的包内相对路径版。

完整r11复制目录内继承的旧报告和manifest是基线材料，不构成r12的新冻结声明。下一步由独立Chrome环境只做狭窄冷/暖配对与原生像素验证，再决定是否接受该实验候选。
