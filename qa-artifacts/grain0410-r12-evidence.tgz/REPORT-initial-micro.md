# GRAINFORM contour-enum micro 候选复核

2026-10-09。基于完整冻结 r11（c5b7fde7af94d0af106feb5b3f4eb593db66da61）另建副本。未修改原 r11，未上传、冻结、提交或发布。

## 唯一运行改动

ca-contour.mjs 第13行：把四个双线性邻点的临时数组枚举展开成八个顺序求值的 q/a 标量和四个 if(a) 分支。原 q0/a0 → q1/a1 → q2/a2 → q3/a3 求值顺序、各乘法表达式、四项插入顺序和条件不变。

保留每个 next record 及其独立 nodes/weights。没有集合或 record 池化、共享数组、ready 预热、物理或轮廓算法/阈值/粒数/路径/时钟/视觉改变。另9运行文件与冻结 r11 完全一致，结束后再次校验。

- 原 ca-contour SHA256：48bee8737347950efe4faab20a25de7b40ec5cd99168a6a479108fdefb8471fa
- 候选 SHA256：ab7bdafd6f9c1b3adc70d74993949c77b9a125e4299cba8c6c03be7da94a8784
- 最小补丁：diagnostic/contour-enum.patch
- 全运行文件校验：diagnostic/runtime-integrity.json

首帧2304个有效 next × 每次一个外层数组和四个子数组，可消除11,520次源码级临时数组构建。V8可能消除其中部分实际分配，没有 allocation stacks 或浏览器性能对照，不能称减少了11,520个实际堆对象、GC降低或冷峰已消失。

## 本次实际完成的 Node 检验

所有命令都检查真实 exit code，汇总为 diagnostic/exit-status.json。

1. 原项目 npm test：76/76，通过，exit0。
2. 冻结r11对候选的既有图像fixture：340组逐RGBA零差异，exit0；Node @napi-rs/canvas。
3. 冻结r11对候选的命令fixture：364组逐RGBA零差异，2,724,962条Canvas命令/属性/浮点参数/次序完全一致；2,680,712次冻结body检查，exit0。覆盖raw/cached/fallback、52,992粒密集材料、局部重绘、路径插值、重置/删除、调色、尺寸和高亮。
4. 真实Game seed1同一物理轨迹首块、第二块、高20代表帧：包含首次触地且在选定早/中/晚/终态帧使用alpha 0/.125/.25/.5/.75/.875/1，backing scale 1/1.5/2；555次contour完整输出和内部状态比较、555次逐RGBA零差异，exit0；最终live=46080。检查records/nodes/weights、links/points/shades/squares、roundedBodies、result/loops/preserve/linear及field/rounded全部元素。这是离线Game与Node栅格等价检验，不是实时worker、真实设备DPR或Chrome性能数据。
5. 专项：105次状态比较，包含95次成功结果与10次超实际棋盘域异常的一致性，exit0；另6004次跨粒数组独立性/旧record不变检查。覆盖实际棋盘四边、小数与取整阈值两侧、删除/重填/重置、generation替换、双色相邻与两种对角、孔洞和孤岛。

证据：diagnostic/base76.log、fixture340.json、command364.json、real20-node.json、contour-targeted.json 及对应日志/exit文件。新测试源码位于diagnostic/及tests/contour-enum-{pixels,commands}.mjs。复制目录中原有r11报告/证据/清单是基线归档，不能当成本候选新完成的检查或冻结清单；以本报告与diagnostic/为准。

## 保留的失败与范围限制

- 专项初版给轮廓网格角(-0.5,-0.5)等超实际棋盘域输入，冻结r11先报“Missing material contour vertex”，初版exit1被保留。最终专项单独记录10个两版同样异常并比较异常后状态；实际棋盘x=28.5/259.5、y=0.5/419.5边界另外通过。未扩修已有轮廓域外行为。
- 本地Chromium首次以及在父停止指令到达前发出的同命令提权重试，都在页面创建前以socket() EPERM失败。两次exit1/日志保留；收到停止后未再次尝试，没有file/data URL等绕行，没有浏览器像素、Chrome trace或新CPU/GC数据。
- 首次shell测试启动误用父cwd的日志路径，重定向失败，npm并未执行；随后在候选cwd运行的实际76项测试exit0。未把启动失败当产品失败或掩盖。

## 交给下一位验证者

候选完整目录是 grain0410-contour-enum-micro，原冻结r11保持不变。可以把本单行补丁送独立Chrome环境做真实Canvas逐像素和有界冷/暖性能配对。只凭本次Node等价结果不能宣称冷首帧46–54ms或偶发暖21ms已解决，也不能宣布无卡顿/可交付。此前只读分因见同级 grain0410-cold-readonly-diagnostic/REPORT.md。
