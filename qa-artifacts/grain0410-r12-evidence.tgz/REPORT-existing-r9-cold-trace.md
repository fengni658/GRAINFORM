# GRAINFORM 首次沙粒绘制峰：现有 r9 trace 只读分因

日期：2026-10-09。只读取现有归档、统计现有 Chrome trace 并对照冻结源码；没有浏览器运行、新 trace、性能回放、候选修改或发布。本文不是 r11 新性能基准。

## 结论

50.5 ms 的首次沙粒 draw 有明确的形状相关 MaterialContour.update 工作和真实主线程 MinorGC，不能简单归因为 Canvas 冷启动。现有证据不支持通过 ready 预热解决主体峰值。唯一建议的最小后续候选：去掉 ca-contour.mjs:13 每个有效 next record 的临时邻点“外层数组 + 四个 [q,a] 数组”，保持四项顺序、浮点表达式、if(a)、独立 record/nodes/weights 和输出完全一致。首帧 2304 次更新对应 11,520 次源码级临时数组构建。未实施；不把这项计数说成实际堆分配数或已验证的性能收益。

## 精确事件与观测

对齐：pid=53926，main tid=53926，worker tid=53961；graintrace-main-origin ts=87141305121 μs 对应 page performance.now()=403.5 ms。以下均为 page ms。原始文件：grain0410-r9-trace-external/unpacked/chrome-trace.json；配套 perf-r9-trace-once-dpr2-high.json。

- RunTask 545.413–598.504，53.091 ms；对应 PerformanceObserver 的 545.4–598.4、53 ms longtask。
- FireAnimationFrame 545.472–596.175，50.703 ms；FunctionCall 545.483–596.141，50.658 ms。外部 probe 记录实际回调/draw 545.600–596.100，均 50.5 ms。
- 首帧 live=active=2304、stable=2304、dynamic=0；contour rebuilds=1，lastUpdatedGrains=2304，lastUpdatedSquares=2425，vertices=240，preserve=0、centerGuard=0；17 个脏 tile、2304 次稳定粒绘制。该帧是第一次真实材料入场，尚无运动路径插值。
- 回调前 worker.onmessage 在 531.526–545.107，13.581 ms，包含另一次 MinorGC 538.725–540.828（2.103 ms）。这是前置独立任务，不计入 50.5 ms draw。
- draw 内 getBoundingClientRect 触发 Document::UpdateStyleAndLayout 545.564–546.927，1.363 ms；其中 Layout 1.009 ms。这不是主体峰。
- 主线程 MinorGC：549.190–550.716（1.526 ms）；551.915–553.828（1.913 ms）；562.658–564.005（1.347 ms）；574.622–575.368（0.746 ms）。四次合计 5.532 ms，都是 allocation failure。另有 V8.GC_HEAP_EXTERNAL_PROLOGUE 573.313–574.619，1.306 ms。无该窗口主线程 MajorGC。
- worker 554.845–558.863 的 4.018 ms MinorGC 在另一线程，不能叠加成主线程阻塞时长。

### CPU 采样说明与栈

按 Profile/ProfileChunk 节点及 timeDeltas 重建此 FunctionCall 内的 own-sample 权重。它是采样近似，不是函数插桩墙钟、自身 CPU 精确时间或可加总的性能预算；记录在邻近任务边界还出现负 timeDelta，故不用总权重证明时间守恒，也不用 tdur 估算 OS 抢占。

- MaterialContour.update（ca-contour.mjs:8）自身采样权重约 17.650 ms；其 isCore 1.815 ms、shadeAt 0.194 ms、line44 匿名回调 0.116 ms。样本持续出现在 547.284–579.681，混有 GC 和父 draw 样本，不能把该区间 32.397 ms 全算作 update 自身执行。
- 典型栈：update → CALayerRenderer.draw（r9 ca-layer.mjs:207）→ app.draw（r9 app.mjs:170）→ renderLoop → rAF probe。
- GC 样本约 9.822 ms，和精确 MinorGC 5.532 ms 不等价；不据此断言额外停顿都是 GC，不将产品与诊断工具的分配归因混在一起。
- 后半段：fill 约 5.006 ms、paint 3.204 ms、drawImage 2.563 ms；典型栈 fill → tinyGrain → paint → CALayerRenderer.draw。都在真实 2304 粒的稳定 tile 重绘路径中。

### Canvas、栅格与编译证据

- ca-layer.mjs 首次 dirtyTiles 分支此时才创建 scratchCanvas。580.208 有 getContext 样本；580.492–583.870 是连续 setTransform 样本，setTransform 权重约 3.528 ms，getContext 0.200 ms。源码和顺序共同支持这是首次 scratch 资源使用相关路径，但 trace 没有给每次 JS 原生 API 调用的完整边界，也不能把 3.528 ms 全称作显存分配。
- 可见 C++ 初始化事件很短：RenderThreadImpl::EstablishGpuChannelSync 580.439–580.454（0.015 ms）；Canvas2DResourceProviderSharedImage::CreateSkSurface 580.489–580.553（0.064 ms）。不能据这些事件把整个 50.5 ms 归到 Canvas 初始化。
- 主 cache/显示 Canvas 在 481.315、513.908 已有 Snapshot，此前还有多次 ProduceCanvasResource。不是第一次页面使用 Canvas。
- 595.826 起出现 scratch Snapshot/复制；后续网页 lifecycle/commit 在 596.198 之后，ProduceCanvasResource 597.504–598.075（0.571 ms）已在测得 draw 结束后。draw 窗口没有可解释主体峰的长 RasterTask 事件。
- 当前 trace 没有编译或 shader 编译事件。窗口内只有 V8.DeoptimizeCode 572.823（0.008 ms）和 592.941（0.008 ms）。没有详细 v8.compile/Skia/GPU memory/native API 调用记录，因此既不能称“首次编译导致峰”，也不能完全排除未被该 trace 配置单独捕获的编译/原生开销。
- 无 OS sched_switch、无分配调用栈。不能用“剩余时间”给 OS、GC、Canvas 栅格或编译指定根因。

## ready 能否提前准备

MaterialContour 的 field、rounded、roundedBodies 等基础容器已在 renderer 构造时创建。空 ready 的 update 没有 updates 就返回；用空场反复 draw 不会执行真实首块热点。首块粒 ID、位置、颜色和后续展示姿态决定 records、dirty squares、ownership/color、轮廓连线及平滑结果，不能拿未知首块在 ready 预算，也不应偷偷投放假材料或改变就绪/绘制/ACK语义。

scratchCanvas 的创建、尺寸和基础 transform 确实不依赖首块形状，是可提前进行的真实资源初始化。但证据只支持它是较小相关段；它不是主体轮廓成本的 ready 解决方案，而且提早创建会改变初始化失败/回退时机和资源生命周期。本轮不把这一项列为值得单独实施的“消峰方案”，更不建议伪粒子预热。

## update 内生命周期与可复用边界

### 必须保留独立跨帧身份；不要池化

- records Map 的 next 对象，以及每个 next.nodes、next.weights 数组：line20 存入 records；下一次 update 的 old 在 line19 用它们减掉旧场贡献，之后才加 next。若就地改 old 或让多个 record 共用数组，会使旧场扣除或不同粒记录损坏。
- roundedBodies[q] 的 Set：跨帧保存该取整格有哪些 ID，供邻域/颜色/支撑查询。第一块会初始化大量实际占用格集合，属于材料相关持久状态。
- links、points、shades、squares：保存轮廓增量状态；points 值来自 xy 内部坐标数组，squares 值来自 fromKeys。不能把这些内部数组当临时 scratch 覆写。
- preserved Map 的 [id,x,y,strength] 值与最终 result.preserve 元素存在共享引用；loops/smooth/result 是返回且可能供后续绘制复用的输出。未变更新也会返回同一个 result，不能随意清空复用这些输出。
- pending 与 previousMoving 是跨调用状态。pending 在 line9 先交接为 candidates，随后 this.pending 换新 Set；若简单 clear() 会擦掉当前候选。previousMoving 必须保留到下一次候选合并后才能替换。

### 函数局部 scratch，可以讨论清空后复用，但收益未证实

- updates 容器与每个 [id,old,next] 包装本身不逃逸；old/next 引用的对象逃逸。可以在后续设计中复用私有包装/并行列表，但调用结束需清掉引用，不能复用其指向的 record。仅复用 updates 外层并不会消掉逐粒三元组。
- dirtyNodes、dirtyRounded、oldRounded、dirtySquares、inspect、coreCache、shadeCache 都是当前同步调用的临时集合/缓存，未返回、未存到持久字段；独占实例、无重入且每次开始/异常结束可靠 clear 的前提下可复用。clear 不保证 V8 保留内部容量，因此不声称 ready 创建空 Set/Map 会消掉首次容量分配或 GC。
- line41 的 links 副本用于破坏性遍历，不能改为直接消费 this.links。只可复用独立临时 Map，再按同序复制。
- 包装用常量邻域数组和临时枚举数组不必跨帧保留，可改成同序标量求值或只在局部使用的常量索引；不得共享即将保存到 records/points/squares/result 的数组。

## 唯一最小候选与计数边界

只针对 line13 的四邻点临时枚举：当前每个有效 next 必定求值一个外层数组及四个 [q,a] 子数组，即便多数 a 为 0，数组字面量也先被求值。首帧 next=2304，对应 2304×5=11,520 次源码级数组构建。保留 next 对象和各自两条 nodes/weights 数组（2304 对、4608 个持久数组）不动；依次计算原四个 q/a，仍仅 if(a) 才 push。不要给 old record 重新赋值、不要预演物理、不要移到 ready。

此候选不变算法、阈值、粒数、排序、随机性、路径、时钟或输出。需要后续授权实施与原生像素/命令序列等价复核后才可比较一次有界冷帧；当前只有源码层面的可消除重复构建，Chrome trace 没有 allocation stack，V8 可能消除部分临时对象，因此不承诺 11,520 个实际堆对象、释放多少字节、GC 减少多少或降到 16.67 ms 内。

r9 与 r11 的 ca-contour.mjs 完全相同，SHA256: 48bee8737347950efe4faab20a25de7b40ec5cd99168a6a479108fdefb8471fa。r11 的动态 paint 去临时 body 不影响此首帧，因为 dynamic=0；UI 去重对布局开销可能有关，但不能据 r9 trace 给 r11 的冷峰精确分因。
