# Experiment B: target-only adjacent diagonal slip

**Numerical screening complete. One continuous real-game video review is justified; this is not visual approval or permission to publish.**

Built independently from frozen r13. The only runtime change removes the same-height lateral vacancy condition in direction(). The actual simulation already calls this method without reservations; the down-diagonal destination must still be empty and in bounds. Original bottom-to-top ordering, generation checks, Q/birth speed, g=900, cap=720, four real 1/240-second substeps, max-three current moves, all colors/grains, renderer, arc timing and final ACK are unchanged. Neither A ordering nor failed contact-roll rules are included.

## Explicit collision model and limitations

This is discrete occupied-cell material transport, not continuous-circle contact or swept-disk collision equivalence. The animated diagonal can cut between occupied same-height/below neighbours. The old lateral-corridor collision assertion intentionally does not pass and has not been relabeled as a success.

- Every audited move ends in an empty cell; container bounds remain strict. A complete axis-aligned one-cell wall blocks a diagonal whose target is occupied.
- Two particles touching at a corner leave no finite-width physical gap, but B allows a diagonal between them. An 8-connected diagonal chain formed only by corner contacts is therefore not an impermeable rigid barrier in B.
- A one-cell aperture beneath an occupied upper lip is reachable diagonally, including corner clipping.
- The current game has container boundaries and sand piles, not internal rigid obstacles. The parent explicitly classified particle corner chains as the approximation under review, while retaining strict container/occupied-target and axis-wall constraints. If rigid internal obstacles are later introduced, this rule requires separate obstacle clearance handling.

The wall/aperture/corner fixtures are instantaneous direction-eligibility queries, not claims that isolated grain walls are physically fixed objects. The natural-game audit below separately observes actual committed motions.

## Same seed and six fixed inputs

| Drop | r13 frames | B frames | r13/B width × height | r13/B lateral grains | r13/B particle visits | B corner-cut events |
|---|---:|---:|---|---:|---:|---:|
| 1 | 43 | 22 | [107, 41] / [120, 33] | 462 / 1099 | 160392 / 92978 | 9279 |
| 2 | 69 | 35 | [136, 67] / [147, 54] | 1213 / 2216 | 582545 / 329979 | 45203 |
| 3 | 28 | 20 | [191, 67] / [197, 54] | 298 / 2247 | 196906 / 179311 | 18381 |
| 4 | 81 | 38 | [216, 84] / [222, 73] | 1252 / 2300 | 679236 / 342448 | 45481 |
| 5 | 35 | 24 | [217, 97] / [222, 83] | 310 / 2169 | 255961 / 189436 | 26867 |
| 6 | 89 | 37 | [232, 97] / [232, 83] | 1236 / 2302 | 685240 / 395541 | 63886 |

First / second / sixth settle in 0.367 / 0.583 / 0.617 seconds, versus r13 0.717 / 1.150 / 1.483 seconds. More grains can spread laterally and piles become wider/flatter. The clock was not accelerated, but this might still look too fast or loose; faster settling is not the quality criterion.

## Limited checks actually run

- 524,242 actual B movement events: destination vacancy, container bounds, adjacent downward/diagonal steps, support for diagonal choice, per-substep original quota and ≤3 moves. Actual same-height occupied-side crossings are counted openly.
- Six Game episodes conserve all mass and each identity’s color. Live counts are 2304, 4608, 6912, 9216, 11520, 13824. This input sequence causes no clears.
- In every episode, older settled layers make exactly 0 moves and retain exact positions/colors while new material lands. The change opens new-particle side scattering without ongoing flow through the natural settled color layers.
- Full-grid independent geometric enumeration finds 0 legal rest actions after every drop. After the sixth, 20 idle output frames and one forced-full-awake output make 0 moves.
- A 4,640-grain full-width supported dense bed makes 0 moves over 80 material steps and sleeps normally.
- Final quiet frames reject a non-endpoint receipt and accept the true endpoint receipt before spawning. No presentation code was changed.
- Stale queued-generation replacement is skipped correctly; the newly admitted replacement does not inherit same-step visitation and moves normally next step.
- All 20 other top-level runtime files match frozen r13 byte-for-byte. No old-trajectory oracle, old swept-clearance gate, full regression suite, raster matrix or browser timing is claimed passed in this small experiment.

## One real-game recording comparison

Use fresh baseline and B pages, seed 1, QA OFF, identical viewport and DPR. Start recording before first contact; let the first piece fall naturally. Wait for the next falling phase before each subsequent input: drop 2 Right, Rotate, Space; drop 3 Left three times, Space; drop 4 Right twice, Rotate, Space; drop 5 Left, Space; drop 6 Right three times, Rotate, Space. Verify actual input ACKs. Record through the sixth complete rest and next falling piece. Retain uninterrupted normal-speed originals; contact-aligned excerpts may supplement them.

Decisive questions: does the material genuinely scatter and flow rather than collapse like a block; are short contact events still readable; are fine edges and color layers stable; does corner clipping appear as unacceptable tunnelling, breakup or shimmer; are there any boundary, long-tail, pause/ACK or frame-debt problems? Do not approve merely because lateral counts are much higher or the episode is shorter.

## Minimal handoff layout and commands

Under a fresh QA root, bind baseline/ to the existing unchanged full r13 and copy full r13 into candidate/. Extract B-delta.tgz inside candidate/. Extract B-validation-evidence.tgz at the QA root; create evidence/ if needed. The scripts use only ../baseline and ../candidate relative paths.

Optional numerical reproduction: node diagnostic/slide-b.mjs; node diagnostic/generation-check.mjs. Current browser work should prioritize the single decisive recording comparison rather than expanding numerical tests.

No browser was launched, no upload or deployment was performed, and product version remains 0.4.10.
