# GRAINFORM 0.4.10 boundary-contour candidate

Unpublished, independent candidate over the complete delivered 0.4.9 runtime. Do not overwrite 0.4.9 or publish this candidate before browser review.

## What changes

- Reconstructs only the material silhouette using marching squares over the currently displayed particle centers. Fractional positions contribute bilinearly. Shared vertices are canonical, and the two diagonal-only cases remain disconnected.
- Locally rounds the outer contour (two neighboring segments; coordinate relaxation capped at 0.25 material cell). Interior microcircles, per-ID offset/size/tint and cached stable texture are unchanged. A 0.7-cell stroke, clipped to the inside, fills only the narrow silhouette band beneath the original grain texture. Colors are selected from the local occupied side, with deterministic palette order.
- Single grains and one-cell streams retain their original glyphs. Hole boundaries are retained without smoothing. Clear highlights use the same contour. Context state is restored even if drawing fails.
- Updates scalar occupancy and neighboring dual cells only for changed/display-moving IDs. Idle draws reuse contour results. Stable material still uses the verified dirty-tile cache; there is no full-bed per-frame paint or image blur.

## Unchanged

Physics, 1px material cell size, four rule steps per 60Hz material frame, all recorded unit trajectories, collision rules, stable-slot reuse, worker protocol, final-pose rAF ACK, pause, and clear gates are unchanged. Version strings alone change in app.mjs/game.mjs. Visual pixels intentionally differ from 0.4.9 only around material boundaries; compare candidate incremental rendering against the new full-rebuild reference, not against the old appearance.

## Tests

- npm test: original 36 plus six contour/topology/invalidation tests.
- npm run verify:pixels: 180 exact RGBA cached-vs-full-rebuild draws, including fractional dimensions, clipping, palette, highlights, deletion/refill, tile boundaries and fallback.
- npm run verify:edge-sequence: real two-block CA sequence at DPR1/1.5/2 and alpha0/.5/1, exact incremental-vs-full-rebuild screen pixels.
- npm run verify:slots and npm run verify:parity: existing bounded identity and exact physics/trajectory regression.
- npm run verify:pixels:browser and npm run verify:browser: pending independent Chromium verification. Local Chromium was not launched due to the already-confirmed environment restriction.

Node raster checks are correctness evidence, not real browser/UI frame-rate measurements. Required external review: first landing and landing on an existing slope at DPR1/1.5/2; 13,824 and 40,000–53,000 material live scenes; QA OFF/ON timing; pause/resume/restart, two pending frames, natural clears, isolated grains/one-cell streams and multi-color boundaries. Do not claim completion until those checks pass.

The ten runtime files are listed with hashes in RUNTIME-MANIFEST.json. The frozen delta overlays the delivered 0.4.9 directory at unchanged relative paths; tests/evidence are not runtime uploads.
