# GRAINFORM 0.4.10 r7 — bounded adjacent complete-slip experiment

Unpublished experimental candidate over frozen r6. The only runtime change is ca-world direction reach:1 adjacent column instead of ID-dependent1/2 columns. It combines r6 complete in-place diagonal commits and per-material-substep arc-length presentation with immediate-neighbor descent. This is not r5's synchronized horizontal-leg model. All r6 worker/app/queue/renderer/contour/UI/timing and nine other runtime files remain byte-identical. No smaller glyphs, smoothing change or clock compensation.

## Why this experiment

Actual same-token61/alpha1 evidence established that micro and integrated r6 were identical, including23448 material pixels with zeroRGB difference; there was no demonstrated integration bug. Earlier micro visual acceptance covered favorable narrow phases and mislabelled nominal screenshot times. r6 had real2–3cell attached thin tongues at endpoints, not merely enlarged glyph/rim. This revision tests only the combination previously missing, not another sampling adjustment.

Offline same-seed complete first/second replay includes all endpoints,137half-phase scans for first-drop entirety and second-drop first40frames, plus all later endpoints.20499 old/new scene poses were ranked diagnostically; actual worst textured pictures were viewed at324CSS from648backing.118-frame all-endpoint and varying-phase videos retain all first/second frames. Early particle-sized steps remain. Old failure-time long attached rows visibly shrink in this offline evidence, but actual game visual acceptance is pending. Counts/geometry indicators alone do not establish product acceptance.

## Explicit style and timing costs

Same-seed shifted/rotated second drop r6→r7: width165→136(−17.6%),height63→67, overall width/height angle proxy37.37°→44.58°. This is not a fitted angle of repose. First/second settling36/84→35/84ticks. Shorter lateral flow means a steeper, more compact pile; user/product style acceptance remains open.

Alternating offset six-drop sequence: final131→146ticks(+11.45%), exceeding the former110% settling goal. Both13824born/2304cleared/11520live. Dense23drop sequence: both52992live, no top-out/count failure; last-five303→326ticks(+7.59%). Local no-render high step p9523.59→27.40ms in separate runs is not controlled performance certification and is not hidden. No claim of overall no-regression, stable60Hz, or passing CPU limits.

## Local checks and known boundaries

76Node tests including inherited real-worker/final-barrier/negative-time regression;320slot cycles;340same-pose exact incremental/full-reference RGBA. Independent motion oracle is tightened to maxone-column descent:115253 first/second move events,40660diagonals,zero two-column commits. Supported shoulders must stay blocked; removing adjacent corner support must permit real descent. Following-column throughput remains100%r4. ID/colors/logical cells conserved. This intentionally changes old trajectories; old551 equality is not claimed and references are retained.

Run npm test, verify:slots, verify:motion, verify:pixels:browser, verify:browser. verify:parity remains the explicitly labelled new-oracle compatibility alias. merge-test now checks blocked two-column shoulder plus positive adjacent descent for reused generations; identity/hash stability is still checked, not merely new expected coordinates.

Sand/sand brief subpixel coverage remains the declared2D material approximation. Convex external walls are strict; no internal obstacle feature is added. r6's bounded Float64 time buffer cost~44.9MiB persists; not a leakage claim. Full reset/GC retention and actual app debt still require browser QA.

## Required independent browser procedure

FIRST record unmodified whole first/second/sixth flow without screenshots or heavy per-draw logs during playback. Decode all frames afterward at exact324CSS/648backing correspondence, including every observed endpoint and multiple initial rAF phase offsets. Do not promote nominal screenshot labels into actual phase evidence. If a severe recurring tooth row remains, reject rather than hide it with favorable alpha.

Only after visual review, record true input ACKs/poses, final endpoint painted beforeclear, active-only draw rate/gaps, absolute16.67ms budget and peak/lastSETTLING debt atDPR1/1.5/2 including high density. Keep recording/probes/GC separate from timing. Report memory reset retention and style/settling costs honestly. No publication until actual acceptance and product tradeoff decision.
