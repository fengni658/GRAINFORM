# Integrated r6 local freeze report

Based on frozen r4, not r5. Runtime changes are limited to ca-world.mjs (complete in-place downhill commits), ca-frame-world.mjs (within-substep distance timing), ca-adapter.mjs (explicit path mode and omit wholly stationary paths), ca-layer.mjs (mode-aware sampling/validation), game.mjs (accurate interpolation diagnostic label). No app/worker/timeline/cache/contour/UI change.

The isolated predecessor passed bounded real DPR1/1.5/2 visual replay, with all costs/exceptions retained in grain0410-async-external. That does not certify this integrated game. Real app/worker visual, activity debt and high-density DPR2 acceptance remain pending; do not publish.

## Local final checks

76 Node tests: original68 plus5 path/negative-time/decoder tests and3 real worker-thread tests. Worker tests use native timers and actual worker module transport: fractional paths validate, pending bounded2, consume-only versus endpoint receipts distinguished, pause/resume/fullsync/restart epoch isolated. A full real-worker natural first drop transported35frames, consumed34 without endpoint proof, and required terminal token35 alpha1 before respawn;2304 IDs/grid cells conserved. QA gap clear rejects final false/null receipts and retains12-tick flash. Recording canvas checks ordering, not browser pixels/timing.

320 slot/reuse cycles unchanged and passed. New short oracle validates123843 input-Map move events including41360 diagonals; max8vertical/3slip perrule, corridors/destinations/IDs/colors/count, one/two-cell target contention, outer container and substep sampler. Continuous following advances24576 cells,100% r4. Internal solids are not a current game feature and no arbitrary internal-wall support is claimed. Old551 trajectory equality intentionally inapplicable. The initially adapted oracle omitted the explicit new path mode in its handcrafted samples; its failure log is retained, then corrected to declare the mode, without changing physical expected results.

340 exact incremental/full-reference RGBA comparisons passed, including88 newly added draws for explicit complete-slip mode, fractional substeps, opposing colors, dirty tile crossings and settled transition at all3DPR sizes. These are same-pose raster comparisons, not old/new physical pixel equality. Legacy rendering reference remains independent; historical golden trajectories untouched.

## Bounded same-input progression

First/second shifted-rotated sample:35/83→36/84 ticks, widths121/164→122/165, second height63 unchanged (predecessor model and integrated short oracle agree).

Six alternating ±24 offset drops: r4 ticks35,41,77,77,127,127; r6 34,41,80,78,131,131. Both13824born,2304cleared,11520live. Sixth final time+3.15%.

23-drop high-density same command sequence: both52992born/live,0cleared,0count failures, no top-out. Last5 ticks old14,155,38,68,27 (302total), new13,157,37,68,28 (303total). Local no-render high step p95 old26.42/new23.59ms; this is not browser FPS or stable comparative certification. Existing isolated CPU failed rounds1.235local and1.291/1.237browser remain relevant and not hidden.

## Memory and early-time boundary

Float64 fractional framePhase replaces Uint8, increasing fixed maximum World allocation47063520bytes≈44.9MiB. This is an explicit bounded capacity increase, not itself evidence of a leak. Real reset/GC must check repeated World retention; no long native-leak claim.

The microplayer's render(negative progress) deterministically indexes frames[-1]; the actual captured timestamp origin remains unproven. None of its player/index logic enters r6. Product queue has alpha clamp at0 before startedAt; new regression checks a callback.001ms earlier than origin and no premature ACK, plus negative/nonfinite direct sampler inputs. Pause/late/restart tested via unchanged queue and real worker.

## External QA focus

Apply exact delta to independent complete r4. Run npm test, verify:slots, verify:motion, verify:pixels:browser, verify:browser. verify:parity is an explicit new-oracle alias, not old551 parity. No historical unrelated evidence files are required by the revision manifest.

Capture real acknowledged first/shifted-rotated second/sixth/high-density gameplay at DPR1/1.5/2; recurring attached2–3CSSpx teeth should stay absent without broad color covering or fine-stream failure. Verify real final alpha1 painting before clear, no old/new epoch mixing, fullsync/resume/late frames, raw logical conservation. Separate actual SETTLING activity from input/falling gaps; report draws/s, draw-start gaps, update/draw rAF p95/p99/max, debt peak and lastSETTLING debt plus later recovery separately. Budget is real absolute60Hz workload, not averaged/precomputed replay. Check World/reset retention and bounded caches without conflating intentional larger arrays with leaks.
