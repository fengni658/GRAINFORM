# Contact-flow prototype for independent continuous-video review

Status: frozen local prototype, not visually accepted and not published. Product version remains 0.4.10. No browser or user computer was used, and nothing was uploaded or deployed. The current source is derived only from frozen r13, not the rejected r14 color-cache work.

## Diagnosis

The old rules always increase y by one. They contain no supported horizontal roll, persistent contact direction or dynamic/static surface distinction. A grain on a 26.6° two-run/one-rise terrace remains still even with all chunks forced awake; a grain at floor 419 never moves sideways. In seed 1's natural first block, only 462/2304 grains ever move laterally. Forcing the settled full pile awake changes none of these facts. The r13 contour optimization did not change these motion rules, and the arc decoder already spread movement over real substep time.

## Scope of the final mechanism

- Keep the existing 232×420 grid, four actual 1/240 steps per 60 Hz output, g=900, cap 720, analytic current-time movement quota, ordered wake-front, generation identities, renderer/contour, frame arc allocation, and final-alpha 1 receipt barrier.
- Add exact one-cell supported horizontal rolls. Destination and its upper-side opening must be empty; current and destination are supported. A shallow-roll corridor requires both further same-height and further-below cells to be empty. This prevents a fresh horizontal vacancy being treated as an invitation to shear a loaded interior row.
- A fresh admission or actual free-fall interval can create a bounded contact run. Mere waking cannot. Extra shallow-slope rolls require this dynamic qualification; original vertical/diagonal gravity remains legal without it. Recent continuous descending motion can sustain the same run, but blocking ends it. Flat runout spends finite energy and cannot reverse back and forth.
- Fixed prototype constants: new horizontal cadence 2 material ticks; maximum flat runout 6 cells; local qualification lifetime 48 ticks. These were not parameter-swept. Every horizontal action consumes one unit of the existing current quota and ends that particle's substep; original downward/diagonal moves retain their prior quota. No extra budget, stored sleep credit, 2-column horizontal jump, or fake slowed playback.
- Zero-quota contact also dissipates blocked admission evidence. Without that correction, a low-speed buried particle could sleep before its first integer allowance and retain a false future impact. The dedicated regression reproduces this boundary and now passes.
- ca-layer's sole runtime change is accepting exactly |dx|=1,dy=0 in substep-arc validation. Its painting and interpolation are unchanged. The world move guard is tightened to actual adjacent moves.
- simulation-worker's sole runtime change is initialVy: 0 for artificial QA support fixtures. Ordinary spawn/admission defaults are unchanged. The floor still prepares in one output, with the same early-clear barrier and 12-tick flash; there is no hidden extra pre-settling.

## Results, same seed and fixed six-block input sequence

Baseline r13 first through sixth settling output frames: 43, 69, 28, 81, 35, 89.
Final prototype: 44, 67, 30, 80, 34, 86.

First / second / sixth:
- Unique grains with lateral movement: 462→471 /1213→1362 /1236→1625.
- New actual horizontal actions: 537 /3590 /4759.
- Width×height: 107×41→112×41 /136×67→143×67 /232×97→232×96.
- Particle visits: 160392→164210 /582545→615363 /685240→690196, approximately +2.4% /+5.6% /+0.7%.

All six episodes conserve mass and each identity's color, settle without forced stopping, and then remain unchanged for 20 additional output frames. There are no clear groups in this specific six-block sequence. Separate connected/cascade tests exercise actual removal and scoring.

These are motion and work-count observations, not browser timing or proof of better hand feel. The first block's unique lateral-grain gain is small. Continuous review must determine whether the contact/scatter change is noticeable enough. Added contact predicates may cost CPU despite similar particle visits; browser performance is still unmeasured.

Artificial video fixtures, same initial bed and admission in both versions:
- 144-grain narrow column on a 45° slope: 25 output frames in both; 0 old-bed moves; candidate 157 horizontal actions.
- 16-grain local patch on a 26.6° terrace: 4→10 output frames; 0 old-bed moves; candidate 18 horizontal actions. No global pile relaxation.

## Actual verification

- Final npm test: 77/77 pass, including the real native Node worker's complete natural episode, queue credit, pause/resync/restart, final-draw ACK, connected clearing, cascade scoring, renderer/UI clocks and timeline tests.
- New invariant script: 11 fixtures pass. Includes shallow turn, finite flat runout, no stale sleep impulse, buried under-load lateral rejection, same-new-rule full-awake support-removal parity, generation reset, walls, horizontal/diagonal arc legality, full-awake stable pile, zero-quota admission evidence, and a 2488-grain true connected clear held until final alpha 1 then the unchanged 12-tick flash.
- Six-drop independent occupied-map audit: 529172 candidate actions; legality, vacancy/corridor/support, analytic current-Q budget, one horizontal end-of-substep action, bounds, per-ID color and mass conservation. 1131564 sampled path positions are checked. Raw logs and per-output observations are included.
- Slot suite: all 7 checks pass, including 320 reuse cycles, atomic failure, generation safety and fixed capacity. The six new fixed contact arrays add 1,948,800 bytes (about 1.86 MiB); no capacity increase.
- Free-fall 720 quota oracle passes unchanged, including long-age exact quotas.
- Same-pose raster regression: 340 existing fixture comparisons pass with the final renderer/validator code (run while the second physics mechanism was being evaluated; these are renderer fixtures, not a final-trajectory claim). An additional 162 comparisons use actual final-physics first and offset/rotated second trajectories at backing scales 1/1.5/2 and alpha.125/.5/1 against the independent full-scene/full-repaint renderer. 864 sampled path occurrences include a horizontal leg. Exact RGBA, no tolerance. Node raster only, not browser.
- A separate read-only reviewer found no must-fix correctness issue and independently stressed ordered versus forced-full-awake scheduling over 24 seeds, 7200 ticks and 45204 moves with irregular beds, repeated support removal and varying admission speeds. Exact actions, positions and RNG state match. The saved script/result is included.

## Rejected attempts and test failures retained

The first draft exposed a same-layer vacancy conveyor. Its source and logs remain in evidence; upper-side exposure was added to satisfy the approved surface-only scope. After that correctness fix, the first parameter set still limited all contact descent to 120 cells/s and produced 225/530/819 frames for blocks 1/2/6. It was rejected, not accepted by expanding a timeout.

Restoring original descending quotas while leaving every shallow surface free to roll produced 122/253/411 frames. It was rejected because waking a static surface could still lower the resting slope of the whole pile. The final dynamic/static distinction removed that behavior; no constants were swept.

The original 76-test run initially had 8 failures: 2 natural-duration bounds exposed the erroneous global contact slowdown; 5 failures came from stationary artificial beds inheriting 480 birth speed; 1 test rejected the newly intentional one-cell horizontal path. The implementation slowdown was fixed. Static fixture construction is now explicit zero-speed, retaining one-output preparation. The old invalid-horizontal case now rejects 2-cell horizontal movement, and a new positive one-cell acceptance test raises the suite to 77. Old failed logs are retained; no conservation, occupied-cell, ACK, clear-timing or scoring assertion was relaxed.

Historical exact-trajectory oracles against the old transport rule are intentionally not applicable. They must not be labeled passed against a different physics model. Old inherited README/revision reports/manifests inside baseline/candidate are historical source context; CONTACT-FLOW-MANIFEST.json and this report describe this prototype.

## Independent QA and stopping condition

QA-RECORDING-SPEC.md supplies four normal-speed continuous old/new recordings: natural first-piece contact, artificial narrow column on slope, real consecutive multi-color blocks, and artificial shallow-slope local disturbance. It includes exact input/coordinate definitions and expected visible questions. diagnostic/flow-fixtures.mjs constructs the artificial scenes using each real CAWorld and exactly one static-bed preparation output.

Do not ship based on action counts or still images. If the continuous flow remains too subtle, appears choreographed, harms fine edges, creates under-load motion or long tails, report that and stop; no automatic further rule layering, speed tuning or publication is authorized by this package.
