// Independently written gameplay CA, based on mechanisms described in the source review.
// Cells are material units, not hard circles. No third-party source copied.
export const CFG={width:232,height:420,cell:1,dt:1/240,gravity:900,maxVertical:8,maxSlide:3,maxSpeed:720,chunk:16,massPerCell:676/2304,phases:17,contactPeriod:2,contactRunout:6,contactLifetime:48};
export class World{
 constructor(){const C=CFG.width*CFG.height;this.grid=new Int32Array(C);this.x=new Int16Array(C);this.y=new Int16Array(C);this.color=new Uint8Array(C);this.batch=new Uint16Array(C);this.live=new Uint8Array(C);this.vy=new Float64Array(C);this.credit=new Float64Array(C);this.n=0;this.count=0;this.identity=new Float64Array(C);this.freeSlots=new Int32Array(C);this.freeCount=0;this.tick=0;this.time=0;this.seed=0x842199;this.cols=Math.ceil(CFG.width/CFG.chunk);this.rows=Math.ceil(CFG.height/CFG.chunk);this.chunks=new Set();this.quiet=new Uint8Array(this.cols*this.rows);this.changed=new Uint8Array(this.quiet.length);this.potential=new Uint8Array(this.quiet.length);this.noMoveSweeps=0;this.pendingInbound=0;this.lastMoveTick=-1;this.presentedTick=-1;this.dirty=null;this.lastMoved=new Uint32Array(C);this.moveStamp=new Uint32Array(C);this.pathN=new Uint8Array(C);this.pathX=new Int16Array(C*18);this.pathY=new Int16Array(C*18);this.pathPhase=new Uint8Array(C*18);this.pathStamp=new Uint32Array(C);this.reserved=new Int32Array(C);this.reserveStamp=new Uint32Array(C);this.reserveEpoch=0;this.metrics={stepCalls:0,chunkVisits:0,cellVisits:0,particleVisits:0,pathMoves:0,directionChecks:0,verticalMoves:0,slideMoves:0};this.last={moves:0,movedParticles:0,particles:0,chunks:0,pending:0};this.audit=null;this.birthTick=new Float64Array(C);this.birthSpeed=new Float64Array(C);this.frontInitialId=new Float64Array(C);this.frontInitialKey=new Int32Array(C);this.frontHeapId=new Float64Array(C);this.frontHeapKey=new Int32Array(C);this.frontQueued=new Uint32Array(C);this.frontVisited=new Uint32Array(C);this.frontChunkStamp=new Uint32Array(this.quiet.length);this.frontEpoch=0;this.frontHeapN=0;this.frontActive=false;this.contactDir=new Int8Array(C);this.contactEnergy=new Uint8Array(C);this.contactUntil=new Float64Array(C);this.contactNext=new Float64Array(C);this.fallDistance=new Uint8Array(C);this.impactReady=new Uint8Array(C);this.metrics.contactMoves=0;this.metrics.rollMoves=0;this.metrics.contactChecks=0;}
 rand(){let s=this.seed;s^=s<<13;s^=s>>>17;s^=s<<5;this.seed=s>>>0;return this.seed/4294967296}
 cell(x,y){return y*CFG.width+x}chunk(x,y){return Math.floor(y/CFG.chunk)*this.cols+Math.floor(x/CFG.chunk)}
 wake(x,y){
  // Preserve permissive direct-call behavior outside normal integer grid coordinates.
  if(!Number.isInteger(x)||!Number.isInteger(y)){for(let yy=Math.max(0,y-2);yy<=Math.min(CFG.height-1,y+2);yy++)for(let xx=Math.max(0,x-2);xx<=Math.min(CFG.width-1,x+2);xx++){const c=this.chunk(xx,yy);this.chunks.add(c);this.quiet[c]=0;this.changed[c]=1;if(this.frontActive)this.frontScanChunk(c)}return;}
  if(x+2<0||x-2>=CFG.width||y+2<0||y-2>=CFG.height)return;
  // Same first-insertion order as row-major cells, once per affected chunk.
  const x0=Math.floor(Math.max(0,x-2)/CFG.chunk),x1=Math.floor(Math.min(CFG.width-1,x+2)/CFG.chunk),y0=Math.floor(Math.max(0,y-2)/CFG.chunk),y1=Math.floor(Math.min(CFG.height-1,y+2)/CFG.chunk);
  for(let cy=y0;cy<=y1;cy++)for(let cx=x0;cx<=x1;cx++){const c=cy*this.cols+cx;this.chunks.add(c);this.quiet[c]=0;this.changed[c]=1;if(this.frontActive)this.frontScanChunk(c)}
 }

 markDirty(x,y){if(!this.dirty)this.dirty={x0:x,y0:y,x1:x,y1:y};else{this.dirty.x0=Math.min(this.dirty.x0,x);this.dirty.y0=Math.min(this.dirty.y0,y);this.dirty.x1=Math.max(this.dirty.x1,x);this.dirty.y1=Math.max(this.dirty.y1,y)}}
 // Storage is slot-indexed; public IDs are generation * capacity + slot.
 // No identity maps or allocation growth are needed in the material hot path.
 has(id){if(!Number.isSafeInteger(id)||id<0)return false;const i=id%this.live.length;return !!this.live[i]&&this.identity[i]===id}
 slotOf(id){if(!this.has(id))throw Error('missing-ID');return id%this.live.length}
 idAt(i){if(!Number.isInteger(i)||i<0||i>=this.n||!this.live[i])throw Error('missing-slot');return this.identity[i]}
 _resetSlot(i){this.contactDir[i]=0;this.contactEnergy[i]=0;this.contactUntil[i]=0;this.contactNext[i]=0;this.fallDistance[i]=0;this.impactReady[i]=1;this.frontQueued[i]=0;this.frontVisited[i]=0;this.vy[i]=0;this.credit[i]=0;this.lastMoved[i]=this.tick;this.moveStamp[i]=(this.tick-1)>>>0;this.pathN[i]=0;this.pathStamp[i]=(this.tick-1)>>>0;const p=i*18;this.pathX.fill(0,p,p+18);this.pathY.fill(0,p,p+18);this.pathPhase.fill(0,p,p+18)}
 admit(points,color,batch,initialVy=0){
  if(!Array.isArray(points))throw Error('admission-points');
  if(!Number.isFinite(color)||!Number.isFinite(batch)||!Number.isFinite(initialVy))throw Error('admission-fields');
  const staged=[],seen=new Set();for(const p of points){const {x,y}=p;if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||x>=CFG.width||y<0||y>=CFG.height)throw Error('admission-bounds');const q=this.cell(x,y);if(this.grid[q]||seen.has(q))throw Error('non-atomic-admission');seen.add(q);staged.push({x,y})}
  const C=this.live.length;if(this.count+staged.length>C)throw Error('capacity');
  // Check every future handle before touching slots, grid, counts or wake state.
  for(let k=0;k<Math.min(staged.length,this.freeCount);k++)if(!Number.isSafeInteger(this.identity[this.freeSlots[this.freeCount-1-k]]+C))throw Error('identity-exhausted');
  for(const p of staged){const reused=this.freeCount>0,i=reused?this.freeSlots[--this.freeCount]:this.n++;this.identity[i]=reused?this.identity[i]+C:i;this._resetSlot(i);this.live[i]=1;this.x[i]=p.x;this.y[i]=p.y;this.color[i]=color;this.batch[i]=batch;this.vy[i]=initialVy;this.birthSpeed[i]=initialVy;this.impactReady[i]=initialVy>0?1:0;this.birthTick[i]=this.tick;this.grid[this.cell(p.x,p.y)]=i+1;this.count++;this.wake(p.x,p.y);this.markDirty(p.x,p.y)}this.noMoveSweeps=0;return staged.length
 }
 remove(ids){const slots=[],seen=new Set();for(const id of ids){const i=this.slotOf(id);if(seen.has(i))throw Error('duplicate-ID');seen.add(i);slots.push(i)}for(const i of slots){const x=this.x[i],y=this.y[i];this.grid[this.cell(x,y)]=0;this.live[i]=0;this.freeSlots[this.freeCount++]=i;this.count--;this.wake(x,y);this.markDirty(x,y)}this.noMoveSweeps=0}
 empty(x,y){return x>=0&&x<CFG.width&&y>=0&&y<CFG.height&&!this.grid[this.cell(x,y)]}
 record(i,phase){let n=this.pathN[i];if(n>=18)throw Error('path-capacity');const p=i*18+n;this.pathX[p]=this.x[i];this.pathY[p]=this.y[i];this.pathPhase[p]=phase;this.pathN[i]=n+1}
 move(i,x,y,phase){const ox=this.x[i],oy=this.y[i];if(!this.empty(x,y)||!((x===ox&&y===oy+1)||(Math.abs(x-ox)===1&&(y===oy+1||y===oy))))throw Error('invalid-local-path');this.grid[this.cell(ox,oy)]=0;this.grid[this.cell(x,y)]=i+1;this.x[i]=x;this.y[i]=y;this.record(i,phase);this.wake(ox,oy);this.wake(x,y);this.markDirty(ox,oy);this.markDirty(x,y);this.metrics.pathMoves++;this.last.moves++;this.lastMoved[i]=this.tick;if(this.moveStamp[i]!==this.tick){this.moveStamp[i]=this.tick;this.last.movedParticles++;}if(this.audit)this.audit(this.identity[i],ox,oy,x,y,phase)}
 roughness(i){let h=(i+1)>>>0;h=Math.imul(h^(h>>>16),0x7feb352d);h=Math.imul(h^(h>>>15),0x846ca68b);return 1+((h^(h>>>16))&1)}
 direction(i,dx,reservations=true){this.metrics.directionChecks++;const x=this.x[i],y=this.y[i],limit=1;for(let dist=1;dist<=limit;dist++){const xx=x+dx*dist;if(!this.empty(xx,y))return null;const a=this.cell(xx,y);if(reservations&&this.reserveStamp[a]===this.reserveEpoch)return null;if(!this.empty(xx,y+1))continue;const b=this.cell(xx,y+1);if(reservations&&this.reserveStamp[b]===this.reserveEpoch)continue;let depth=0;while(depth<8&&this.empty(xx,y+1+depth))depth++;return{dx,dist,depth}}return null}


 // A contact run is finite. Only admission or a real free-fall interval can seed
 // flat runout; diagonal descent never recharges it and sleep cannot accrue it.
 contactAvailable(i){return (this.impactReady[i]||this.fallDistance[i]>=2)?Math.min(CFG.contactRunout,2+Math.floor(Math.max(this.fallDistance[i],this.impactReady[i]?this.birthSpeed[i]/120:0)/3)):(this.tick<=this.contactUntil[i]?this.contactEnergy[i]:0)}
 prepareContact(i){
  if(this.impactReady[i]||this.fallDistance[i]>=2){this.contactEnergy[i]=this.contactAvailable(i);this.contactUntil[i]=this.tick+CFG.contactLifetime;this.contactDir[i]=0;this.contactNext[i]=this.tick;}
  else if(this.tick>this.contactUntil[i])this.contactEnergy[i]=0;
  this.impactReady[i]=0;this.fallDistance[i]=0;
 }
 contactOptions(i,energy=this.contactAvailable(i)){
  this.metrics.contactChecks++;const x=this.x[i],y=this.y[i];
  // The vacancy beside a supported grain defines a local exposed interface.
  // Fully packed material has no lateral option, independent of energy or age.
  const side=dx=>{if(!this.empty(x+dx,y))return null;
   if(this.empty(x+dx,y+1)){const d=this.direction(i,dx,false);return d?{dx,dy:1,rank:3,depth:d.depth}:null;}
   // A supported roll is restricted to the open surface. A vacancy travelling
   // under a loaded row must not turn the whole row into a lateral conveyor.
   if(!this.empty(x+dx,y-1))return null;
   const downhill=this.empty(x+2*dx,y)&&this.empty(x+2*dx,y+1);
   if(downhill)return{dx,dy:0,rank:2,depth:1};
   if(energy>0)return{dx,dy:0,rank:1,depth:0};return null;};
  return[side(-1),side(1)];
 }
 chooseContact(i,options){
  const [l,r]=options,dir=this.contactDir[i],forward=dir<0?l:dir>0?r:null;
  if(forward)return forward;
  // A stopped finite flat run cannot reverse and creep back and forth.
  const a=l&&(!dir||l.rank>1)?l:null,b=r&&(!dir||r.rank>1)?r:null;
  if(!a)return b;if(!b)return a;if(a.rank!==b.rank)return a.rank>b.rank?a:b;
  if(a.depth!==b.depth)return a.depth>b.depth?a:b;return this.rand()<.5?a:b;
 }
 hasContactOption(i){const [l,r]=this.contactOptions(i),dir=this.contactDir[i];return !!((l&&(!dir||dir<0||l.rank>1))||(r&&(!dir||dir>0||r.rank>1)));}

 orderKey(i){return (CFG.height-1-this.y[i])*CFG.width+((this.tick&1)?this.x[i]:CFG.width-1-this.x[i])}
 frontPush(id,key){let n=this.frontHeapN++;if(n>=this.live.length)throw Error('front-capacity');while(n){const p=(n-1)>>1;if(this.frontHeapKey[p]<=key)break;this.frontHeapId[n]=this.frontHeapId[p];this.frontHeapKey[n]=this.frontHeapKey[p];n=p}this.frontHeapId[n]=id;this.frontHeapKey[n]=key;this.frontStats.peakHeap=Math.max(this.frontStats.peakHeap,this.frontHeapN)}
 frontPop(){const id=this.frontHeapId[0],n=--this.frontHeapN;if(n){const v=this.frontHeapId[n],key=this.frontHeapKey[n];let p=0;while(p*2+1<n){let c=p*2+1;if(c+1<n&&this.frontHeapKey[c+1]<this.frontHeapKey[c])c++;if(this.frontHeapKey[c]>=key)break;this.frontHeapId[p]=this.frontHeapId[c];this.frontHeapKey[p]=this.frontHeapKey[c];p=c}this.frontHeapId[p]=v;this.frontHeapKey[p]=key}return id}
 frontScanChunk(c){
  if(this.frontChunkStamp[c]===this.frontEpoch)return;
  this.frontChunkStamp[c]=this.frontEpoch;this.frontStats.newChunks++;
  const cx=c%this.cols,cy=Math.floor(c/this.cols);
  for(let y=cy*16;y<Math.min((cy+1)*16,CFG.height);y++)for(let x=cx*16;x<Math.min((cx+1)*16,CFG.width);x++){
   this.frontStats.newCells++;const v=this.grid[this.cell(x,y)];if(!v)continue;const i=v-1;
   if(this.frontQueued[i]===this.frontEpoch)continue;this.frontQueued[i]=this.frontEpoch;
   const id=this.identity[i],key=this.orderKey(i);this.frontTouched.push(id);
   if(key<=this.frontCursor){this.frontStats.passed++;continue}
   this.frontStats.woken++;this.frontPush(id,key);
  }
 }
 step(){
  this.metrics.stepCalls++;this.tick++;this.time+=CFG.dt;this.last={moves:0,movedParticles:0,particles:0,chunks:0,pending:0};this.dirty=null;this.frontStats={initial:0,initialCells:0,newChunks:0,newCells:0,woken:0,passed:0,visited:0,stale:0,peakHeap:0};if(!this.chunks.size)return;
  this.changed.fill(0);this.potential.fill(0);
  this.frontEpoch=(this.frontEpoch+1)>>>0;if(!this.frontEpoch){this.frontQueued.fill(0);this.frontVisited.fill(0);this.frontChunkStamp.fill(0);this.frontEpoch=1}
  this.frontHeapN=0;this.frontCursor=-1;this.frontTouched=[];
  const ids=[];
  for(const c of this.chunks){this.frontChunkStamp[c]=this.frontEpoch;this.metrics.chunkVisits++;this.last.chunks++;const cx=c%this.cols,cy=Math.floor(c/this.cols);
   for(let y=cy*16;y<Math.min((cy+1)*16,CFG.height);y++)for(let x=cx*16;x<Math.min((cx+1)*16,CFG.width);x++){this.metrics.cellVisits++;this.frontStats.initialCells++;const v=this.grid[this.cell(x,y)];if(v)ids.push(v-1)}
  }
  ids.sort((a,b)=>this.orderKey(a)-this.orderKey(b));
  for(let p=0;p<ids.length;p++){const i=ids[p],id=this.identity[i];this.frontInitialId[p]=id;this.frontInitialKey[p]=this.orderKey(i);this.frontQueued[i]=this.frontEpoch;this.frontTouched.push(id)}
  this.frontStats.initial=ids.length;let head=0;this.frontActive=true;
  try{
   while(head<ids.length||this.frontHeapN){
    let id,key;
    if(head<ids.length&&(!this.frontHeapN||this.frontInitialKey[head]<=this.frontHeapKey[0])){id=this.frontInitialId[head];key=this.frontInitialKey[head++]}
    else{key=this.frontHeapKey[0];id=this.frontPop()}
    this.frontCursor=key;if(!this.has(id)){this.frontStats.stale++;continue}const i=this.slotOf(id);
    if(this.frontVisited[i]===this.frontEpoch)throw Error('front-double-visit');this.frontVisited[i]=this.frontEpoch;this.frontStats.visited++;this.metrics.particleVisits++;
    const age=this.tick-this.birthTick[i],v0=this.birthSpeed[i];this.vy[i]=Math.min(CFG.maxSpeed,v0+CFG.gravity*age*CFG.dt);
    this.credit[i]=Math.min(8,this.transportQuota(v0,age));this.pathN[i]=0;this.pathStamp[i]=this.tick;this.record(i,0);
    let order=0;
    if(this.empty(this.x[i],this.y[i]+1)){
     // Keep the existing analytic free-fall clock. A newly encountered support
     // starts contact on the following substep, never a hidden extra hop.
     while(this.credit[i]>=1&&this.empty(this.x[i],this.y[i]+1)){
      this.move(i,this.x[i],this.y[i]+1,++order);this.credit[i]--;this.metrics.verticalMoves++;
      this.fallDistance[i]=Math.min(18,this.fallDistance[i]+1);
     }
    }else{
     this.prepareContact(i);
     if(this.hasContactOption(i)){
      if(this.tick>=this.contactNext[i]){const d=this.chooseContact(i,this.contactOptions(i));
       if(d){this.move(i,this.x[i]+d.dx,this.y[i]+d.dy,1);this.contactDir[i]=d.dx;this.contactEnergy[i]=Math.max(0,this.contactEnergy[i]-1);this.contactNext[i]=this.tick+CFG.contactPeriod;this.metrics.contactMoves++;if(d.dy)this.metrics.slideMoves++;else this.metrics.rollMoves++;}
      }
     }else{this.contactEnergy[i]=0;this.contactUntil[i]=0;this.contactDir[i]=0;}
    }this.credit[i]=0;
   }
  }finally{this.frontActive=false}
  this.last.particles=this.frontStats.visited;this.last.chunks+=this.frontStats.newChunks;this.metrics.chunkVisits+=this.frontStats.newChunks;this.metrics.cellVisits+=this.frontStats.newCells;
  // Also inspect passed-cursor wake entries: geometry may be legal although this step cannot revisit them.
  for(const id of this.frontTouched)if(this.has(id)){const i=this.slotOf(id),x=this.x[i],y=this.y[i];if(this.empty(x,y+1)||this.hasContactOption(i)){this.potential[this.chunk(x,y)]=1;this.chunks.add(this.chunk(x,y));this.last.pending++}}
  for(const c of [...this.chunks]){if(this.changed[c]||this.potential[c])this.quiet[c]=0;else if(++this.quiet[c]>=2)this.chunks.delete(c)}
  if(this.last.moves){this.noMoveSweeps=0;this.lastMoveTick=this.tick}else if(!this.last.pending)this.noMoveSweeps++;else this.noMoveSweeps=0;
 }

 // The configured caps (480/720 at 240 Hz) have exact integer saturated quotas.
 // Avoid subtracting large cumulative values once both endpoints are saturated.
 transportQuota(v0,age){if(age<=0)return 0;const cap=Math.max(0,(CFG.maxSpeed-v0)/CFG.gravity);if((age-1)*CFG.dt>=cap)return CFG.maxSpeed*CFG.dt;return Math.floor(this.transportQ(v0,age)+1e-9)-Math.floor(this.transportQ(v0,age-1)+1e-9)}
 transportQ(v0,age){const t=Math.max(0,age)*CFG.dt,cap=Math.max(0,(CFG.maxSpeed-v0)/CFG.gravity),a=Math.min(t,cap);return v0*a+.5*CFG.gravity*a*a+CFG.maxSpeed*Math.max(0,t-cap)}
 completePresentation(){this.presentedTick=this.tick}
 ready(){return !this.pendingInbound&&!this.chunks.size&&this.noMoveSweeps>=2&&this.presentedTick>=this.lastMoveTick}
 positionAt(id,alpha){const i=this.slotOf(id);if(!this.pathN[i]||this.pathStamp[i]!==this.tick)return[this.x[i]+.5,this.y[i]+.5];const phase=alpha*17,n=this.pathN[i],base=i*18;let x=this.pathX[base],y=this.pathY[base];for(let j=1;j<n;j++){const k=base+j,end=this.pathPhase[k];if(phase<end-1)return[x+.5,y+.5];if(phase<end){const u=phase-(end-1);return[x+(this.pathX[k]-x)*u+.5,y+(this.pathY[k]-y)*u+.5]}x=this.pathX[k];y=this.pathY[k]}return[x+.5,y+.5]}
 snapshot(){const out=[];for(let i=0;i<this.n;i++)if(this.live[i])out.push({id:this.identity[i],x:this.x[i],y:this.y[i],color:this.color[i],batch:this.batch[i]});return out}
}
