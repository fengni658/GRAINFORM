// Microfixture-only fixed-solid route check. Sand grains are not passed as obstacles.
// Unit grain logical footprint vs unit solid cell: center must stay outside open expanded unit AABB.
export function crossesFixed(a,b,solids){for(const s of solids){let low=0,high=1;for(let axis=0;axis<2;axis++){const v=b[axis]-a[axis],lo=s[axis]-1,hi=s[axis]+1;if(!v){if(a[axis]<=lo||a[axis]>=hi){low=2;break}}else{const t0=(lo-a[axis])/v,t1=(hi-a[axis])/v;low=Math.max(low,Math.min(t0,t1));high=Math.min(high,Math.max(t0,t1))}}if(low<high-1e-12&&high>0&&low<1)return true}return false}
export function routeAroundFixed(a,b,solids){if(!crossesFixed(a,b,solids))return[a,b];const corner=[b[0],a[1]];if(crossesFixed(a,corner,solids)||crossesFixed(corner,b,solids))return null;return[a,corner,b]}
