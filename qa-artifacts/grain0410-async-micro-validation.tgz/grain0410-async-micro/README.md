# Isolated async complete-slip visual microexperiment (not r6)

Frozen exploratory page, no product integration or release. r4/r5 remain unchanged. This bundle includes exact r4 modules in baseline/ and candidate-only model/ modules. Browser needs no dependencies: serve this folder over localhost (e.g. python3 -m http.server 8765) and open index.html.

## What changed

Only experimental motion: each fixed slip-round ID reads the current grid, checks the original one/two-column corridor and empty destination, and immediately commits its full diagonal descent. The next grain reads the new state. Original 1px grid, colors/IDs, active chunks, ID reach, eight vertical rounds and three slip rounds remain. No common visible horizontal intermediate stage.

Each original material-rule substep retains one quarter of the fixed output frame. Each grain's recorded actual vertical/diagonal polyline is interpolated by its cumulative Euclidean length within that substep; stationary substeps and all four boundaries remain. Numeric 0..68 frame coordinates are now fractional time markers, not shared unit-axis phases. No four-substep first-to-last shortcut. CFG.dt and accelerated physical credit values remain exactly r4; 1/240 second describes presentation allocation, not a newly modified physical dt.

Sand-to-sand brief subpixel overlap is an explicit 2D material approximation. Logical grid occupancy/IDs/colors must remain unique and conserved. This is not rigid-body accuracy. Existing rectangular container is convex: valid center endpoints imply no segment exits. fixed-obstacles.mjs is a separate microfixture adapter: if a direct line intersects an expanded fixed solid, only that grain gets a checked local L route. It is tested but NOT integrated into the candidate world, which currently has no internal rigid solids. Do not claim arbitrary rigid-obstacle app support.

The unchanged r4 renderer includes r3 cache batching and unchanged contour/texture. The product worker/queue/app are not present or altered. This viewer builds deterministic physics frames ahead of playback and renders them using real browser Canvas/rAF; therefore it does not certify end-to-end worker timing or product presentation ACKs.

## Controls and browser QA

Buttons play same-seed first drop and right-shifted/rotated second drop, or sweep all137 half-phase positions of second-drop frame26 (~.434s). Slider allows arbitrary phase. window.micro exposes runs, views, samples, play, render, select. Old and new retain their own physical evolution, not falsely identical poses.

Start with actual CSS-size continuous DPR1/1.5/2 playback. Look for repeated attached2–3CSSpx horizontal tooth rows, color-cover flicker, new visual thinning, and settling shape. Original-CSS offline contacts and videos are provided only as evidence; they are not browser capture. All137 frame26 source images and168 second-drop frames are locally preserved outside this compact bundle; replay scripts regenerate them from compare.mjs if desired.

If visual acceptance fails, stop before performance optimization. If promising, use warmed, alternating/interleaved same-scene old/new measurements, record sample counts and GC, and compare update and draw p95 separately. window.micro.samples contains per-side replay render ms and cache metrics; these are NOT app FPS or input/worker debt. Existing local g.step CPU four-pair new/old p95 ratios1.047,1.020,.918,1.235 include one failed threshold; no stable≤110% claim. All raw pair summaries retained.

## Bounded checks already completed

Run node async-legality.mjs and node fixed-obstacle-check.mjs. Node built-ins only. No old551 trajectory-equality claim.
- Seed1 first/second settle36/84 frames vs r4 35/83;2304/4608 conserved.
-123843 independent input-Map move events, including41360 diagonals, legal corridor/target, bounds, IDs/colors/count and max8vertical/3slip per rule.
- Touching-column throughput24576 cell advances,100% r4.
- One/two-cell competing-target fixtures have only one winner.
- Arc-length substep boundary and FrameWorld.positionAt agreement.
- Forced232-grain spanning-row clear requires final endpoint receipt, then12flash ticks and respawn. This is logic-level, not browser presented-pixel certification.
- Outer container corners; separate five fixed-solid route tests and707 sampled route points.

First/second widths r4 121/164 to candidate122/165; second height63 unchanged. No r5 compact steep-style cost in this sample. Local settling gate≤110% passes these two episodes only.

## Offline replay dependencies

Browser page and Node legality tests need no npm packages. Offline PNG scripts require @napi-rs/canvas. They default to the installed dot cloud dependency path; on another machine set CANVAS_REQUIRE_FROM to an absolute existing JS file in the directory containing node_modules. compare.mjs regenerates evidence/runs.json, sequence.mjs start end renders120fps second-drop frames; phases.mjs start end renders frame26 phases0..136. Separate processes of28 frames were used to bound Node native canvas allocations. This is not evidence of browser memory behavior.

## Inspiration, not a direct port

Sandspiel clears source and writes down/diagonal destination in its official update_sand source:
https://github.com/MaxBittker/sandspiel/blob/9936e06b07a583aedfba9589c0cead2917f405fb/crate/src/species.rs#L65-L90
Its cell clock and alternating horizontal sweep prevent repeated update:
https://github.com/MaxBittker/sandspiel/blob/9936e06b07a583aedfba9589c0cead2917f405fb/crate/src/lib.rs#L89-L102
https://github.com/MaxBittker/sandspiel/blob/9936e06b07a583aedfba9589c0cead2917f405fb/crate/src/lib.rs#L180-L224
This experiment preserves r4 bottom-up ID order and adds explicit per-substep path presentation; it is not identical to sandspiel's top-down grid renderer.
