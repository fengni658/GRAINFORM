// Small candidate-external audit. Sand is grid material, deliberately not a hard-circle oracle.
import { writeFileSync } from 'node:fs';
import { FrameWorld, CFG } from './model/ca-frame-world.mjs';
import { FrameWorld as R4 } from './baseline/ca-frame-world.mjs';
import { Game } from './model/game.mjs';
import { positionOnPath } from './sample-path.mjs';
const report = { scope: 'Four bounded scenes; frozen r4/r5 untouched; no app integration', model: { presentationRuleSeconds: 1 / 240, outputPhases: 68, materialRuleDt: CFG.dt, physicalClockNote: 'r4 accelerated rule values retained; 1/240 describes presentation only', sandSubpixelOverlap: 'Explicitly permitted 2D material approximation; no hard-circle checks', old551TrajectoryParity: 'Intentionally inapplicable' }, scenes: {}, failures: [] };
const near = (a,b) => Math.abs(a-b) < 1e-8;
function check(ok, message) { if (!ok) throw Error(message); }
function audit(w) {
  const byCell = new Map(), byId = new Map(), events = new Map();
  const stats = { events: 0, vertical: 0, diagonal: 0, twoCellDiagonal: 0, pathNodes: 0, samples: 0, frames: 0, maxVerticalPerRule: 0, maxSlipPerRule: 0, boundaries: 0 };
  const key = (x,y) => y*CFG.width+x;
  const admit = w.admit.bind(w);
  w.admit = (points,color,batch,vy=0) => {
    const old = new Set(byId.keys());
    for (const p of points) check(!byCell.has(key(p.x,p.y)), 'input admission overlap');
    const result = admit(points,color,batch,vy), added = w.snapshot().filter(p=>!old.has(p.id));
    check(added.length === points.length, 'admission count');
    for (const input of points) {
      const p = added.find(p=>p.x===input.x && p.y===input.y);
      check(p && p.color === color && p.batch === batch, 'input-driven admission identity/color/batch');
      check(!byId.has(p.id), 'duplicate public ID');
      byId.set(p.id,{...p}); byCell.set(key(p.x,p.y),p.id);
    }
    return result;
  };
  const remove = w.remove.bind(w);
  w.remove = ids => {
    for (const id of ids) check(byId.has(id), 'removal missing ID');
    const saved = ids.map(id=>({...byId.get(id)})), result = remove(ids);
    for (const p of saved) { byCell.delete(key(p.x,p.y)); byId.delete(p.id); }
    verify(); return result;
  };
  w.audit = (id,ox,oy,x,y,phase) => {
    const p = byId.get(id), dx=x-ox, dy=y-oy;
    check(p && p.x===ox && p.y===oy && byCell.get(key(ox,oy))===id, 'audit source/ID does not match input-derived map');
    check(Number.isInteger(x) && Number.isInteger(y) && x>=0 && x<CFG.width && y>=0 && y<CFG.height, 'event bounds');
    check(dy===1 && Math.abs(dx)<=2, 'non-vertical/non-diagonal event');
    check(!byCell.has(key(x,y)), 'destination occupied at commit');
    if (dx) {
      check(byCell.has(key(ox,oy+1)), 'slip lacks current support');
      for (let d=1;d<=Math.abs(dx);d++) check(!byCell.has(key(ox+Math.sign(dx)*d,oy)), 'same-height corridor blocked at commit');
    }
    const ekey = `${w.tick}:${id}`, list = events.get(ekey) || [];
    list.push({ox,oy,x,y,phase}); events.set(ekey,list);
    const vertical=list.filter(e=>e.x===e.ox).length, slip=list.length-vertical;
    check(vertical<=8 && slip<=3, 'per-rule 8-vertical/3-slip budget exceeded');
    stats.maxVerticalPerRule=Math.max(stats.maxVerticalPerRule,vertical); stats.maxSlipPerRule=Math.max(stats.maxSlipPerRule,slip);
    byCell.delete(key(ox,oy)); byCell.set(key(x,y),id); p.x=x; p.y=y;
    check(w.grid[key(x,y)]===w.slotOf(id)+1 && w.grid[key(ox,oy)]===0, 'committed grid disagrees with event');
    stats.events++; if(dx) {stats.diagonal++;if(Math.abs(dx)===2)stats.twoCellDiagonal++;} else stats.vertical++;
  };
  function verify(full=false) {
    check(w.count===byId.size && byCell.size===byId.size, 'count preservation');
    const actual=w.snapshot(); check(actual.length===byId.size, 'snapshot count');
    for(const p of actual) {
      const e=byId.get(p.id);
      check(e && ['x','y','color','batch'].every(k=>e[k]===p[k]), 'ID/color/batch/position preservation');
      check(w.grid[key(p.x,p.y)]===w.slotOf(p.id)+1 && byCell.get(key(p.x,p.y))===p.id, 'grid occupancy consistency');
    }
    if(full) {let n=0; for(let i=0;i<w.grid.length;i++)if(w.grid[i]) {n++;check(byCell.has(i), 'unexpected occupied grid cell');} check(n===w.count,'full-grid occupied count');}
  }
  function frame(startTick) {
    verify(); stats.frames++;
    for(const id of w.frameIds) {
      const slot=w.slotOf(id), base=slot*69, n=w.frameN[slot], points=[];
      for(let j=0;j<n;j++) points.push(w.frameX[base+j]+.5,w.frameY[base+j]+.5,w.framePhase[base+j]);
      const path={id,points};
      for(let j=3;j<points.length;j+=3) {
        const a=points.slice(j-3,j), b=points.slice(j,j+3);
        check(b[2]>a[2] && b[2]<=68+1e-8, 'path times not strictly increasing or out of frame');
        const dx=b[0]-a[0], dy=b[1]-a[1];
        check((dx===0&&dy===0)||(dy===1&&Math.abs(dx)<=2), 'path has invented/intermediate motion');
        stats.pathNodes++;
        for(const u of [0,.25,.5,.75,1]) {
          const t=a[2]+u*(b[2]-a[2]), actual=positionOnPath(path,t/68), expected=[a[0]+u*dx,a[1]+u*dy];
          check(actual.every((v,k)=>near(v,expected[k])), 'arc-length edge sampler');
          check(actual[0]>=.5-1e-8&&actual[0]<=CFG.width-.5+1e-8&&actual[1]>=.5-1e-8&&actual[1]<=CFG.height-.5+1e-8,'sample crosses convex container boundary');
          const api=w.positionAt(id,t/68); check(api.every((v,k)=>near(v,actual[k])), 'FrameWorld.positionAt differs from output path sampler');
          stats.samples++;
        }
      }
      for(let s=0;s<4;s++) {
        const list=events.get(`${startTick+s+1}:${id}`); if(!list?.length)continue;
        const length=list.reduce((v,e)=>v+Math.hypot(e.x-e.ox,e.y-e.oy),0); let distance=0;
        const start=positionOnPath(path,s/4); check(near(start[0],list[0].ox+.5)&&near(start[1],list[0].oy+.5),'rule substep start boundary drift');
        for(const e of list) {
          distance+=Math.hypot(e.x-e.ox,e.y-e.oy); const t=s*17+17*distance/length;
          let found=false;for(let j=0;j<points.length;j+=3)if(near(points[j+2],t)&&points[j]===e.x+.5&&points[j+1]===e.y+.5)found=true;
          check(found,'actual event missing or not allocated by arc length within rule substep');
        }
        const end=positionOnPath(path,(s+1)/4), e=list.at(-1); check(near(end[0],e.x+.5)&&near(end[1],e.y+.5),'rule substep endpoint boundary drift');stats.boundaries+=2;
      }
    }
    events.clear();
  }
  return {stats,verify,frame,byId};
}
function runScene(name,fn) {try {report.scenes[name]={status:'pass',...fn()};} catch(e) {report.scenes[name]={status:'fail',error:e.message};report.failures.push(`${name}: ${e.message}`);}}
function tickGame(g,a) {
  const start=g.world.tick; g.step();
  if(g.world.tick!==start)a.frame(start);
  let gated=0;
  if(g.awaitingPresentation) {
    const token=g.consumedToken+1;
    if(g.presentationBarriers.has(token)) {
      check(!g.world.ready() && g.phase==='settling','terminal endpoint did not gate settlement');
      check(!g.completePresentation(token,{endpointDrawn:false}),'final gate accepted missing endpoint'); gated++;
    }
    check(g.completePresentation(token,{endpointDrawn:true}),'presentation acknowledgment failed');
  }
  check(g.world.count+g.rawCleared===g.added,'Game conservation'); return gated;
}
runScene('1_seed1_two_drops_and_forced_clear',()=>{
  const g=new Game({seed:1}), a=audit(g.world), drops=[]; g.start();let endpointGates=0;
  for(let b=0;b<2;b++) {
    if(b){g.move(24);g.rotate();} check(g.drop(),'drop rejected');let frames=0;
    while(g.phase!=='falling' && frames<450){endpointGates+=tickGame(g,a);frames++;}
    check(g.phase==='falling','bounded drop failed to settle');a.verify(true);drops.push({drop:b+1,frames,count:g.world.count,rawCleared:g.rawCleared});
  }
  const clear=new Game({seed:1}), ca=audit(clear.world); clear.state='playing';clear.phase='settling';clear.active=null;clear.world.pendingInbound=0;
  const result=clear.world.addMany(Array.from({length:CFG.width},(_,x)=>({x:x+28,y:CFG.height-1,color:3})),{batch:9,initialVy:480});
  check(result.accepted,'forced spanning row admission'); clear.added=CFG.width;let ticks=0,clearGates=0;
  while(clear.phase!=='flash'&&ticks++<12)clearGates+=tickGame(clear,ca);
  check(clear.phase==='flash'&&clear.clearTicks===12&&clear.pendingClear.flat().length===CFG.width,'clear-start protocol');
  check(clear.presentedToken===clear.presentationToken&&clearGates>0,'clear scan preceded terminal presentation');
  for(let i=0;i<11;i++){tickGame(clear,ca);check(clear.world.count===CFG.width&&clear.phase==='flash','cleared before full flash');}
  tickGame(clear,ca);check(clear.world.count===0&&clear.rawCleared===CFG.width&&clear.phase==='settling','clear removal protocol');
  let after=0;while(clear.phase!=='falling'&&after++<12)clearGates+=tickGame(clear,ca);
  check(clear.phase==='falling'&&clear.world.count===0&&result.addedIds.every(id=>!clear.world.has(id)),'post-clear settlement/spawn');ca.verify(true);
  return {drops,endpointGates,gameAudit:a.stats,forcedClear:{description:'Explicit logical full floor row; not claimed as a naturally produced clear',removed:clear.rawCleared,flashTicks:12,endpointGates:clearGates,audit:ca.stats}};
});
runScene('2_touching_one_column_following',()=>{
  const input=Array.from({length:96},(_,i)=>({x:116,y:8+i})), w=new FrameWorld(),a=audit(w),base=new R4();
  w.admit(input,2,1,480);base.admit(input,2,1,480);const y0=input.reduce((v,p)=>v+p.y,0);
  for(let f=0;f<8;f++){const t=w.tick;w.stepFrame();a.frame(t);w.completePresentation();base.stepFrame();base.completePresentation();}
  const moved=w.snapshot().reduce((v,p)=>v+p.y,0)-y0,baseline=base.snapshot().reduce((v,p)=>v+p.y,0)-y0;
  const ys=w.snapshot().map(p=>p.y).sort((a,b)=>a-b);check(ys.every((y,i)=>!i||y===ys[i-1]+1),'touching column lost following');check(moved>=.9*baseline,'following throughput below 90% r4');check(a.stats.diagonal===0,'column fixture unexpectedly touched floor');a.verify(true);
  return {frames:8,particles:96,asyncCellAdvance:moved,r4CellAdvance:baseline,throughputRatio:moved/baseline,threshold:.9,audit:a.stats};
});
runScene('3_one_two_cell_gaps_opposing_targets',()=>{
  const cases=[];
  for(const distance of [1,2]) {
    const w=new FrameWorld(),a=audit(w);w.admit([{x:0,y:419}],4,0,0); // Make both source IDs have two-cell roughness.
    w.admit([{x:116-distance,y:418},{x:116+distance,y:418}],1,1,480);
    w.admit(Array.from({length:232},(_,x)=>({x,y:419})).filter(p=>p.x!==0&&p.x!==116),3,2,0);
    const t=w.tick;w.stepFrame();a.frame(t);w.completePresentation();a.verify(true);
    check(w.grid[w.cell(116,419)]!==0,'opposing target was not filled');check(a.stats.diagonal===1,'opposing target accepted more/less than one source');check(distance===1?a.stats.twoCellDiagonal===0:a.stats.twoCellDiagonal===1,'gap distance not exercised');
    cases.push({distance,target:[116,419],commits:a.stats.diagonal,count:w.count,audit:a.stats});
  }
  return {cases};
});
runScene('4_fixed_container_corners',()=>{
  const w=new FrameWorld(),a=audit(w);w.admit([{x:116,y:419}],4,0,0);w.admit([{x:0,y:418},{x:231,y:418}],1,1,480);w.admit([{x:0,y:419},{x:1,y:419},{x:230,y:419},{x:231,y:419}],3,2,0);
  const t=w.tick;w.stepFrame();a.frame(t);w.completePresentation();a.verify(true);check(a.stats.twoCellDiagonal===2,'left/right two-cell corner diagonals not exercised');
  return {convexContainer:[0,0,232,420],sampledCenterBounds:[.5,.5,231.5,419.5],audit:a.stats,internalRigidWalls:{status:'not_implemented_in_original_model',required:'Separate fixed-obstacle segment/corner legality and supported fallback must be checked before integration; sand occupancy is not a fixed-wall oracle'}};
});
report.status=report.failures.length?'fail':'pass_with_explicit_internal_wall_scope_limit';
writeFileSync(new URL('async-legality.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2)); if(report.failures.length)process.exitCode=1;
