// Reproduce the final review's exact 24-seed scheduler/RNG stress.
// Both engines use the candidate's rules. This checks wake-front scheduling
// against forced-full-awake execution; it is not an independent physics oracle.
// Run from any directory: node <prototype>/diagnostic/review-scheduler-stress.mjs
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { World } from '../candidate/ca-world.mjs';

const target = new URL('../candidate/ca-world.mjs', import.meta.url);
const moduleSha256 = createHash('sha256').update(readFileSync(target)).digest('hex');
const reviewedModuleSha256 = '39f451a625720a09a2f569e3f73bdfa95a9f8f4d6b9ac35fafc0033e71fa5727';
assert.equal(moduleSha256, reviewedModuleSha256, 'The reviewed candidate runtime must be unchanged');

let events = 0, checks = 0;
const results = [];
for (let seed = 1; seed <= 24; seed++) {
  let randomSeed = seed;
  const rnd = () => {
    randomSeed = (Math.imul(randomSeed, 1664525) + 1013904223) >>> 0;
    return randomSeed / 4294967296;
  };
  const a = new World(), b = new World();
  a.seed = b.seed = seed;
  const points = [];
  for (let x = 0; x < 232; x++) {
    const h = 2 + Math.floor(8 * rnd());
    for (let y = 420 - h; y < 420; y++) points.push({ x, y });
  }
  for (const w of [a, b]) w.admit(points, 1, 1, 0);

  let seedEvents = 0;
  const interventions = [];
  for (let t = 0; t < 300; t++) {
    if ([40, 100, 180].includes(t)) {
      const remove = a.snapshot().filter(p => p.y >= 417 && rnd() < .035).map(p => p.id);
      for (const w of [a, b]) w.remove(remove);
      const born = [];
      for (let k = 0; k < 12; k++) {
        const x = Math.floor(rnd() * 232), y = 380 + Math.floor(rnd() * 12);
        if (a.empty(x, y) && !born.some(p => p.x === x && p.y === y)) born.push({ x, y });
      }
      const speed = [0, 43.2, 120, 261, 480][seed % 5];
      for (const w of [a, b]) w.admit(born, 2, 2, speed);
      interventions.push({ beforeStepIndex: t, removed: remove.length, admitted: born.length, initialVy: speed });
    }
    for (let i = 0; i < b.n; i++) if (b.live[i]) b.chunks.add(b.chunk(b.x[i], b.y[i]));
    const ea = [], eb = [];
    a.audit = (...v) => ea.push(v);
    b.audit = (...v) => eb.push(v);
    a.step();
    b.step();
    assert.deepEqual(ea, eb, `seed ${seed} tick ${t} actions`);
    assert.equal(a.seed, b.seed, `seed ${seed} tick ${t} RNG`);
    assert.deepEqual(a.snapshot(), b.snapshot(), `seed ${seed} tick ${t} state`);
    checks++;
    events += ea.length;
    seedEvents += ea.length;
  }
  results.push({ seed, ticksChecked: 300, initialParticles: points.length, eventCount: seedEvents, finalParticles: a.count, finalRngState: a.seed, interventions, pass: true });
}

assert.equal(checks, 7200, 'Exact original review tick count');
assert.equal(events, 45204, 'Exact original review move count');
const report = {
  diagnostic: 'Final-review ordered wake-front versus forced-full-awake scheduler stress',
  targetModule: '../candidate/ca-world.mjs',
  moduleSha256,
  reviewedModuleSha256,
  scope: 'Same-rule action, snapshot, and RNG parity; not an independent physics oracle or visual acceptance test',
  seeds: 24,
  seedRange: [1, 24],
  stepsPerSeed: 300,
  interventionStepIndices: [40, 100, 180],
  admissionSpeeds: [0, 43.2, 120, 261, 480],
  ticksChecked: checks,
  eventCount: events,
  fullAwakeParity: true,
  pass: true,
  results
};
writeFileSync(new URL('../evidence/review-scheduler-stress.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ moduleSha256, seeds: report.seeds, ticksChecked: checks, eventCount: events, fullAwakeParity: true, pass: true }, null, 2));
