// Labeled artificial motion fixtures only; not shipped gameplay or QA commands.
// WorldType must be the selected model's CAWorld (one step = four 1/240 rules).
export function makeFlowFixture(WorldType, scene){
 const world=new WorldType(),bed=[],incoming=[];let description;
 if(scene==='thin-column-slope'){
  for(let y=390;y<420;y++)for(let x=116-(y-390);x<=116+(y-390);x++)bed.push({x,y});
  for(let y=342;y<378;y++)for(let x=110;x<114;x++)incoming.push({x,y});
  description='Static 45-degree triangular bed, apex (116,390), floor 419; 4-by-36 grain column at x110..113,y342..377, above the left slope.';
 }else if(scene==='shallow-local-disturbance'){
  for(let x=0;x<232;x++){const surface=390+Math.floor(Math.max(0,Math.min(30,x-100))/2);for(let y=surface;y<420;y++)bed.push({x,y})}
  for(let y=385;y<389;y++)for(let x=100;x<104;x++)incoming.push({x,y});
  description='Static 2-run/1-rise terrace from x100..130 (26.6 degrees), with a 4-by-4 incoming patch at x100..103,y385..388.';
 }else throw Error('Unknown flow fixture');
 world.admit(bed,1,1,0);world.sync();let steps=0;while(world.chunks.size){if(steps++>3)throw Error('Static fixture did not rest within existing one-output preparation allowance');world.step();world.completePresentation()}if(steps!==1)throw Error('Static fixture requires exactly one output to establish quiet');
 const bedState=world.snapshot(),birthSpeed=120;let released=false;
 return{world,metadata:{scene,artificial:true,description,seed:world.seed,bedCount:bed.length,incomingCount:incoming.length,birthSpeed,baseOutputFrames:steps,expectedCount:bed.length+incoming.length},bedState,
  release(){if(released)throw Error('Fixture already released');released=true;world.admit(incoming,3,2,birthSpeed);world.sync();return world.snapshot()},
 };
}
