import{createRequire}from'node:module';import{writeFileSync}from'node:fs';import assert from'node:assert/strict';
import{Game}from'../candidate/game.mjs';import{CALayerRenderer as Candidate,positionOnPath}from'../candidate/ca-layer.mjs';import{CALayerRenderer as Reference}from'../candidate/tests/reference/ca-layer.mjs';
const {createCanvas}=createRequire(new URL('../candidate/tests/pixel-equivalence-node.mjs',import.meta.url))('@napi-rs/canvas');let comparisons=0,horizontalPaths=0;const summary=[];
for(const scale of[1,1.5,2]){const g=new Game({seed:1});g.start();let token=0;const width=324*scale,height=486*scale,targets=[Candidate,Reference].map(Type=>{const canvas=createCanvas(width,height);return{canvas,c:canvas.getContext('2d'),r:new Type({createCanvas:()=>createCanvas(1,1)})}});
 for(let drop=0;drop<2;drop++){if(drop){g.move(24);g.rotate()}g.drop();let n=0,selected=[];
 while(g.phase!=='falling'){if(n++>500)throw Error('new-pose timeout');g.step();const f=g.pendingMaterialFrame,patch=g.world.consumeChanges({full:++token===1});if(f){for(const t of targets){t.r.synchronize([f],{positions:f.paths.map(p=>({id:p.id,xy:positionOnPath(p,0)}))});t.r.apply(patch)}
  const inspect=[1,2,4,8,16,32,48,64].includes(n)||f.requiresEndpointDraw;if(inspect){selected.push(n);for(const p of f.paths)for(let j=3;j<p.points.length;j+=3)if(p.points[j]!==p.points[j-3]&&p.points[j+1]===p.points[j-2])horizontalPaths++;
   for(const alpha of[.125,.5,1]){for(const t of targets){const{c,r}=t;r.synchronize([f],{positions:f.paths.map(p=>({id:p.id,xy:positionOnPath(p,alpha)}))});r.configure(width,height,'standard');c.setTransform(width/288,0,0,height/432,0,0);c.fillStyle='#0d1315';c.fillRect(0,0,288,432);c.save();c.beginPath();c.rect(28,0,232,420);c.clip();r.draw(c);c.restore()}assert(Buffer.from(targets[0].c.getImageData(0,0,width,height).data).equals(Buffer.from(targets[1].c.getImageData(0,0,width,height).data)),`exact RGBA scale${scale} drop${drop+1} frame${n} alpha${alpha}`);comparisons++}
  }
 }if(g.awaitingPresentation)assert(g.completePresentation(g.consumedToken+1));}
 summary.push({scale,drop:drop+1,frames:n,selected});}
}
const report={passed:true,backend:'Node @napi-rs/canvas, not browser timing',scope:'Actual new-physics first/offset rotated second poses; incremental candidate versus independent full-scene/full-repaint reference at three backing scales and .125/.5/1 interpolation phases',comparisons,horizontalPaths,summary};writeFileSync(new URL('../evidence/new-pose-pixels.json',import.meta.url),JSON.stringify(report,null,2));console.log(report);
