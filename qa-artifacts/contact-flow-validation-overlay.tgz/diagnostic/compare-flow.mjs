import {Game as Baseline} from '../baseline/game.mjs';
import {Game as Candidate} from '../candidate/game.mjs';
import {validateMaterialFrame,positionOnPath} from '../candidate/ca-layer.mjs';
import{writeFileSync}from'node:fs';import assert from'node:assert/strict';
const scenes=[];
for(const[version,Game]of[['r13',Baseline],['contact',Candidate]]){
 const g=new Game({seed:1});g.start();let events=0,phaseChecks=0,paths=0;const drops=[];
 for(let drop=0;drop<6;drop++){
  if(drop){g.move([24,-72,48,-24,72][drop-1]);if(drop%2)g.rotate()}
  if(!drop)while(g.phase==='falling')g.step();else g.drop();
  const colorLedger=new Map(g.world.snapshot().map(p=>[p.id,p.color]));
  const initial=new Map(g.world.snapshot().map(p=>[p.id,[p.x,p.y]])),lateral=new Set(),coords=new Map(g.world.snapshot().map(p=>[p.y*232+p.x,p.id]));let horizontal=0,diagonal=0,vertical=0,maxContactPerTick=0,positions=[],n=0;const before={...g.world.metrics};let seenIdTick=new Map();
  g.world.audit=(id,ox,oy,x,y)=>{
   const dx=x-ox,dy=y-oy;assert.equal(coords.get(oy*232+ox),id);assert.equal(coords.has(y*232+x),false);assert.ok(x>=0&&x<232&&y>=0&&y<420);assert.ok(dy===0?Math.abs(dx)===1:dy===1&&Math.abs(dx)<=1);
   if(dx){assert.ok(!coords.has(oy*232+x));assert.ok(oy===419||coords.has((oy+1)*232+ox));if(!dy){assert.ok(!coords.has((oy-1)*232+x));assert.ok(y===419||coords.has((y+1)*232+x));}}
   const key0=id+':'+g.world.tick,total=(seenIdTick.get('total:'+key0)||0)+1;seenIdTick.set('total:'+key0,total);const slot=g.world.slotOf(id),age=g.world.tick-g.world.birthTick[slot],v0=g.world.birthSpeed[slot],Q=n=>{const t=Math.max(0,n)/240,k=(720-v0)/900;return t<=k?v0*t+450*t*t:720*t-(720-v0)**2/1800};assert.ok(total<=Math.floor(Q(age)+1e-9)-Math.floor(Q(age-1)+1e-9));if(version==='contact')assert.equal(seenIdTick.get('horizontal:'+key0)||0,0,'A horizontal action ends its substep');
   coords.delete(oy*232+ox);coords.set(y*232+x,id);events++;
   if(dx){lateral.add(id);if(dy)diagonal++;else horizontal++;const key=id+':'+g.world.tick,c=(seenIdTick.get(key)||0)+1;seenIdTick.set(key,c);maxContactPerTick=Math.max(maxContactPerTick,c);if(version==='contact'&&!dy){const hkey='horizontal:'+key,h=(seenIdTick.get(hkey)||0)+1;seenIdTick.set(hkey,h);assert.ok(h<=1);}}else vertical++;
  };
  while(g.phase!=='falling'&&g.state==='playing'){
   if(n++>=1800)throw Error(version+' drop '+drop+' did not settle');coords.clear();for(const p of g.world.snapshot())coords.set(p.y*232+p.x,p.id);g.step();
   assert.equal(g.world.count+g.rawCleared,g.added);for(const p of g.world.snapshot())assert.equal(p.color,colorLedger.get(p.id),'Per-identity color is conserved');
   if(g.pendingMaterialFrame){if(version==='contact')validateMaterialFrame(g.pendingMaterialFrame);paths+=g.pendingMaterialFrame.paths.length;for(const p of g.pendingMaterialFrame.paths){for(const t of[0,.125,.25,.5,.75,.875,1]){const [x,y]=positionOnPath(p,t);assert.ok(x>=28.5&&x<=259.5&&y>=.5&&y<=419.5);phaseChecks++;}}}
   const s=g.world.snapshot(),xs=s.map(p=>p.x),ys=s.map(p=>p.y);positions.push({frame:n,moves:g.world.frameLast?.moves,xMin:Math.min(...xs),xMax:Math.max(...xs),yMin:Math.min(...ys),yMax:Math.max(...ys),activeChunks:g.world.chunks.size,particlesVisited:g.world.frameLast?.particles,contactMoves:g.world.metrics.contactMoves??0});
   if(g.awaitingPresentation)assert(g.completePresentation(g.consumedToken+1));
  }
  const after=g.world.snapshot(),net=after.filter(p=>initial.has(p.id)).map(p=>Math.abs(p.x-initial.get(p.id)[0])),newborn=after.filter(p=>p.batch===drop+1),newSide=newborn.filter(p=>lateral.has(p.id));
  drops.push({drop:drop+1,frames:n,seconds:n/60,live:after.length,cleared:g.rawCleared,colorCounts:[1,2,3,4].map(c=>after.filter(p=>p.color===c).length),lateralParticles:lateral.size,newbornLateral:newSide.length,newbornCount:newborn.length,netLateralSum:net.reduce((a,b)=>a+b,0),moves:{vertical,diagonal,horizontal,maxContactPerTick},extent:positions.at(-1),work:Object.fromEntries(Object.keys(before).map(k=>[k,g.world.metrics[k]-before[k]])),positions});
 }
 let idleMoves=0;g.world.audit=()=>idleMoves++;const settled=JSON.stringify(g.world.snapshot());for(let f=0;f<20;f++){g.world.step();assert.equal(JSON.stringify(g.world.snapshot()),settled)}
 scenes.push({version,drops,idleMoves,events,phaseChecks,paths});
}
writeFileSync(new URL('../evidence/flow-comparison.json',import.meta.url),JSON.stringify(scenes,null,2));console.log(JSON.stringify(scenes.map(v=>({...v,drops:v.drops.map(({positions,...d})=>d)})),null,2));
