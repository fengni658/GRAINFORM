import {World} from '../baseline/ca-world.mjs';
import {Game} from '../baseline/game.mjs';
import {writeFileSync} from 'node:fs';
const out={baseline:'Frozen r13, runtime unmodified',fixtures:[]};
const w=new World(),bed=[];
for(let x=0;x<232;x++){const surface=390+Math.floor(Math.max(0,Math.min(30,x-100))/2);for(let y=surface;y<420;y++)bed.push({x,y})}
w.admit(bed,1,1,0);for(let j=0;j<10;j++)w.step();const settled=w.chunks.size===0;
w.admit([{x:100,y:389}],2,2,120);const id=w.idAt(w.n-1);let actions=0;w.audit=(p)=>{if(p===id)actions++};for(let j=0;j<80;j++)w.step();const p=w.snapshot().find(p=>p.id===id);let awakeActions=0;w.audit=(p)=>{if(p===id)awakeActions++};for(let j=0;j<80;j++){for(let i=0;i<w.n;i++)if(w.live[i])w.chunks.add(w.chunk(w.x[i],w.y[i]));w.step()}
out.fixtures.push({name:'grain-on-two-run-one-rise-stair-slope',bedInitiallySettled:settled,probeStart:[100,389],probeAfter:[p.x,p.y],actions,fullAwakeActions:awakeActions,rightSameLevelEmpty:w.empty(101,389),rightBelowBlocked:!w.empty(101,390),twoRightBelowEmpty:w.empty(102,390),claim:'No move on 26.6-degree staircase despite an adjacent supported roll leading downhill; forcing all chunks awake changes nothing.'});
const f=new World();f.admit([{x:116,y:418}],1,1,480);let flat=[];f.audit=(...v)=>flat.push(v);for(let j=0;j<100;j++)f.step();out.fixtures.push({name:'single-grain-contact-flat-floor',start:[116,418],end:[f.x[0],f.y[0]],moves:flat.map(v=>({dx:v[3]-v[1],dy:v[4]-v[2]})),claim:'Actual descent to floor produces no post-contact lateral runout.'});
const g=new Game({seed:1});g.start();while(g.phase==='falling')g.step();let observations=[],moves=0,slides=0,floorLateral=0;const idsWithLateral=new Set();let k=0;
g.world.audit=(id,ox,oy,x,y)=>{moves++;if(x!==ox){slides++;idsWithLateral.add(id)}if(oy===419&&x!==ox)floorLateral++};
while(g.phase!=='falling'&&g.state==='playing'){if(k++>500)throw Error('timeout');g.step();const s=g.world.snapshot();const xs=s.map(p=>p.x),ys=s.map(p=>p.y);observations.push({frame:k,moves:g.world.frameLast?.moves,xMin:Math.min(...xs),xMax:Math.max(...xs),yMin:Math.min(...ys),yMax:Math.max(...ys)});if(g.awaitingPresentation)g.completePresentation(g.consumedToken+1)}
const first=g.world.snapshot();let allAwakeMoves=0;g.world.audit=()=>allAwakeMoves++;for(let n=0;n<20;n++){for(let i=0;i<g.world.n;i++)if(g.world.live[i])g.world.chunks.add(g.world.chunk(g.world.x[i],g.world.y[i]));g.world.step()}
out.naturalFirst={seed:1,settlingFrames:k,count:first.length,moves,slides,slideShare:slides/moves,particlesEverLateral:idsWithLateral.size,floorLateral,allAwakeAfterRestMoves:allAwakeMoves,observations};
writeFileSync(new URL('./baseline-flow.json',import.meta.url),JSON.stringify(out,null,2));console.log(JSON.stringify({...out,naturalFirst:{...out.naturalFirst,observations:'in JSON'}},null,2));
