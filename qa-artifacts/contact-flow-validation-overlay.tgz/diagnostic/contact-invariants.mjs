import assert from 'node:assert/strict';import{writeFileSync}from'node:fs';
import {World}from'../candidate/ca-world.mjs';import{FrameWorld}from'../candidate/ca-frame-world.mjs';import{Game,SHAPES}from'../candidate/game.mjs';import{validateMaterialFrame,positionOnPath}from'../candidate/ca-layer.mjs';
const report={fixtures:[],pass:true};
function settle(w,max=3000){let n=0;while(w.chunks.size){assert.ok(n++<max,'bounded fixture reaches rest');w.step();w.completePresentation()}return n}
function idle(w){const s=JSON.stringify(w.snapshot());let moves=0;w.audit=()=>moves++;for(let n=0;n<80;n++)w.step();assert.equal(moves,0);assert.equal(JSON.stringify(w.snapshot()),s);w.audit=null;return moves}
{
 const w=new World(),bed=[];for(let x=0;x<232;x++){const surface=390+Math.floor(Math.max(0,Math.min(30,x-100))/2);for(let y=surface;y<420;y++)bed.push({x,y})}w.admit(bed,1,1,0);settle(w);const b=JSON.stringify(w.snapshot());w.admit([{x:100,y:389}],2,2,120);const id=w.idAt(w.n-1),events=[];w.audit=(p,ox,oy,x,y)=>{if(p===id)events.push({tick:w.tick,ox,oy,x,y})};const steps=settle(w),p=w.snapshot().find(p=>p.id===id);assert.ok(events.some(e=>e.y===e.oy));assert.ok(p.x>100&&p.y>389);const ht=new Set();for(const e of events)if(e.y===e.oy){assert.ok(!ht.has(e.tick));ht.add(e.tick);}report.fixtures.push({name:'26.6-degree-slope',steps,start:[100,389],end:[p.x,p.y],events,idleMoves:idle(w)});
}
{
 const w=new World();w.admit([{x:116,y:418}],1,1,480);const events=[];w.audit=(...e)=>events.push(e);settle(w);const dx=w.x[0]-116;assert.ok(Math.abs(dx)>0&&Math.abs(dx)<=6);const dirs=events.filter(e=>e[3]!==e[1]).map(e=>Math.sign(e[3]-e[1]));assert.equal(new Set(dirs).size,1);report.fixtures.push({name:'finite-flat-impact',start:[116,418],end:[w.x[0],w.y[0]],events,idleMoves:idle(w)});
}
{
 const w=new World();w.admit([{x:116,y:419}],1,1,0);settle(w);assert.equal(w.x[0],116);w.tick+=100000;w.wake(116,419);settle(w);assert.equal(w.x[0],116);assert.equal(w.contactEnergy[0],0);report.fixtures.push({name:'no-stale-sleep-impulse',pass:true,idleMoves:idle(w)});
}
{
 const w=new World(),bed=[];for(let y=410;y<420;y++)for(let x=0;x<232;x++)if(!(x===116&&y===415))bed.push({x,y});w.admit(bed,1,1,0);const buried=w.grid[415*232+115]-1;assert.ok(w.contactOptions(buried,6).every(d=>!d));settle(w);const before=JSON.stringify(w.snapshot());w.tick+=100000;w.wake(116,415);settle(w);assert.equal(JSON.stringify(w.snapshot()),before);report.fixtures.push({name:'buried-cavity-does-not-creep',pass:true,idleMoves:idle(w)});
}
{
 const a=new World(),b=new World();for(const w of[a,b]){const pts=[];for(let y=405;y<420;y++)for(let x=0;x<232;x++)pts.push({x,y});w.admit(pts,1,1,0);settle(w);const removed=w.snapshot().filter(p=>p.y===419&&p.x>=106&&p.x<122).map(p=>p.id);w.remove(removed);w.admit([{x:94,y:400},{x:133,y:399},{x:128,y:395}],2,2,180)}let moves=0,steps=0,maxFront=0;
 for(;steps<800;steps++){const ea=[],eb=[];a.audit=(...v)=>ea.push(v);b.audit=(...v)=>eb.push(v);for(let i=0;i<b.n;i++)if(b.live[i])b.chunks.add(b.chunk(b.x[i],b.y[i]));a.step();b.step();assert.deepEqual(ea,eb);assert.deepEqual(a.snapshot(),b.snapshot());assert.equal(a.seed,b.seed);moves+=ea.length;maxFront=Math.max(maxFront,a.frontStats.peakHeap);if(!a.chunks.size)break}assert.ok(steps<800);report.fixtures.push({name:'full-awake-new-rule-support-removal',steps,moves,maxFront,idleMoves:idle(a)});
}
{
 const w=new World();w.admit([{x:100,y:419}],1,1,480);const old=w.idAt(0);w.contactDir[0]=-1;w.contactEnergy[0]=6;w.contactUntil[0]=999999;w.contactNext[0]=999999;w.fallDistance[0]=18;w.remove([old]);w.admit([{x:100,y:419}],2,2,0);assert.notEqual(w.idAt(0),old);assert.equal(w.contactDir[0],0);assert.equal(w.contactEnergy[0],0);assert.equal(w.contactNext[0],0);assert.equal(w.fallDistance[0],0);settle(w);assert.equal(w.x[0],100);report.fixtures.push({name:'generation-resets-contact-state',pass:true});
}
{
 const w=new FrameWorld();w.admit([{x:0,y:419},{x:231,y:419}],1,1,480);const n=settle(w);assert.ok([...w.x.slice(0,2)].every(x=>x>=0&&x<232));report.fixtures.push({name:'walls-bound-finite-roll',frames:n,end:w.snapshot(),idleMoves:idle(w)});
 const valid={token:1,ruleTick:4,paths:[{id:1,mode:'substep-arc',points:[10.5,400.5,0,11.5,400.5,17,12.5,401.5,34,12.5,402.5,51,12.5,402.5,68]}]};validateMaterialFrame(valid);assert.deepEqual(positionOnPath(valid.paths[0],.125),[11,400.5]);assert.deepEqual(positionOnPath(valid.paths[0],.375),[12,401]);for(const [dx,dy]of[[2,0],[.5,0],[1,-1],[3,1]])assert.throws(()=>validateMaterialFrame({token:1,ruleTick:1,paths:[{id:1,mode:'substep-arc',points:[10,10,0,10+dx,10+dy,17]}]}));report.fixtures.push({name:'horizontal-diagonal-arc-and-invalid-legs',pass:true});
}

{
 const w=new World(),bed=[];for(let y=390;y<420;y++)for(let x=116-(y-390);x<=116+(y-390);x++)bed.push({x,y});w.admit(bed,1,1,0);settle(w);const initial=JSON.stringify(w.snapshot());let stationaryMoves=0;w.audit=()=>stationaryMoves++;for(let n=0;n<80;n++){for(let i=0;i<w.n;i++)if(w.live[i])w.chunks.add(w.chunk(w.x[i],w.y[i]));w.step()}assert.equal(stationaryMoves,0);assert.equal(JSON.stringify(w.snapshot()),initial);let oldMoves=0,newMoves=0;w.admit([{x:112,y:382}],2,2,120);const probe=w.idAt(w.n-1);w.audit=id=>id===probe?newMoves++:oldMoves++;const steps=settle(w);assert.equal(oldMoves,0);assert.ok(newMoves>0);report.fixtures.push({name:'static-pile-wake-is-not-motion-qualification',fullAwakeSteps:80,stationaryMoves,probeSteps:steps,oldMoves,newMoves,idleMoves:idle(w)});
}

{
 const w=new World();w.admit([{x:100,y:419},{x:101,y:419},{x:102,y:419}],1,1,43.2);const id=w.idAt(1);w.step();assert.equal(w.impactReady[1],0);assert.equal(w.contactUntil[1],0);assert.equal(w.contactEnergy[1],0);w.tick+=100000;w.remove([w.idAt(0),w.idAt(2)]);settle(w);assert.equal(w.x[w.slotOf(id)],101);report.fixtures.push({name:'zero-quota-buried-admission-cannot-store-impact',pass:true,idleMoves:idle(w)});
}
function advance(g,predicate,max=1500){for(let n=0;n<max;n++){if(predicate())return n;g.step();assert.equal(g.world.count+g.rawCleared,g.added);if(g.awaitingPresentation)assert(g.completePresentation(g.consumedToken+1))}throw Error('phase fixture timeout')}
{
 const g=new Game();const base=Array.from({length:232},(_,i)=>({x:i+28,y:419,color:1})).filter(p=>p.x<120||p.x>=168);assert(g.world.addMany(base,{initialVy:0}).accepted);g.added=base.length;settle(g.world);g.next={shape:SHAPES[0].map(p=>p.slice()),color:1};g.start();g.active.x=120;g.drop();let frames=0;while(g.world.chunks.size){g.step();frames++;if(g.world.chunks.size&&g.awaitingPresentation)assert(g.completePresentation(g.consumedToken+1));assert.ok(frames<1500)}assert.equal(g.phase,'settling');assert(g.awaitingPresentation);const t=g.consumedToken+1;assert(!g.completePresentation(t,{endpointDrawn:false}));for(let n=0;n<10;n++)g.step();assert.equal(g.phase,'settling');assert.equal(g.rawCleared,0);assert(g.completePresentation(t,{endpointDrawn:true}));g.step();assert.equal(g.phase,'flash');const group=g.pendingClear.flat();assert.equal(group.length,2488);for(let n=0;n<11;n++){g.step();assert.equal(g.rawCleared,0)}g.step();assert.equal(g.rawCleared,2488);assert.equal(g.world.count,0);advance(g,()=>g.phase==='falling');report.fixtures.push({name:'actual-connected2488-ACK-and-flash',frames,cleared:g.rawCleared,score:g.score});
}
writeFileSync(new URL('../evidence/contact-invariants.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
