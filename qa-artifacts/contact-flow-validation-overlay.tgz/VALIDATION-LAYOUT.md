# Minimal independent-QA overlay

No old source, assets, reports, or result data are duplicated here.

Required layout under a fresh QA root:

- baseline/: a complete unchanged r13 copy, or a local link to the reviewer's existing unchanged r13.
- candidate/: a separate complete r13 copy, with contact-flow-delta.tgz extracted inside this directory.
- diagnostic/: extract this overlay at the QA root, beside candidate/ and baseline/.
- evidence/: create this directory for script output, or use the already supplied evidence archive.

Never apply the delta to the unchanged baseline. All diagnostic imports use this relative layout; no developer-machine absolute path is required. The existing full r13 supplies the inherited tests, full-render reference, runtime dependencies, and source files absent from the small delta.

Prepare (replace the two verified paths with the QA environment's actual directories):

mkdir -p QA_ROOT/candidate QA_ROOT/evidence
cp -a EXISTING_UNCHANGED_R13/. QA_ROOT/candidate/
ln -s EXISTING_UNCHANGED_R13 QA_ROOT/baseline
# A separate ordinary copy may be used instead of the baseline link.
tar -xzf contact-flow-delta.tgz -C QA_ROOT/candidate
tar -xzf validation-overlay.tgz -C QA_ROOT
cd QA_ROOT

Current targeted execution commands, for independent reproduction if needed:

(cd candidate && npm test)
(cd candidate && npm run verify:slots)
node candidate/tests/speed720-independent-quota.mjs
node diagnostic/contact-invariants.mjs
node diagnostic/review-scheduler-stress.mjs
node diagnostic/compare-flow.mjs
node diagnostic/new-pose-pixels.mjs
node diagnostic/baseline-flow.mjs

new-pose-pixels.mjs uses the same existing @napi-rs/canvas dependency as the original r13 Node raster tests. It is a same-pose raster check, not browser timing. Do not install or change dependencies merely to run an already documented check without checking the QA environment's existing setup first.

For the four decisive continuous recordings, use the already delivered QA-RECORDING-SPEC.md. flow-fixtures.mjs has no imports and exports makeFlowFixture(WorldType, scene); pass the selected baseline or candidate CAWorld. Supported scene names are thin-column-slope and shallow-local-disturbance. It returns the real world, exact metadata, original bed identities, and a single-use release(). For a browser harness, expose this helper through the authorized QA server or import its source as a module. Preserve normal-time actual arcs and final alpha-1 acknowledgement; do not present offline reconstructed frames as native recordings.

CONTACT-FLOW-RUNTIME-MANIFEST.json contains the exact 21 top-level runtime hashes and the six overlay-script hashes. Only ca-world.mjs, ca-layer.mjs, and simulation-worker.mjs differ from frozen r13. Full earlier reports/manifests remain in the already supplied evidence archive.
