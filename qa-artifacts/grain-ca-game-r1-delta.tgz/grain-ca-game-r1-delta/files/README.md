# GRAINFORM internal CA Game revision 1

This is a frozen renderer/test/measurement revision of baseline archive SHA256 35a0937b3bd1bdd0ea0271a31119e08a06e8eca191ff8a1ff15bc9573251f424. It is not published or approved for user playtesting. Physics, Game state transitions, material cadence and micrograin appearance are unchanged.

## Revision changes

1. Only stable cache invalidation and repainting changed: device-aligned tiles, original global paint order, complete intersecting microcircles, and a same-size/origin scratch surface. Direct arc clipping altered antialias coverage in an actual pixel counterexample, so whole uncut arcs are drawn on scratch and exact integer device-pixel tiles are copied to the cache. The screen still composites one complete stable layer before the unchanged dynamic layer. Dynamic sample/allocation code is deliberately retained for clear attribution.
2. The held-key browser test now waits for the restart epoch and a strictly newer pieceId after the drop ACK, plus a non-null falling piece. The old phase-only wait could see the old piece snapshot and later read active.x while active was null. This fixes the test, not a gameplay input defect.
3. Snapshot delivery delay uses worker/window performance.timeOrigin, with the receive stamp captured at handler entry. lastSnapshotDeliveryDelayMs and maxSnapshotDeliveryDelayMs include preparation after the send stamp and event-queue waiting; they are not isolated structured-clone CPU. Missing origins yield unknown rather than fictitious zero.

## Verification to run

- npm test: Game, UI/worker protocol, cache behavior and cross-realm measurement tests.
- npm run verify:pixels: exact cache and final-screen RGBA comparison using the ALREADY INSTALLED @napi-rs/canvas. Resolution uses Node createRequire from tests/pixel-equivalence-node.mjs. No install step is authorized or needed here. If the second environment lacks it, report that dependency and use the browser fixture below; do not silently install.
- npm run verify:pixels:browser: same injectable scenes with native Chromium Canvas2D and existing Playwright. GRAINFORM_PLAYWRIGHT_MODULE and GRAINFORM_CHROMIUM can identify existing supported installations. No custom security flags are passed.
- npm run verify:browser: actual UI/Worker browser smoke including the repaired piece barrier.
- npm run verify:slots and npm run verify:parity remain available; their physics sources are unchanged from the approved baseline.

The 144 Node Skia comparisons use exact RGBA bytes, including324×486, dense beds, fractional sizes, edge/corner antialiasing, raw/micro modes, theme/resize, two pending frames, deletion/ID reuse and full-sync paint-order changes. This proves equality on that backend; actual Chromium pixels and performance still require independent verification.

## Performance claims and measurement scope

Independent baseline Chromium feedback found only44–46draw/s on the13824-cell sixth batch. Stable cache repaint plus final drawImage accounted for approximately97% of rAF cost. drawImage included deferred rasterization waiting and must not all be called a memory copy. Baseline ended near1.0 cumulative simulation/wall ratio but did not sustain60Hz during dense motion.

Operation-count fixtures show an internal dense-bed grain membership change repainting354 rather than13823 stable particles, plus one18×18device-pixel internal copy at324×486. That is not a browser FPS claim. New scratch-copy costs must be included in the next real-browser profile.

Run performance both with QA ON and OFF, on the same physical scenario and viewport. QA is query.has('qa'): remove the entire qa parameter for OFF; ?qa=0 is still ON. Confirm worker.qaEnabled in each record. QA-only JSON.stringify/TextEncoder byte-measurement overhead must be listed separately from postMessage synchronous time, handler time and calibrated end-to-end delivery delay. Do not infer isolated clone CPU from any of them. Include rAF mean/p95/max, active drawHz, queue/debt trajectory, stable paints/tiles/internal-copy pixels, actual paused/hidden behavior and long-session identity/render-cache reuse. No installation or cloud-side source repair is part of verification.

---

## Preserved baseline documentation

# GRAINFORM internal CA Game candidate

Internal candidate only. No Site checkout changed and no release/publication performed. The gameplay CA, fixed ID roughness, four material rules per60Hz output, and whole-block-to-cell conversion are deliberate game approximations. They replace the previous676 hard-circle/triangular-slot model with2304 tracked1px material cells per four-tile piece, preserving occupied area and normalized scoring mass.

## Run and verify

- `npm test`: current CA Game/phase and retained UI/worker contract tests
- `npm run verify:slots`: bounded reuse/atomic identity tests
- `npm run verify:parity`: self-contained551-frame comparison against the frozen roughness reference, including full paths, clear and support recovery
- `npm start`: local-only server, default127.0.0.1:4181
- `npm run verify:browser`: real Chromium smoke with existing Playwright. Set GRAINFORM_PLAYWRIGHT_MODULE only if its installed location needs explicit resolution. No installation or security changes are part of the script.

The dot environment could not start Chromium because ProcessSingleton socket creation was denied. This happened before loading Game; browser/UI wall-clock performance is NOT verified. The frozen package is intended for independent Codex environment verification. Do not give this candidate to the user as a working playtest until that completes.

## Preserved Game behavior

- Falling shape remains one solid four-cell silhouette. Each swept integer pose is tested; only actual contact atomically admits the entire2304-cell shape.
- `falling → settling → checking → flash → settling → spawn`; stable means exact no legal material move, two complete no-move active sweeps, and last physical frame actually presented by rAF.
-12 control flash ticks at60Hz preserve the old0.2second duration; score/level mass normalization changes169→576cells per tile to preserve the old score per block.
- Seven shapes, rotations, seeded next-piece selection, input phase locking, epoch and pieceId barriers, pause/blur/hidden/restart semantics are retained.
- UI rAF follows each recorded horizontal/vertical unit leg. It sends exact epoch/token acknowledgment only after painting the completed frame. Worker allows at most2unacknowledged material frames and retains owed wall-clock time under backpressure. No queue truncation or playback-rate tricks.
- Public stable handles use generation×capacity+slot. Grid and typed arrays use bounded slots; stale IDs cannot delete reused births.320-cycle reuse and ghost-path tests pass.

## What changed and what is still unverified

Raw CA cells no longer claim hard-circle contact mechanics. Fixed per-ID roughness permits either1or2horizontal cells before at least1downward cell, with complete clear paths and deterministic geometric sleep. The approved wake optimization visits each affected chunk once in the same insertion order; merged trajectories remain exact against the original reference.

The old node tests for676circle spacing and triangular row/column geometry are retained as historical source files but are not applicable to this explicitly approved model replacement. The current npm test list names the applicable CA and UI/worker tests. The old runtime itself remains separately preserved in grain048-dynamic-review; no old pass count is claimed as new proof.

Core headless timings do not include UI rendering, message cloning or event latency. The roughness candidate's original late-batch p95≈6–7ms and the wake patch's≈5ms remain above the internal4ms comparison gate. This alone does not establish60Hz failure or success. The browser smoke must measure actual wall time, presentation queue, renderer cost and worker messages. A slow machine must display retained debt rather than silently slow simulation or discard frames.

QA bridge/cascade/early-clear setups are explicitly artificial fixtures. Ordinary Game clears after each stable batch; the six-block density experiment deliberately delayed clear and is not its spawn schedule.

## Verification artifacts

- evidence/node-tests.log: current Node suite
- evidence/slot-merge-tests.json: bounded identity atomic tests
- evidence/slot-wake-parity.json:551exact frames,330rigid idle rule comparisons,4608clear,680support cut
- evidence/dot-browser-blocked.json: confirmed environment startup blocker
- browser-smoke.mjs: portable real-browser test sequence, not yet passed here
- validation-reference/: frozen original CA and minimal fixture/checkpoint data

No source was copied from an external falling-sand repository. Implementation borrows general game mechanisms independently, with source review kept in the broader task evidence.
