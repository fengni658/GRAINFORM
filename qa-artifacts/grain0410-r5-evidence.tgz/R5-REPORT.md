# 0.4.10 edge-contour-r5 — adjacent-column descent

Frozen candidate is grain0410-edge-r5, based on frozen r4. Only runtime ca-world.mjs changes: direction permits a one-cell adjacent descent, and no longer lets an ID-dependent two-cell slide cross a still-supported shoulder. All other nine runtime files are byte-identical, including r3 batching and r4 presentation/barrier protocol. No trajectory smoothing, blur, particle removal, extra collision solver, time-rate change or compensating rule is included.

## Intentional physical and appearance changes

First/second drops use the same seed1 and same accepted commands. Offline results:
- First2304 grains:35control ticks unchanged, width121→107cells, height40→41.
- Second4608:83→84ticks (1.383→1.400s), width164→136 (−17.1%), height63→67.
- Second overall aspect-ratio slope proxy atan(height/(width/2)):37.53°→44.58°. This is not a fitted angle of repose.

The material is more compact and steep, with shorter lateral transport. Original-CSS worst-phase comparisons show markedly fewer prominent connected horizontal tooth rows, while fine grain-sized fluctuations remain. Parent reviewed these images and approved a real-browser candidate, not final visual acceptance. There is no claim that nonzero pixel roughness is itself failure or that every microstep is geometrically smooth.

The inspection swept137 half-stages at each of four second-drop times .25/.5/.75/1s, both models. The contact sheet selects each model's own worst phase by a documented connected-mask reversal indicator, then renders the unchanged texture at originalCSS size. It is not an actual browser video or identical physical pose comparison. Raw indicators alone do not determine visual acceptance.

## Settling-time cost is explicit

Six-drop natural-clear input: both clear2304 and retain11520 of13824; sixth drop127→146control ticks (2.117→2.433s,+15.0%). The23-drop dense sequence reaches52992 live grains in both without top-out: total1278→1403control ticks(+9.8%); drops19–23 aggregate302→326(+7.9%). Do not claim every scenario settles as quickly. These are physical-model differences under the unchanged clock.

## Local verification completed on final directory

-68 existing Node flow/clock/render/presentation/gate tests PASS.
-252 exact identical-pose raster/reference comparisons PASS. Rendering is unchanged; generated physical trajectories intentionally differ.
-320 slot/reuse cycles PASS. The obsolete test demanding some generations cross two cells was replaced with the explicit supported-shoulder prohibition for all generations plus positive one-cell descent. The original failure and frozen r4 remain; identity texture/hash stability is retained.
-Independent direction/admissibility oracle:196608 direction cases;2096frames,7440rule steps,3140300unit moves,532599one-cell horizontal legs,zero second-horizontal phases10/13/16;62447088particle snapshot comparisons. Expected occupancy originates from explicit birth/removal inputs and validated unit events, never candidate snapshots.
-Real26-block/4-color Game naturally clears twice,27584grains total;4736generation-handle reuses checked. Independent support removal3312grains causes all576 previously supported grains to descend.
-Analytic continuous-square collision oracle:12fixtures (six new/six frozen-r4),six oracle self-tests,24650pair-phase interval checks,70actual unit legs, no overlap or duplicate/lost occupancy. One-cell bridge-aperture transit succeeds with24grains conserved. Sand walls are verified stationary only during the finite fixture interval; no permanent-rigid-wall claim.

Motion-oracle scope is legality/conservation, not a second full velocity/credit/chunk simulator or proof every legal move is emitted. The collision oracle supplies continuous between-phase geometry checks. The unchanged phase-axis architecture and remaining original tests complement these checks.

Old551-frame049/r4 exact-trajectory parity is intentionally not applicable. Its original expected/reference files and merge-parity.mjs are untouched. verify:motion is the new explicit oracle; verify:parity is a documented compatibility alias and prints that it is NOT historical trajectory equality.

## Computational scope

One direction call now inspects at most one neighbor instead of two and no longer hashes an ID to choose reach. There is no added global traversal, solver iteration, allocation/index or retained cache. In the23-drop Node no-render check, particle visits8849285→8815865 and direction checks69249224→68990570; path moves1935907→1971683 and control ticks increase as above. Local high-density stepCPU p95/p99 32.75/40.83ms→26.13/36.21ms is only a computational sanity observation, not controlled browser performance or a causal speedup percentage. Real DPR2 and activity-only debt still require QA.

## Independent browser gate

Apply the exact revision overlay to a separate complete r4 root. Only ca-world.mjs is a runtime replacement; provided new tests and frozen-r4 reference copies make checks self-contained. Run npm test, verify:slots, verify:motion, verify:collisions, verify:pixels:browser and verify:browser. Do not demand old551 trajectory equality or silently rebaseline old golden snapshots.

Capture actual ACKed first/rotated-right second drop at DPR1/1.5/2, especially early steep-side flow and0.5–1.2s where r4 failed. Judge recurring attached2–3CSSpx tooth rows separately from isolated grains and roughly1CSSpx texture/AA. Also assess whether the compact steeper shape looks unnaturally blocky/pointed; show width/height/settling differences honestly. Avoid selecting only favorable alpha or final stills.

Recheck natural mixed-color clearing, isolated grains and small holes/one-cell passages, pause/hidden/resume/reset/resync, and actual finalalpha1 drawn endpoint before flash. Runtime r4 receipt arrays and consumed/presented distinction are unchanged. Inspect active-only sixth/high-density CPU, actualdraw/s and draw-start gaps, max2queue, peak and lastSETTLING debt, with recording/GC outside timing. Do not conceal debt with later falling samples or claim stable60fps. Short native-memory uncertainty remains.

Unpublished. Frozen r3/r4 remain as valid performance/timeline improvements with recorded visual failures. Final visual/physics-style acceptance belongs to the parent/user after actual browser review.
