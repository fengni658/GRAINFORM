# GRAINFORM 0.4.10 edge-contour-r3

Unpublished rendering-only performance patch over frozen edge-contour-r2. Original 049, r1 and r2 remain unchanged. Apply the exact delta to a separate complete r2 copy and verify all old/new hashes. Only ca-layer.mjs changes among the ten runtime files.

## One targeted change: batch dirty-tile scratch rasterization

Collect the union of particle IDs in dirty stable-cache tiles, sort by the existing global paintRanks, and paint each particle once into the same-size scratch canvas at the original transform/origin. Clear scratch once before painting. After all painting is complete, copy the original integer-device-pixel dirty tile rectangles into the stable cache without modifying scratch between copies.

Each grain is still independently filled in the same relative paint order. The original dirty footprints, AA fringe, local crop rectangles, palette, full-cache rebuild policy, final composite, dynamic drawing, highlight drawing and fallback remain unchanged. Clearing the scratch canvas does not repaint the stable bed: only the union of dirty-tile grains is painted, and only original dirty tiles are copied. No new persistent cache or retained scene is introduced.

The contour geometry, rim, glyph protection weights and styles are byte-identical to r2. Physics, complete unit paths, clock, worker, rendering completion/ACK and clear gate are unchanged. No Path2D caching, skipped time, resolution reduction or smoothing-rule change is included.

## Why this change

Independent Chromium DPR2 profiling of frozen r2 located the dominant synchronous cost in dirty-cache handling: mean7.05ms/p9517.4ms; tile copy calls inside it mean5.24ms/p9512.8ms. There were3100tile copies across337dirty passes. Trace supports repeated source-raster/submit work, but does not uniquely separate source flush, target compositing and waiting. This patch removes source modifications between copies and deduplicates shared-border grain painting. Actual browser speedup is pending independent verification.

## Local verification

- 51 Node tests (one new behavioral test requires one globally ordered scratch paint before every tile copy, and no work on idle).
- 252 exact RGBA fixture draws against independent fresh-contour/full-stable reference, including a new52992-particle/56-dirty-tile/four-color corner, removal, reversed-reinsertion and reset fixture.
- Additional36 exact screen/cache comparisons directly against frozen r2 at DPR1/1.5/2.
- 320 slot cycles and551-frame six-batch/clear/support-cut physics/path parity.

Node Canvas checks are raster correctness only, not real UI timing or leak proof. The known old monolithic Node verify:edge-sequence is not required. Independent Chromium must run npm test, verify:pixels:browser, verify:browser, verify:slots and verify:parity, and repeat fixed topology checks if desired; the contour source hash is unchanged from the already-verified r2.

## Required browser review and remaining limits

Compare complete independent r2/r3 module roots with the same real presented poses. Verify screen and cache exact RGBA including mixed-color tile corners at DPR1/1.5/2 and resize/highlight/fallback. Check actual first/second drops, clearing and reset. Run unprofiled/no-recording DPR2 high-density performance with measured CSS/backing dimensions and full activity windows; include draw rate, rAF/draw p95/p99/max, exceedance percentage/consecutive count, per-frame dirty work, presentation queue and peak/end debt. Record actual drop poses so timing differences are not mistaken for identical physical workloads.

Frozen r2 failed the DPR2 frame budget and showed transient debt1.31s. R3 has no independent browser performance result yet and is not ready to publish on local tests alone. R2 visual improvement is local short-tooth reduction, not elimination of all natural roughness or proven absence of every high-frequency flicker. Previous short browser memory tests did not exclude long-term native leakage. No deployment is included.
